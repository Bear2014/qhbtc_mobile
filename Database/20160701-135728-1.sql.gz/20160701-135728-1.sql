-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : mydbbtc.cltb6pznmc6g.ap-northeast-1.rds.amazonaws.com
-- Port     : 3306
-- Database : move
-- 
-- Part : #1
-- Date : 2016-07-01 13:57:28
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `movesay_admin`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_admin`;
CREATE TABLE `movesay_admin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `username` char(16) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `moble` varchar(50) NOT NULL,
  `password` char(32) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `last_login_time` int(11) unsigned NOT NULL,
  `last_login_ip` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='管理员表';

-- -----------------------------
-- Records of `movesay_admin`
-- -----------------------------
INSERT INTO `movesay_admin` VALUES ('1', '', 'admin123', '', '', '0192023a7bbd73250516f069df18b500', '0', '0', '0', '0', '0', '1');
INSERT INTO `movesay_admin` VALUES ('4', '', 'movesay', '', '', '0192023a7bbd73250516f069df18b500', '0', '0', '0', '0', '0', '1');
INSERT INTO `movesay_admin` VALUES ('6', '', 'btc100', '大一', '', '123456', '0', '1467289686', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `movesay_adver`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_adver`;
CREATE TABLE `movesay_adver` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `url` varchar(255) NOT NULL,
  `img` varchar(250) NOT NULL,
  `type` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='广告图片表';

-- -----------------------------
-- Records of `movesay_adver`
-- -----------------------------
INSERT INTO `movesay_adver` VALUES ('15', '最专业的交易平台', '', '5775e5ad38f6d.jpg', '', '0', '0', '0', '1');
INSERT INTO `movesay_adver` VALUES ('3', '幻灯片', 'http://54.238.188.201/Article/detail/id/5.html', '56f9942f9b5db.jpg', 'index', '0', '1446829556', '0', '1');

-- -----------------------------
-- Table structure for `movesay_article`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_article`;
CREATE TABLE `movesay_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `adminid` int(10) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `hits` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `type` (`type`),
  KEY `adminid` (`adminid`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COMMENT='系统文章表';

-- -----------------------------
-- Records of `movesay_article`
-- -----------------------------
INSERT INTO `movesay_article` VALUES ('1', '办公环境', '<p>\r\n	<span style=\"font-size:16px;\">2016年6月11日正式上线</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>', '1', 'aboutus', '0', '0', '1447196517', '0', '1');
INSERT INTO `movesay_article` VALUES ('2', '法律声明', '<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<br />\r\n</p>', '1', 'aboutus', '0', '0', '1447196754', '0', '1');
INSERT INTO `movesay_article` VALUES ('3', '用户协议', '', '1', 'aboutus', '0', '0', '1447196832', '0', '1');
INSERT INTO `movesay_article` VALUES ('4', '资质证明', '', '1', 'aboutus', '0', '0', '1447196898', '0', '1');
INSERT INTO `movesay_article` VALUES ('5', '联系我们', '', '1', 'aboutus', '0', '0', '1447197626', '0', '1');
INSERT INTO `movesay_article` VALUES ('6', '关于我们', '', '1', 'aboutus', '0', '0', '1441733195', '0', '1');
INSERT INTO `movesay_article` VALUES ('8', '新人必看--登录注册详细说明', '', '1', 'help', '0', '0', '0', '0', '1');
INSERT INTO `movesay_article` VALUES ('9', '新人必看--平台交易详细说明', '', '1', 'help', '0', '0', '1447197238', '0', '1');
INSERT INTO `movesay_article` VALUES ('10', '新人必看--自助充值详细说明', '目前支持支付宝充值 &nbsp;充值成功后立即到账&nbsp;', '1', 'help', '0', '0', '1447197283', '0', '1');
INSERT INTO `movesay_article` VALUES ('11', '新人必看--申请提现详细说明', '关于提现说明 每次提现收取1%手续费 &nbsp;需要完成实名认证', '1', 'help', '0', '0', '1447197343', '0', '1');
INSERT INTO `movesay_article` VALUES ('12', '新人必看--修改密码详细说明', '即将公布', '1', 'help', '0', '0', '1447197369', '0', '1');
INSERT INTO `movesay_article` VALUES ('13', '新人必看--实名认证详细说明', '', '1', 'help', '0', '0', '1447196898', '0', '1');
INSERT INTO `movesay_article` VALUES ('21', '这里是最新公告', '', '1', 'notice', '0', '0', '1452514770', '0', '1');
INSERT INTO `movesay_article` VALUES ('26', '新人必看--应用中心详细说明', '', '1', 'help', '0', '0', '1447196898', '0', '1');
INSERT INTO `movesay_article` VALUES ('27', '这是帮助中心文章', '', '1', 'help', '0', '0', '1452514759', '0', '1');
INSERT INTO `movesay_article` VALUES ('30', '这是行业资讯文章', '', '1', 'news', '0', '0', '1452514748', '0', '1');
INSERT INTO `movesay_article` VALUES ('32', '这里是最新公告', '', '1', 'notice', '0', '0', '1452514770', '0', '1');
INSERT INTO `movesay_article` VALUES ('49', '这里是最新公告', '', '1', 'notice', '0', '0', '1452514770', '0', '1');
INSERT INTO `movesay_article` VALUES ('50', '2016年6月16日提现到账公告', '', '1', 'news', '0', '0', '1447196898', '0', '1');
INSERT INTO `movesay_article` VALUES ('64', '优特币即将上线', '优特币即将上线', '1', 'notice', '0', '0', '1447196898', '0', '1');
INSERT INTO `movesay_article` VALUES ('65', '区块链上的分布式物联网', '<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	想象一下你的洗衣机，当洗涤剂不够时可以自动联系供应商，并进行自助下订单购物，进行自我维护，从外部资源处下载新的洗衣程序，根据电价的变化周期来安排最经济的洗衣计划表，还能和它的传感器互动来决定最优化的洗衣环境；再想象一辆汽车，实时联网，可以智能的选择最合适的零件和服务；还有这样的制造厂，它们的机械在没有人工干预的情况下，知道自己的哪个部位什么时候需要修理。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	以上的这些场景，在物联网（the Internet of Things IoT）的帮助下将会成为现实。事实上，那些曾不适应电脑的的产业已经被数十亿计的连接互联网的物联网设备改变；还没有被改变的产业，最终将在这样的浪潮中被迫跟上这种步伐。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	<img src=\"http://7xqy72.com1.z0.glb.clouddn.com/public/resources/pic/news/2016/06/30/c0h1pzUyRV_IoT.jpg\" style=\"height:auto;\" />\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	未来的可能性是无限的，特别是当物联网和其它技术结合所产生的力量，比如和机器学习结合。然而，数十亿的智能设备之间想要产生互动，或者和它们的拥有者互动，那么就会出现一些大问题。当现存的支持物联网通信的模型无法应对这样的挑战时，相关的技术公司和一些研究人员希望通过区块链技术来解决它们，这个技术就是大名鼎鼎的<a name=\"tuilink_a_5dfe53e3dre3\" href=\"http://www.tuiunion.com/tuilink/redirect/8/?domain=www.btckan.com\" target=\"_black\">比特币</a>背后的基石。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	<strong>中心化模型的问题</strong>\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	当前的物联网生态依赖于中心化系统，中介通信模型，也就是我们熟知的服务器/客户端（server/client）模型。拥有巨大计算能力和存储空间的云服务器与被标记和验证的设备相连。设备间的只通过互联网连接，即使它们只相隔几英尺。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	这种模型在通用的计算设备连接中运行了几十年，它还会存在于小规模的物联网网络中，正如我们现在所看到的那些。然而在未来逐渐增长为大规模的物联网生态上，这种模型就会显得无能了。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	现存的物联网方案是昂贵的，因为它的基础设施和维护费用极高，它需要中心云服务、大规模服务器集群和网络设备。当物联网设备以数十亿级别的速度增长时，它们之间要处理的通信量更是惊人，这样以来的费用会大幅度的增长。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	即使这种经济上和工程上的挑战不是问题，那么云服务器依然存在瓶颈，还有就是它出现一个故障点就会导致整个网络的崩溃。如果将来人类的生命健康依赖于物联网，那么这个问题就非常非常的严重。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	另外，不同设备间的多样化所有权，和它们支持的云服务架构多元化让机器对机器（machine-to-machine M2M）通信很困难。没有一个单独的设备可以连接其他所有设备，不同的云服务提供商也不会保证它们之间的互操作性和兼容性。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	<strong>分布式物联网（IoT）网络</strong>\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	物联网的分布式方案可以解决以上的很多问题。采用标准化的点对点通信模型处理成千上万设备间的交易，这有效的削减了成本，包括部署和维护大型数据中心的费用，而且可以通过成千上万的物联网设备把计算需求和存储需求去中心化。这将避免由于一个节点的失败而导致整个网络的崩溃。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	可是，建立点对点通信也有它自己的问题，其中首要问题是安全。我们都知道，物联网的安全不仅仅只是要保护敏感数据。解决方案必须在大规模物联网网络中保护隐私安全，还要为交易提供一些验证形式和共识形式，来避免被欺诈和偷盗。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	<strong>区块链方案</strong>\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	对于点对点通信平台问题，<a href=\"http://www.btckan.com/redirect?url=+http%3A%2F%2F8btc.com%2Farticle-44-1.html\">区块链</a>给出了精妙的解决方案，这种技术在网络节点间创建一种相互共享的分布式数字账簿，来记录交易，而不是把这些交易账簿存储于一个中心服务器。参与者通过区块链来记录交易。这个技术使用加密技术认证识别参与节点，保证它们安全的在账簿中添加交易记录。交易是被这个网络中的节点所验证和确认，所以这就消除了中心验证的必要性。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	这个账簿是防干扰和不可被恶意者修改的，因为它不单独存在于本地独立设备，它也不可能被中间人攻击，因为交易不是可被拦截的单独一个线程。区块链让去信任化、点对点通信成为现实，而且它在金融服务领域的价值已经通过加密货币（如<a name=\"tuilink_a_5dfe53e3dre3\" href=\"http://www.tuiunion.com/tuilink/redirect/8/?domain=www.btckan.com\" target=\"_black\">比特币</a>）证明，它在没有第三方支付参与的情况下为点对点支付做保障。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	科技公司现在试图让区块链的实用性与网联网领域磨合。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	这个概念可以直接解决物联网的规模化问题，不需要传统的昂贵资源就可以让数十亿计的设备共享于一个相同网络。区块链也可以解决不同供应商间的权威冲突，它提供了一个标准，让每个人有平等的权益。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	这将打通M2M(机器对机器)间的通信，在当前的模型中，这是无法实现的，这也让一些全新的使用案例成为现实。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	<strong>在物联网中混合使用区块链</strong>\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	物联网和区块链的结合正蓄势待发，创业公司和科技巨头都非常看好。IBM和三星引入他们的概念证明，ADEPT使用区块链技术支持下一代物联网生态，每天将会产生千亿计的交易。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	IBM作为最早研究把区块链用于物联网中的企业之一，IBM的Paul Brody 这样描述：新设备被工厂组装完成后在一个通用的区块链中注册，在被出售后转移进一个区域区块链，在这个区块链上它们可以与其它设备自主互动。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	物联网和区块链的结合让循环经济和资产流体化成为可能，资源可以被共享和再利用，而不是消费一次就处理掉。区块链平台领导者以太坊举办的物联网黑客马拉松中，一个区块链驱动的物联网概念被测试，其中还有很多非常有创意的项目，其中包括能源分享、电力燃气账单等领域中的项目。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	Filament是一个投身于物联网和区块链的创业公司，它专注于工业应用，像农业、制造业、石油和天然气等。Filament 使用一种名叫Taps的无线传感器，组成低功耗自治网状网络，来收集数据，监控资产，而且不需要云服务或中心网络服务器的参与。这家公司使用区块链技术识别认证设备，通过提供这样的网络和数据服务来获得收入，当然是以<a name=\"tuilink_a_5dfe53e3dre3\" href=\"http://www.tuiunion.com/tuilink/redirect/8/?domain=www.btckan.com\" target=\"_black\">比特币</a>为支付方式。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	Chain of Things 是一个联盟，他们的任务是探索区块链在处理物联网规模化和安全问题中所能扮演的角色。他们在最近伦敦举行的黑客马拉松中展示了区块链 和物联网的使用案例，包括一种太阳能堆栈设计，它可以提供可靠地、可验证的再生资源数据，加速刺激结算，减少其中的欺诈。这个系统加强了太阳能面板和数据记录器的连接过程，跟踪太阳能的生产量，安全的把这些数据提交给节点，节点把这些数据记录在分布式账簿中，然后在范围更广的全球节点网络同步。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	<strong>警示和挑战</strong>\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	把区块链技术应用于物联网并不是没有缺点的，还有一些问题需要解决。其一就是，在<a name=\"tuilink_a_5dfe53e3dre3\" href=\"http://www.tuiunion.com/tuilink/redirect/8/?domain=www.btckan.com\" target=\"_black\">比特币</a>开发者之间争吵不断的区块链基础问题，这个问题产生于，随着这个网络的发展，交易量和体积越来越大，当区块链技术应用于物联网时，这个问题也不可避免。科技公司也承认这是一种挑战，然而有一些解决方案正在测试，其中包括侧链、树链和迷你区块等方案。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	能源消耗也是一个问题，加密和验证区块链交易是一种计算力集约操作，需要消耗大量的电力资源，这是物联网设备所缺少的。与此同时，还需要较大的存储空间，随着账簿的增长，节点的存储空间需求也越来越大。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	还有，如Machina Research 的研究者 Jeremy Green所说，以区块链作为驱动的自治物联网对制造商来说，最大的挑战时寻求一种商业模型，其中包括持续盈利的长期合作伙伴，而且需要一个商业和经济模型的大转型。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	物联网产业发展飞速，区块链是否是解决物联网面临的困难的关键，现在下结论还为时过早。它还不完美，然而与物联网结合非常的有希望，分布式自治网络将成为解决问题的关键因素。\r\n</p>', '1', 'news', '0', '0', '1467287166', '0', '1');

-- -----------------------------
-- Table structure for `movesay_article_type`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_article_type`;
CREATE TABLE `movesay_article_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `index` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='分组分类别';

-- -----------------------------
-- Records of `movesay_article_type`
-- -----------------------------
INSERT INTO `movesay_article_type` VALUES ('1', 'news', '行业资讯', '行业资讯', '1', '2', '0', '0', '1');
INSERT INTO `movesay_article_type` VALUES ('2', 'notice', '最新公告', '最新公告', '1', '1', '0', '0', '1');
INSERT INTO `movesay_article_type` VALUES ('3', 'help', '帮助中心', '帮助中心', '1', '3', '0', '0', '1');
INSERT INTO `movesay_article_type` VALUES ('4', 'aboutus', '关于我们', '关于我们', '0', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `movesay_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_auth_extend`;
CREATE TABLE `movesay_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_auth_extend`
-- -----------------------------
INSERT INTO `movesay_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `movesay_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `movesay_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `movesay_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `movesay_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `movesay_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `movesay_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `movesay_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `movesay_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_auth_group`;
CREATE TABLE `movesay_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_auth_group`
-- -----------------------------
INSERT INTO `movesay_auth_group` VALUES ('1', 'admin', '1', '资讯管理员', '拥有网站文章资讯相关权限', '1', '424,426,431,441,446,449,453,461,475,501,502,503,508,509,510,515,516');
INSERT INTO `movesay_auth_group` VALUES ('3', 'admin', '1', '超级管理员', '超级管理员组,拥有系统所有权限', '1', '424,426,431,433,434,435,436,437,438,439,440,441,443,444,445,446,447,448,449,450,451,452,453,454,455,456,458,459,460,461,462,463,465,466,467,469,470,471,473,474,475,476,477,479,480,481,482,484,485,486,487,488,489,490,491,492,493,494,495,496,497,498,499,500,501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518,519,520,521,522,523,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539,540,541,542,543,544,545,546,547,548,549');
INSERT INTO `movesay_auth_group` VALUES ('2', 'admin', '1', '财务管理组', '拥有网站资金相关的权限', '1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195');
INSERT INTO `movesay_auth_group` VALUES ('4', 'admin', '1', '资讯管理员', '拥有网站文章资讯相关权限11', '-1', '');
INSERT INTO `movesay_auth_group` VALUES ('5', 'admin', '1', '资讯管理员', '拥有网站文章资讯相关权限', '1', '');
INSERT INTO `movesay_auth_group` VALUES ('6', 'admin', '1', '财务管理组', '拥有网站资金相关的权限333', '1', '');

-- -----------------------------
-- Table structure for `movesay_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_auth_group_access`;
CREATE TABLE `movesay_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_auth_group_access`
-- -----------------------------
INSERT INTO `movesay_auth_group_access` VALUES ('2', '3');
INSERT INTO `movesay_auth_group_access` VALUES ('3', '1');

-- -----------------------------
-- Table structure for `movesay_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_auth_rule`;
CREATE TABLE `movesay_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=134 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_bazaar`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_bazaar`;
CREATE TABLE `movesay_bazaar` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `coin` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `deal` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `fee` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='集市交易表';


-- -----------------------------
-- Table structure for `movesay_bazaar_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_bazaar_log`;
CREATE TABLE `movesay_bazaar_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `peerid` int(11) unsigned NOT NULL,
  `coin` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `fee` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`),
  KEY `peerid` (`peerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='集市交易记录表';


-- -----------------------------
-- Table structure for `movesay_category`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_category`;
CREATE TABLE `movesay_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `movesay_category`
-- -----------------------------
INSERT INTO `movesay_category` VALUES ('1', 'blog', '默认', '0', '0', '10', '', '', '', '', '', '', '', '2', '2,1', '0', '0', '1', '0', '0', '1', '', '1379474947', '1382701539', '1', '0');
INSERT INTO `movesay_category` VALUES ('2', 'default_blog', '默认分类', '1', '1', '10', '', '', '', '', '', '', '', '2', '2,1,3', '0', '1', '1', '0', '1', '1', '', '1379475028', '1386839751', '1', '31');

-- -----------------------------
-- Table structure for `movesay_chat`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_chat`;
CREATE TABLE `movesay_chat` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` varchar(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文字聊天表';


-- -----------------------------
-- Table structure for `movesay_coin`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_coin`;
CREATE TABLE `movesay_coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `img` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `fee_bili` varchar(50) NOT NULL,
  `endtime` int(11) unsigned NOT NULL COMMENT '',
  `addtime` int(11) unsigned NOT NULL,
  `status` int(4) unsigned NOT NULL,
  `dj_zj` varchar(200) NOT NULL,
  `dj_dk` varchar(200) NOT NULL,
  `dj_yh` varchar(200) NOT NULL,
  `dj_mm` varchar(200) NOT NULL,
  `zr_zs` varchar(50) NOT NULL,
  `zr_jz` varchar(50) NOT NULL,
  `zr_dz` varchar(50) NOT NULL,
  `zr_sm` varchar(50) NOT NULL,
  `zc_sm` varchar(50) NOT NULL,
  `zc_fee` varchar(50) NOT NULL,
  `zc_user` varchar(50) NOT NULL,
  `zc_min` varchar(50) NOT NULL,
  `zc_max` varchar(50) NOT NULL,
  `zc_jz` varchar(50) NOT NULL,
  `zc_zd` varchar(50) NOT NULL,
  `js_yw` varchar(50) NOT NULL,
  `js_sm` text NOT NULL,
  `js_qb` varchar(50) NOT NULL,
  `js_ym` varchar(50) NOT NULL,
  `js_gw` varchar(50) NOT NULL,
  `js_lt` varchar(50) NOT NULL,
  `js_wk` varchar(50) NOT NULL,
  `cs_yf` varchar(50) NOT NULL,
  `cs_sf` varchar(50) NOT NULL,
  `cs_fb` varchar(50) NOT NULL,
  `cs_qk` varchar(50) NOT NULL,
  `cs_zl` varchar(50) NOT NULL,
  `cs_cl` varchar(50) NOT NULL,
  `cs_zm` varchar(50) NOT NULL,
  `cs_nd` varchar(50) NOT NULL,
  `cs_jl` varchar(50) NOT NULL,
  `cs_ts` varchar(50) NOT NULL,
  `cs_bz` varchar(50) NOT NULL,
  `tp_zs` varchar(50) NOT NULL,
  `tp_js` varchar(50) NOT NULL,
  `tp_yy` varchar(50) NOT NULL,
  `tp_qj` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COMMENT='币种配置表';

-- -----------------------------
-- Records of `movesay_coin`
-- -----------------------------
INSERT INTO `movesay_coin` VALUES ('1', 'cny', 'rmb', '人民币', 'cny.png', '0', '', '0', '0', '1', '182.254.134.191', '0', '0', '0', '0', '1', '0', '0', '0', '', '', '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `movesay_coin` VALUES ('43', 'btc', 'qbb', '比特币', '5774fdc823ff6.jpg', '0', '100', '0', '0', '1', '', '', '', '', '0', '1', '1', '', '', '0', '0', '0', '10000', '1', '10', 'bitcoin', '<div class=\"para\" style=\"font-size:14px;color:#333333;font-family:arial, 宋体, sans-serif;background-color:#FFFFFF;\">\r\n	比特币（BitCoin）的概念最初由中本聪在2009年提出，根据中本聪的思路设计发布的开源软件以及建构其上的<a target=\"_blank\" href=\"http://baike.baidu.com/view/3280.htm\">P2P</a>网络。比特币是一种P2P形式的数字货币。点对点的传输意味着一个去中心化的支付系统。\r\n</div>\r\n<div class=\"para\" style=\"font-size:14px;color:#333333;font-family:arial, 宋体, sans-serif;background-color:#FFFFFF;\">\r\n	与大多数货币不同，比特币不依靠特定货币机构发行，它依据特定算法，通过大量的计算产生，比特币经济使用整个P2P网络中众多节点构成的<a target=\"_blank\" href=\"http://baike.baidu.com/view/68389.htm\">分布式数据库</a>来确认并记录所有的交易行为，并使用密码学的设计来确保货币流通各个环节<a target=\"_blank\" href=\"http://baike.baidu.com/view/421194.htm\">安全性</a>。P2P的去中心化特性与算法本身可以确保无法通过大量制造比特币来人为操控币值。基于密码学的设计可以使比特币只能被真实的拥有者转移或支付。这同样确保了货币所有权与流通交易的匿名性。比特币与其他<a target=\"_blank\" href=\"http://baike.baidu.com/view/16260.htm\">虚拟货币</a>最大的不同，是其总数量非常有限，具有极强的稀缺性。该货币系统曾在4年内只有不超过1050万个，之后的总数量将被永久限制在2100万个。\r\n</div>\r\n<div class=\"para\" style=\"font-size:14px;color:#333333;font-family:arial, 宋体, sans-serif;background-color:#FFFFFF;\">\r\n	比特币可以用来兑现，可以兑换成大多数国家的货币。使用者可以用比特币购买一些<a target=\"_blank\" href=\"http://baike.baidu.com/view/73493.htm\">虚拟物品</a>，比如网络游戏当中的衣服、<a target=\"_blank\" href=\"http://baike.baidu.com/view/54792.htm\">帽子</a>、装备等，只要有人接受，也可以使用比特币购买现实生活当中的物品。\r\n</div>', 'https://bitcoin.org/en/download', 'https://github.com/bitcoin/bitcoin', 'https://bitcoin.org', 'https://bitcointalk.org', 'https://en.bitcoin.it/wiki/Comparison_of_mining_po', 'Dorian S. Nakamoto', 'SHA-256', '2009/01/09', '600秒/块', '21000000', '14750000', '', '', '50', '虚拟币始创者，受众最广，被信任最高', '确认时间长', '1', '5', '5', '5');
INSERT INTO `movesay_coin` VALUES ('44', 'ltc', 'qbb', '莱特币', '5774fef268879.png', '0', '0', '0', '0', '1', '', '', '', '', '0', '1', '3', '', '', '0.01', '0', '0', '10000', '1', '100', 'Litecoin', '<div class=\"para\" style=\"font-size:14px;color:#333333;font-family:arial, 宋体, sans-serif;background-color:#FFFFFF;\">\r\n	莱特币Litecoin（简写：LTC，货币符号：Ł<span style=\"font-weight:700;\"></span>）是一种基于“点对点”(peer-to-peer)技术的<a target=\"_blank\" href=\"http://baike.baidu.com/view/1490463.htm\">网络货币</a>，也是MIT/X11许可下的一个开源软件项目。它可以帮助用户即时付款给世界上任何一个人。\r\n</div>\r\n<div class=\"para\" style=\"font-size:14px;color:#333333;font-family:arial, 宋体, sans-serif;background-color:#FFFFFF;\">\r\n	莱特币受到了<a target=\"_blank\" href=\"http://baike.baidu.com/subview/5784548/12216829.htm\">比特币</a>（BTC）的启发，并且在技术上具有相同的实现原理，莱特币的创造和转让基于一种开源的加密协议，不受到任何中央机构的管理。莱特币旨在改进比特币，与其相比，莱特币具有三种显著差异。第一，莱特币网络每2.5分钟（而不是10分钟）就可以处理一个块，因此可以提供更快的交易确认。第二，莱特币网络预期产出8400万个莱特币，是比特币网络发行货币量的四倍之多。第三，莱特币在其工作量证明算法中使用了由Colin Percival首次提出的scrypt加密算法，这使得相比于比特币，在普通计算机上进行莱特币挖掘更为容易。每一个莱特币被分成100,000,000个更小的单位，通过八位小数来界定。\r\n</div>', 'https://litecoin.org/zh_CN/', 'https://github.com/litecoin-project', 'https://litecoin.org/', 'http://explorer.litecoin.net/', 'https://litecointalk.org/', 'Charls Lee', 'Scrypt', '2011/10/7', '150秒/块', '84000000', '35123000', 'PoW', '2016 Blocks', '50LTC', '人气高、国内几大交易网站支持、开发能力强', '推广止步不前', '1', '5', '5', '5');
INSERT INTO `movesay_coin` VALUES ('45', 'ytc', 'qbb', '优特币', '577500d69d49f.png', '0', '100', '0', '0', '1', '', '', '', '', '0', '1', '1', '', '', '0.01', '0', '0', '10000', '1', '100', 'yotcoin', '', '', '', '', '', '', '', '', '', '15S', '', '', '', '', '', '', '', '1', '5', '5', '5');

-- -----------------------------
-- Table structure for `movesay_coin_comment`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_coin_comment`;
CREATE TABLE `movesay_coin_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `content` varchar(500) NOT NULL,
  `cjz` int(11) unsigned NOT NULL,
  `tzy` int(11) unsigned NOT NULL,
  `xcd` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_coin_comment`
-- -----------------------------
INSERT INTO `movesay_coin_comment` VALUES ('1', '2', 'ltc', '莱特是银', '0', '0', '0', '0', '1467291380', '0', '1');
INSERT INTO `movesay_coin_comment` VALUES ('2', '2', 'btc', '比特是金', '0', '0', '0', '0', '1467291420', '0', '1');
INSERT INTO `movesay_coin_comment` VALUES ('3', '2', 'ytc', '优特好', '0', '0', '0', '0', '1467291676', '0', '1');

-- -----------------------------
-- Table structure for `movesay_config`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_config`;
CREATE TABLE `movesay_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `web_name` varchar(200) NOT NULL,
  `web_title` varchar(200) NOT NULL,
  `web_logo` varchar(200) NOT NULL,
  `web_llogo_small` varchar(200) NOT NULL,
  `web_keywords` varchar(200) NOT NULL,
  `web_description` varchar(200) NOT NULL,
  `web_close` varchar(50) NOT NULL,
  `web_close_cause` varchar(200) NOT NULL,
  `web_icp` varchar(50) NOT NULL,
  `web_cnzz` text NOT NULL,
  `web_reg` text NOT NULL,
  `web_waring` text NOT NULL,
  `market_mr` varchar(50) NOT NULL,
  `xnb_mr` varchar(50) NOT NULL,
  `rmb_mr` varchar(50) NOT NULL,
  `moble_type` text NOT NULL,
  `moble_url` text NOT NULL,
  `moble_user` text NOT NULL,
  `moble_pwd` text NOT NULL,
  `contact_moble` text NOT NULL,
  `contact_weibo` text NOT NULL,
  `contact_tqq` text NOT NULL,
  `contact_qq` text NOT NULL,
  `contact_qqun` text NOT NULL,
  `contact_weixin` text NOT NULL,
  `contact_weixin_img` text NOT NULL,
  `contact_email` text NOT NULL,
  `contact_alipay` text NOT NULL,
  `contact_alipay_img` text NOT NULL,
  `contact_bank` text NOT NULL,
  `user_truename` text NOT NULL,
  `user_moble` text NOT NULL,
  `user_alipay` text NOT NULL,
  `user_bank` text NOT NULL,
  `mycz_min` text NOT NULL,
  `mycz_max` text NOT NULL,
  `mytx_min` text NOT NULL,
  `mytx_max` text NOT NULL,
  `mytx_bei` text NOT NULL,
  `mytx_coin` text NOT NULL,
  `mytx_fee` text NOT NULL,
  `trade_min` text NOT NULL,
  `trade_max` text NOT NULL,
  `trade_limit` text NOT NULL,
  `trade_text_index` text NOT NULL,
  `trade_text_entrust` text NOT NULL,
  `trade_text_log` text NOT NULL,
  `issue_ci` text NOT NULL,
  `issue_jian` text NOT NULL,
  `issue_min` text NOT NULL,
  `issue_max` text NOT NULL,
  `money_min` text NOT NULL,
  `money_max` text NOT NULL,
  `money_bei` text NOT NULL,
  `invit_type` text NOT NULL,
  `invit_fee1` text NOT NULL,
  `invit_fee2` text NOT NULL,
  `invit_fee3` text NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  `index_html` varchar(50) DEFAULT NULL,
  `invit_text_txt` text,
  `top_name` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- -----------------------------
-- Records of `movesay_config`
-- -----------------------------
INSERT INTO `movesay_config` VALUES ('1', '优特科技', '优特交易平台', '577503b00ff3b.jpg', '577503b0101f5.png', '优特币交易所,比特币交易平台，莱特币交易平台', '优特币交易所', '0', '升级中...', '粤ICP备88888888号-1', '<script type=\"text/javascript\">var cnzz_protocol = ((\"https:\" == document.location.protocol) ? \" https://\" : \" http://\");document.write(unescape(\"%3Cspan id=\'cnzz_stat_icon_1256773398\'%3E%3C/span%3E%3Cscript src=\'\" + cnzz_protocol + \"s11.cnzz.com/z_stat.php%3Fid%3D1256773398\' type=\'text/javascript\'%3E%3C/script%3E\"));</script>', '<div style=\"text-align:center;\">\r\n	<div style=\"text-align:left;\">\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			用户协议\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; &nbsp; &nbsp;优特科技交易平台所提供的各项服务的所有权和运作权均归优特科技有限公司所有。优特科技交易平台用户注册使用协议（以下简称“本协议”） 系由优特科技交易平台用户与优特科技有限公司就优特科技交易平台的各项服务所订立的相关权利义务规范。用户通过访问或使用本网站， 即表示接受并同意本协议的所有条件和条款。优特科技有限公司作为优特科技交易平台的运营者依据本协议为用户提供服务。不愿接受本协议条款的， 不得访问或使用本网站。优特科技有限公司有权对本协议条款进行修改，修改后的协议一旦公布即有效代替原来的协议。用户可随时查阅最新协议。\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			服务内容\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、优特科技有限公司运用自己的系统，通过互联网络等方式为用户提供优特科技的交易服务。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、用户必须自行准备如下设备和承担如下开支：&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ①上网设备，包括并不限于电脑或者其他上网终端、调制解调器及其他上网装置。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ②上网开支，包括并不限于网络接入费、上网设备租用费、手机流量费等。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			3、用户提供的注册资料，用户必须同意：\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ①提供中华人民共和国大陆地区合法、真实、准确、详尽的个人资料。\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ②如有变动，及时更新用户资料。如果用户提供的注册资料不合法、不真实、不准确、不详尽的，用户需承担因此引起的相应责任及后果， 并且优特科技有限公司保留终止用户使用优特科技交易平台各项服务的权利。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			服务的提供、修改及终止\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、用户在接受优特科技交易平台各项服务的同时，同意接受优特科技交易平台提供的各类信息服务。 用户在此授权优特科技有限公司可以向其电子邮件、手机、通信地址等发送商业信息。 用户有权选择不接受优特科技交易平台提供的各类信息服务，并进入优特科技交易平台相关页面进行更改。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、优特科技交易平台保留随时修改或中断服务而不需通知用户的权利。优特科技交易平台有权行使修改或中断服务的权利， 不需对用户或任何无直接关系的第三方负责。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			3、用户对本协议的修改有异议，或对优特科技交易平台的服务不满，可以行使如下权利：&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ①停止使用优特科技交易平台的网络服务。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ②通过客服等渠道告知优特科技交易平台停止对其服务。 结束服务后，用户使用优特科技交易平台网络服务的权利立即终止。 在此情况下，优特科技交易平台没有义务传送任何未处理的信息或未完成的服务给用户或任何无直接关系的第三方。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			用户信息的保密\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、本协议所称之优特科技交易平台用户信息是指符合法律、法规及相关规定，并符合下述范围的信息：\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ①用户注册优特科技账户时，向优特科技交易平台提供的个人信息。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ②用户在使用优特科技交易平台服务、参加网站活动或访问网站网页时，优特科技交易平台自动接收并记录的用户浏览器端或手机客户端数据， 包括但不限于IP地址、网站中的资料及用户要求取用的网页记录。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ③优特科技交易平台从商业伙伴处合法获取的用户个人信息。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ④其它优特科技交易平台通过合法途径获取的用户个人信息。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、优特科技有限公司承诺：非经法定原因或用户事先许可，不会向任何第三方透露用户的密码、姓名、 手机号码等非公开信息。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			3、在下述法定情况下，用户的个人信息将会被部分或全部披露：&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ①经用户同意向用户本人或其他第三方披露。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ②根据法律、法规等相关规定，或行政机构要求，向行政、司法机构或其他法律规定的第三方披露。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ③其它优特科技有限公司根据法律、法规等相关规定进行的披露。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			用户权利\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、用户的用户名、密码和安全性：&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ①用户有权选择是否成为优特科技交易平台用户，用户选择成为优特科技交易平台注册用户时，可自行输入手机号为帐号。 用户名和帐号使用应遵守相关法律法规并符合网络道德。用户名和帐号中不能含有任何侮辱、威胁、淫秽、 谩骂等侵害他人合法权益的文字。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp;②用户一旦注册成功，成为优特科技交易平台的用户，将得到用户名和密码， 并对以此组用户名和密码登入系统后所发生的所有活动和事件负责，自行承担一切使用该用户名的言语、 行为等而直接或者间接导致的法律责任。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp;③用户有义务妥善保管优特科技交易平台账号、用户名和密码，用户将对用户名和密码安全负全部责任。 因用户原因导致用户名或密码泄露而造成的任何法律后果由用户本人负责，由于用户自身原因泄露这些信息导致的财产损失， 本站不负相关责任。由于本站是交易网站，登录密码、提现密码、交易密码等不得使用相同密码，否则会有安全隐患， 相关责任由用户自身承担。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			④用户密码遗失的，可以通过绑定的手机号码重置密码。用户若发现任何非法使用用户名或存在其他安全漏洞的情况， 应立即告知优特科技交易平台运营平台。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑤优特科技交易平台不会向任何用户索取密码，不会让用户往任何非本站交易中心里提供的帐户打款， 请大家不要相信任何非优特科技有限公司提供的打折、优惠等诈骗信息，往非优特科技交易平台提供的账户、 地址里打款或币造成的损失本站不负责任。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、用户有权根据网站相关规定，在发布信息等贡献后，取得优特科技交易平台给予的奖励。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			3、用户有权修改其个人账户中各项可修改信息，自行录入介绍性文字，自行决定是否提供非必填项的内容。4、用户有权参加优特科技交易平台组织提供的各项线上、线下活动。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			5、用户有权根据优特科技交易平台网站规定，享受优特科技交易平台提供的其它各类服务。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			用户义务\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、不得利用本站危害国家安全、泄露国家秘密，不得侵犯国家社会集体的和公民的合法权益，不得利用本站制作、 复制和传播下列信息：&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			①煽动抗拒、破坏宪法和法律、行政法规实施的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			②煽动颠覆国家政权，推翻社会主义制度的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			③煽动分裂国家、破坏国家统一的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			④煽动民族仇恨、民族歧视，破坏民族团结的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑤捏造或者歪曲事实，散布谣言，扰乱社会秩序的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑥宣扬封建迷信、淫秽、色情、赌博、暴力、凶杀、恐怖、教唆犯罪的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑦公然侮辱他人或者捏造事实诽谤他人的，或者进行其他恶意攻击的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑧损害国家机关信誉的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑨其他违反宪法和法律行政法规的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑩进行商业广告行为的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、用户不得通过任何手段恶意注册优特科技交易平台网站帐号，包括但不限于以牟利、炒作、套现、 获奖等为目的多个账号注册。用户亦不得盗用其他用户帐号,或者利用优特科技交易平台以及交易平台漏洞刷取优特科技。 如用户违反上述规定，则优特科技交易平台有权直接采取一切必要的措施，包括但不限于删除用户发布的内容、 取消用户在网站获得的虚拟财富，暂停或查封用户帐号，取消因违规所获利益，乃至通过诉讼形式追究用户法律责任等。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			3、禁止用户将优特科技交易平台以任何形式作为从事各种非法活动的场所、平台或媒介。 未经优特科技交易平台运营平台的授权或许可，用户不得借用本站的名义从事任何商业活动， 也不得以任何形式将优特科技交易平台作为从事商业活动的场所、平台或媒介。如用户违反上述规定， 则优特科技交易平台运营平台有权直接采取一切必要的措施，包括但不限于删除用户发布的内容、取消用户在网站获得的虚拟财富， 暂停或查封用户帐号，取消因违规所获利益，乃至通过诉讼形式追究用户法律责任等。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			4、用户在优特科技交易平台以各种形式发布的一切信息，均应符合国家法律法规等相关规定及网站相关规定， 符合社会公序良俗，并不侵犯任何第三方主体的合法权益，否则用户自行承担因此产生的一切法律后果， 且优特科技有限公司因此受到的损失，有权向用户追偿。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			5、按照优特科技有限公司的要求准确提供并及时更新您正确、最新及完整的身份信息及相关资料。 若优特科技有限公司有合理理由怀疑您提供的身份信息即相关资料错误、不实、过失或不完整的， 优特科技有限公司有权要求您补充相关资料来证明您身份的真实性。若您不能及时配合提供， 优特科技有限公司有权暂停或终止向您提供服务。优特科技有限公司对此不承担任何责任， 您将承担因此产生的任何直接或间接支出。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			6、用户应当有独立的风险承担能力，以及具备相应的民事行为能力，注册实名认证用户应为中国大陆地区公民， 年龄限制在16周岁~70周岁。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			拒绝担保与免责\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、优特科技交易平台作为“网络服务提供者”的第三方平台，不担保网站平台上的信息及服务能充分满足用户的需求。 对于用户在接受优特科技交易平台的服务过程中可能遇到的错误、侮辱、诽谤、不作为、淫秽、色情或亵渎事件， 优特科技交易平台不承担法律责任。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、基于互联网的特殊性，优特科技交易平台也不担保服务不会受中断，对服务的及时性、安全性都不作担保， 不承担非因优特科技交易平台导致的责任。 优特科技交易平台力图使用户能对本网站进行安全访问和使用， 但优特科技交易平台不声明也不保证本网站或其服务器是不含病毒或其它潜在有害因素的。 因此用户应使用业界公认的软件查杀任何自优特科技交易平台下载文件中的病毒。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			3、优特科技交易平台不对用户所发布信息的保存、修改、删除或储存失败负责。 对网站上的非因优特科技交易平台故意所导致的排字错误、疏忽等不承担责任。 优特科技交易平台有权但无义务， 改善或更正本网站任何部分之疏漏、错误。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			4、除非优特科技交易平台以书面形式明确约定，优特科技交易平台对于用户以任何方式（包括但不限于包含、经由、连接或下载 ）从本网站所获得的任何内容信息，包括但不限于广告等，不保证其准确性、完整性、可靠性； 对于用户因本网站上的内容信息而购买、获取的任何产品、服务、信息或资料，优特科技交易平台不承担责任。 用户自行承担使用本网站信息内容所导致的风险。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			5、优特科技交易平台内所有用户所发表的用户评论，仅代表用户个人观点， 并不表示本网站赞同其观点或证实其描述，本网站不承担用户评论引发的任何法律责任。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			6、优特科技有限公司有权删除优特科技交易平台内各类不符合法律或协议规定的信息，而保留不通知用户的权利。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			7、所有发给用户的通告，优特科技交易平台都将通过正式的页面公告、站内信、电子邮件、客服电话、 手机短信或常规的信件送达。任何非经优特科技交易平台正规渠道获得的中奖、优惠等活动或信息， 优特科技交易平台不承担法律责任。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			适用法律和裁判地点\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、因用户使用优特科技交易平台而引起或与之相关的一切争议、权利主张或其它事项， 均受中华人民共和国法律的管辖。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、用户和优特科技有限公司发生争议的，应首先本着诚信原则通过协商加以解决。 如果协商不成，则应向优特科技有限公司所在地人民法院提起诉讼。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			可分性\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			如果本协议的任何条款被视为不合法、无效或因任何原因而无法执行，则此等规定应视为可分割， 不影响任何其它条款的法律效力。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			冲突选择\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			本协议是优特科技有限公司与用户注册成为优特科技交易平台用户，使用优特科技交易平台服务之间的重要法律文件， 优特科技有限公司或者用户的任何其他书面或者口头意思表示与本协议不一致的，均应当以本协议为准。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 优特科技有限公司\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;\r\n&nbsp; 2016年6月1日\r\n		</p>\r\n<br />\r\n	</div>\r\n</div>\r\n<p>\r\n	<span style=\"font-size:10px;color:#E56600;\"></span> \r\n</p>', '数字资产的交易存在极高风险(预挖、暴涨暴跌、庄家操控、团队解散、技术缺陷等)，作为全球的虚拟数字货币，他们都是全天24小时交易，没有涨跌限制，价格容易因为庄家、全球政府的政策影响而大幅波动，我们强烈建议您在自身能承受的风险范围内，参与虚拟货币交易，动说网仅为数字货币的爱好者提供一个自由的网上交换平台，对币的投资价值不承担任何审查、担保、赔偿的责任，如果您不能接受，请不要进行交易！谢谢！', 'btc_cny', 'btc', 'cny', '1', 'http://utf8.sms.webchinese.cn', '', '', '13888888888', 'http://weibo.com/', 'http://t.qq.com/', '88888888|88888888', '00000000|22222222', '888888888', '577504af69bde.png', '88888888@qq.com', '88888888@qq.com', '577504af69fc0.png', '中国银行|优特科技|0000 0000 0000 0000', '2', '2', '2', '2', '10', '100000', '100', '10000', '100', 'cny', '1', '1', '10000000', '10', '', '&lt;span&gt;&lt;span&gt;长时间委托交易未成功的,自行点击--&lt;/span&gt;&lt;span style=&quot;color:#EE33EE;&quot;&gt;撤销&lt;/span&gt;&lt;span&gt;--重新定价委托,委托交易买入成功后,扣除相应的手续费,委托交易卖出&lt;/span&gt;&lt;span&gt;成功后,&lt;/span&gt;&lt;span&gt;扣除相应的手续费.&lt;/span&gt;&lt;/span&gt;', '&lt;span&gt;&lt;span&gt;你委托买入或者卖出成功交易后的记录.&lt;/span&gt;&lt;/span&gt;', '5', '24', '1', '100000', '100', '100000', '100', '1', '5', '3', '2', '1467352535', '0', 'index2', '优特科技666', '客户电话：4000-000-000 邮箱：APP@APP.com  工作日:9-19时 节假日:9-18时');

-- -----------------------------
-- Table structure for `movesay_fenhong`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_fenhong`;
CREATE TABLE `movesay_fenhong` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `coinjian` varchar(50) NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_fenhong_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_fenhong_log`;
CREATE TABLE `movesay_fenhong_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `coinjian` varchar(50) NOT NULL,
  `fenzong` varchar(50) NOT NULL,
  `fenchi` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_footer`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_footer`;
CREATE TABLE `movesay_footer` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_footer`
-- -----------------------------
INSERT INTO `movesay_footer` VALUES ('1', '1', '关于我们', '/Article/index/type/aboutus.html', '', '1', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('2', '1', '联系我们', '/Article/index/type/aboutus.html', '', '1', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('3', '1', '资质证明', '/Article/index/type/aboutus.html', '', '1', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('4', '1', '用户协议', '/Article/index/type/aboutus.html', '', '1', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('5', '1', '法律声明', '/Article/index/type/aboutus.html', '', '1', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('6', '1', '1', '/', 'footer_1.png', '2', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('7', '1', '1', 'http://www.szfw.org/', 'footer_2.png', '2', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('8', '1', '1', 'http://www.miibeian.gov.cn/', 'footer_3.png', '2', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('9', '1', '1', 'http://www.cyberpolice.cn/', 'footer_4.png', '2', '', '1', '111', '0', '1');

-- -----------------------------
-- Table structure for `movesay_invit`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_invit`;
CREATE TABLE `movesay_invit` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `invit` int(11) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `fee` decimal(20,8) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `invit` (`invit`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='推广奖励表';


-- -----------------------------
-- Table structure for `movesay_issue`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_issue`;
CREATE TABLE `movesay_issue` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `buycoin` varchar(50) NOT NULL,
  `num` bigint(20) unsigned NOT NULL,
  `deal` int(11) unsigned NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `limit` int(11) unsigned NOT NULL,
  `time` varchar(255) NOT NULL,
  `tian` varchar(255) NOT NULL,
  `ci` varchar(255) NOT NULL,
  `jian` varchar(255) NOT NULL,
  `min` varchar(255) NOT NULL,
  `max` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `invit_coin` varchar(50) NOT NULL,
  `invit_1` varchar(50) NOT NULL,
  `invit_2` varchar(50) NOT NULL,
  `invit_3` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`),
  KEY `coinname` (`coinname`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='认购发行表';

-- -----------------------------
-- Records of `movesay_issue`
-- -----------------------------
INSERT INTO `movesay_issue` VALUES ('1', '优特币第一期认购', 'ytc', 'cny', '5000000', '4254603', '0.01000000', '10000', '2016-06-30 00:00:00', '180', '5', '24', '', '', '这里是介绍', 'cny', '', '', '', '0', '1467290504', '0', '1');

-- -----------------------------
-- Table structure for `movesay_issue_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_issue_log`;
CREATE TABLE `movesay_issue_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `buycoin` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` int(20) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `ci` int(11) unsigned NOT NULL,
  `jian` varchar(255) NOT NULL,
  `unlock` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='认购记录表';

-- -----------------------------
-- Records of `movesay_issue_log`
-- -----------------------------
INSERT INTO `movesay_issue_log` VALUES ('1', '2', '优特币第一期认购', 'ytc', 'cny', '0.01000000', '100', '1.00000000', '5', '24', '1', '0', '1467292452', '1467292452', '0');

-- -----------------------------
-- Table structure for `movesay_link`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_link`;
CREATE TABLE `movesay_link` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL,
  `mytx` varchar(200) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='常用银行地址';

-- -----------------------------
-- Records of `movesay_link`
-- -----------------------------
INSERT INTO `movesay_link` VALUES ('4', 'boc', '中国银行', 'http://www.boc.cn/', 'img_56937003683ce.jpg', '', '', '0', '1452503043', '0', '1');
INSERT INTO `movesay_link` VALUES ('5', 'abc', '农业银行', 'http://www.abchina.com/cn/', 'img_569370458b18d.jpg', '', '', '0', '1452503109', '0', '1');
INSERT INTO `movesay_link` VALUES ('6', 'bccb', '北京银行', 'http://www.bankofbeijing.com.cn/', 'img_569370588dcdc.jpg', '', '', '0', '1452503128', '0', '1');
INSERT INTO `movesay_link` VALUES ('8', 'ccb', '建设银行', 'http://www.ccb.com/', 'img_5693709bbd20f.jpg', '', '', '0', '1452503195', '0', '1');
INSERT INTO `movesay_link` VALUES ('9', 'ceb', '光大银行', 'http://www.bankofbeijing.com.cn/', 'img_569370b207cc8.jpg', '', '', '0', '1452503218', '0', '1');
INSERT INTO `movesay_link` VALUES ('10', 'cib', '兴业银行', 'http://www.cib.com.cn/cn/index.html', 'img_569370d29bf59.jpg', '', '', '0', '1452503250', '0', '1');
INSERT INTO `movesay_link` VALUES ('11', 'citic', '中信银行', 'http://www.ecitic.com/', 'img_569370fb7a1b3.jpg', '', '', '0', '1452503291', '0', '1');
INSERT INTO `movesay_link` VALUES ('12', 'cmb', '招商银行', 'http://www.cmbchina.com/', 'img_5693710a9ac9c.jpg', '', '', '0', '1452503306', '0', '1');
INSERT INTO `movesay_link` VALUES ('13', 'cmbc', '民生银行', 'http://www.cmbchina.com/', 'img_5693711f97a9d.jpg', '', '', '0', '1452503327', '0', '1');
INSERT INTO `movesay_link` VALUES ('14', 'comm', '交通银行', 'http://www.bankcomm.com/BankCommSite/default.shtml', 'img_5693713076351.jpg', '', '', '0', '1452503344', '0', '1');
INSERT INTO `movesay_link` VALUES ('16', 'gdb', '广发银行', 'http://www.cgbchina.com.cn/', 'img_56937154bebc5.jpg', '', '', '0', '1452503380', '0', '1');
INSERT INTO `movesay_link` VALUES ('17', 'icbc', '工商银行', 'http://www.icbc.com.cn/icbc/', 'img_56937162db7f5.jpg', '', '', '0', '1452503394', '0', '1');
INSERT INTO `movesay_link` VALUES ('19', 'psbc', '邮政银行', 'http://www.psbc.com/portal/zh_CN/index.html', 'img_5693717eefaa3.jpg', '', '', '0', '1452503422', '0', '1');
INSERT INTO `movesay_link` VALUES ('20', 'spdb', '浦发银行', 'http://www.spdb.com.cn/chpage/c1/', 'img_5693718f1d70e.jpg', '', '', '0', '1452503439', '0', '1');
INSERT INTO `movesay_link` VALUES ('21', 'szpab', '平安银行', 'http://bank.pingan.com/', '56c2e4c9aff85.jpg', '', '', '0', '1455613129', '0', '1');

-- -----------------------------
-- Table structure for `movesay_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_log`;
CREATE TABLE `movesay_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` int(20) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `unlock` int(11) unsigned NOT NULL,
  `ci` int(11) unsigned NOT NULL,
  `recycle` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `coinname` (`coinname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_market`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_market`;
CREATE TABLE `movesay_market` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `round` varchar(255) NOT NULL,
  `fee_buy` varchar(255) NOT NULL,
  `fee_sell` varchar(255) NOT NULL,
  `buy_min` varchar(255) NOT NULL,
  `buy_max` varchar(255) NOT NULL,
  `sell_min` varchar(255) NOT NULL,
  `sell_max` varchar(255) NOT NULL,
  `trade_min` varchar(255) NOT NULL,
  `trade_max` varchar(255) NOT NULL,
  `invit_buy` varchar(50) NOT NULL,
  `invit_sell` varchar(50) NOT NULL,
  `invit_1` varchar(50) NOT NULL,
  `invit_2` varchar(50) NOT NULL,
  `invit_3` varchar(50) NOT NULL,
  `zhang` varchar(255) NOT NULL,
  `die` varchar(255) NOT NULL,
  `hou_price` varchar(255) NOT NULL,
  `tendency` varchar(1000) NOT NULL,
  `zoushi` text NOT NULL,
  `trade` int(11) unsigned NOT NULL,
  `new_price` decimal(20,8) unsigned NOT NULL,
  `buy_price` decimal(20,8) unsigned NOT NULL,
  `sell_price` decimal(20,8) unsigned NOT NULL,
  `min_price` decimal(20,8) unsigned NOT NULL,
  `max_price` decimal(20,8) unsigned NOT NULL,
  `volume` decimal(20,8) unsigned NOT NULL,
  `change` decimal(20,8) NOT NULL,
  `api_min` decimal(20,8) unsigned NOT NULL,
  `api_max` decimal(20,8) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='行情配置表';

-- -----------------------------
-- Records of `movesay_market`
-- -----------------------------
INSERT INTO `movesay_market` VALUES ('3', 'btc_cny', '2', '0', '0', '', '', '', '', '', '', '0', '0', '', '', '', '', '', '4350.00000000', '[[1467093302,0],[1467107702,0],[1467122102,0],[1467136502,0],[1467150902,0],[1467165302,0],[1467179702,0],[1467194102,0],[1467208502,0],[1467222902,0],[1467237302,0],[1467251702,0],[1467266102,0],[1467280502,\"4400.00000000\"],[1467294902,0],[1467309302,0],[1467323702,0],[1467338102,0],[1467352502,0]]', '', '1', '4400.00000000', '4350.00000000', '4400.00000000', '4350.00000000', '4400.00000000', '2.50000000', '1.14940000', '0.00000000', '0.00000000', '0', '0', '0', '1');
INSERT INTO `movesay_market` VALUES ('4', 'ltc_cny', '2', '', '', '', '', '', '', '', '', '0', '0', '', '', '', '', '', '27.00000000', '[[1467093302,0],[1467107702,0],[1467122102,0],[1467136502,0],[1467150902,0],[1467165302,0],[1467179702,0],[1467194102,0],[1467208502,0],[1467222902,0],[1467237302,0],[1467251702,0],[1467266102,0],[1467280502,\"30.00000000\"],[1467294902,0],[1467309302,0],[1467323702,0],[1467338102,0],[1467352502,0]]', '', '1', '30.00000000', '27.00000000', '30.00000000', '27.00000000', '30.00000000', '876.00000000', '11.11110000', '0.00000000', '0.00000000', '0', '0', '0', '1');
INSERT INTO `movesay_market` VALUES ('5', 'ytc_cny', '2', '', '', '', '', '', '', '', '', '0', '0', '', '', '', '', '', '11.00000000', '[[1467093302,0],[1467107702,0],[1467122102,0],[1467136502,0],[1467150902,0],[1467165302,0],[1467179702,0],[1467194102,0],[1467208502,0],[1467222902,0],[1467237302,0],[1467251702,0],[1467266102,0],[1467280502,\"11.00000000\"],[1467294902,0],[1467309302,0],[1467323702,0],[1467338102,0],[1467352502,0]]', '', '1', '11.00000000', '10.00000000', '11.00000000', '10.00000000', '11.00000000', '1043.00000000', '0.00000000', '0.00000000', '0.00000000', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `movesay_market_json`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_market_json`;
CREATE TABLE `movesay_market_json` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `data` varchar(500) CHARACTER SET utf8 NOT NULL,
  `type` varchar(100) CHARACTER SET utf8 NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -----------------------------
-- Records of `movesay_market_json`
-- -----------------------------
INSERT INTO `movesay_market_json` VALUES ('1', 'btc_cny', '[\"1921.50000000\",\"45478.00000000\",\"0.00000000\",\"0.00000000\"]', '', '0', '1467302399', '0', '0');

-- -----------------------------
-- Table structure for `movesay_menu`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_menu`;
CREATE TABLE `movesay_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `ico_name` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=183 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_menu`
-- -----------------------------
INSERT INTO `movesay_menu` VALUES ('1', '系统', '0', '1', 'Index/index', '0', '', '', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('2', '内容', '0', '1', 'Article/index', '0', '', '', '0', 'list-alt');
INSERT INTO `movesay_menu` VALUES ('3', '用户', '0', '1', 'User/index', '0', '', '', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('4', '财务', '0', '1', 'Finance/index', '0', '', '', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('5', '交易', '0', '1', 'Trade/index', '0', '', '', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('6', '应用', '0', '1', 'Game/index', '0', '', '', '0', 'globe');
INSERT INTO `movesay_menu` VALUES ('7', '设置', '0', '1', 'Config/index', '0', '', '', '0', 'cog');
INSERT INTO `movesay_menu` VALUES ('8', '运营', '0', '1', 'Invit/index', '0', '', '', '0', 'share');
INSERT INTO `movesay_menu` VALUES ('9', '工具', '0', '1', 'Tools/index', '0', '', '', '0', 'wrench');
INSERT INTO `movesay_menu` VALUES ('10', '扩展', '0', '1', 'Cloud/index', '0', '', '', '0', 'tasks');
INSERT INTO `movesay_menu` VALUES ('11', '系统概览', '1', '1', 'Index/index', '0', '', '系统', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('13', '文章管理', '2', '1', 'Article/index', '0', '', '内容', '0', 'list-alt');
INSERT INTO `movesay_menu` VALUES ('14', '编辑', '13', '1', 'Article/edit', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('15', '修改', '13', '1', 'Article/status', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('16', '上传图片', '13', '2', 'Article/images', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('156', '提现地址', '3', '6', 'User/bank', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('18', '编辑', '17', '2', 'Adver/edit', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('19', '修改', '17', '2', 'Adver/status', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('153', '管理员管理', '3', '2', 'User/adminUser', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('21', '编辑', '20', '3', 'Chat/edit', '1', '', '聊天管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('22', '修改', '20', '3', 'Chat/status', '1', '', '聊天管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('23', '提示文字', '2', '1', 'Text/index', '1', '', '提示管理', '0', 'exclamation-sign');
INSERT INTO `movesay_menu` VALUES ('24', '编辑', '23', '1', 'Text/edit', '1', '', '提示管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('25', '修改', '23', '1', 'Text/status', '1', '', '提示管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('26', '用户管理', '3', '1', 'User/index', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('163', '虚拟币转入', '4', '6', 'Finance/myzr', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('162', '人民币提现配置', '4', '5', 'Finance/mytxConfig', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('161', '人民币提现', '4', '4', 'Finance/mytx', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('165', '成交记录', '5', '2', 'Trade/log', '0', '', '交易', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('166', '交易聊天', '5', '3', 'Trade/chat', '0', '', '交易', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('32', '确认转出', '26', '8', 'User/myzc_qr', '1', '', '用户管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('33', '用户配置', '3', '1', 'User/config', '1', '', '前台用户管理', '0', 'cog');
INSERT INTO `movesay_menu` VALUES ('34', '编辑', '33', '2', 'User/index_edit', '1', '', '用户管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('35', '修改', '33', '2', 'User/index_status', '1', '', '用户管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('37', '财产修改', '26', '3', 'Usercoin/edit', '1', '', '用户管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('38', '权限列表', '3', '3', 'AuthManager/index', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('39', '新增用户组', '38', '0', 'AuthManager/createGroup', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('40', '编辑用户组', '38', '0', 'AuthManager/editgroup', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('41', '更新用户组', '38', '0', 'AuthManager/writeGroup', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('42', '改变状态', '38', '0', 'AuthManager/changeStatus', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('43', '访问授权', '38', '0', 'AuthManager/access', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('44', '分类授权', '38', '0', 'AuthManager/category', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('45', '成员授权', '38', '0', 'AuthManager/user', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('46', '成员列表授权', '38', '0', 'AuthManager/tree', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('47', '用户组', '38', '0', 'AuthManager/group', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('48', '添加到用户组', '38', '0', 'AuthManager/addToGroup', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('49', '用户组移除', '38', '0', 'AuthManager/removeFromGroup', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('50', '分类添加到用户组', '38', '0', 'AuthManager/addToCategory', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('51', '模型添加到用户组', '38', '0', 'AuthManager/addToModel', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('52', '财务明细', '4', '1', 'Finance/index', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('53', '配置', '52', '1', 'Finance/config', '1', '', '', '0', '0');
INSERT INTO `movesay_menu` VALUES ('159', '人民币充值', '4', '2', 'Finance/mycz', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('55', '类型', '52', '1', 'Finance/type', '1', '', '', '0', '0');
INSERT INTO `movesay_menu` VALUES ('56', '状态修改', '52', '1', 'Finance/type_status', '1', '', '', '0', '0');
INSERT INTO `movesay_menu` VALUES ('169', '交易推荐', '5', '6', 'Trade/invit', '0', '', '交易', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('172', '修改状态', '159', '100', 'Finance/myczStatus', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('168', '交易市场', '5', '5', 'Trade/market', '0', '', '交易', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('60', '修改', '57', '3', 'Mycz/status', '1', '', '充值管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('61', '状态修改', '57', '3', 'Mycztype/status', '1', '', '充值管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('167', '币种评论', '5', '4', 'Trade/comment', '0', '', '交易', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('64', '状态修改', '62', '5', 'Mytx/status', '1', '', '提现管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('65', '取消', '62', '5', 'Mytx/excel', '1', '', '提现管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('66', '导入excel', '9', '5', 'Mytx/exportExcel', '1', '', '提现管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('68', '委托管理', '5', '1', 'Trade/index', '0', '', '交易', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('69', '交易记录', '5', '2', 'Tradelog/index', '0', '', '交易管理', '0', 'time');
INSERT INTO `movesay_menu` VALUES ('70', '修改状态', '68', '0', 'Trade/status', '1', '', '交易管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('71', '撤销挂单', '68', '0', 'Trade/chexiao', '1', '', '交易管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('72', '认购管理', '6', '1', 'Issue/index', '0', '', '认购管理', '0', 'tasks');
INSERT INTO `movesay_menu` VALUES ('74', '认购编辑', '72', '2', 'Issue/edit', '1', '', '认购管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('75', '认购修改', '72', '2', 'Issue/status', '1', '', '认购管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('76', '认购记录', '6', '3', 'Issuelog/index', '0', '', '认购管理', '0', 'time');
INSERT INTO `movesay_menu` VALUES ('79', '基本配置', '7', '1', 'Config/index', '0', '', '网站配置', '0', 'cog');
INSERT INTO `movesay_menu` VALUES ('80', '短信配置', '7', '2', 'Config/moble', '0', '', '网站配置', '0', 'comment');
INSERT INTO `movesay_menu` VALUES ('81', '客服配置', '7', '3', 'Config/contact', '0', '', '网站配置', '0', 'headphones');
INSERT INTO `movesay_menu` VALUES ('82', '银行配置', '79', '4', 'Config/bank', '0', '', '网站配置', '0', 'credit-card');
INSERT INTO `movesay_menu` VALUES ('83', '编辑', '82', '4', 'Config/bank_edit', '1', '', '网站配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('84', '币种配置', '7', '5', 'Coin/index', '0', '', '网站配置', '0', 'signal');
INSERT INTO `movesay_menu` VALUES ('85', '编辑', '84', '4', 'Coin/edit', '0', '', '网站配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('87', '状态修改', '84', '4', 'Coin/status', '1', '', '网站配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('88', '市场配置', '7', '6', 'Market/index', '0', '', '网站配置', '0', 'signal');
INSERT INTO `movesay_menu` VALUES ('89', '编辑市场', '88', '4', 'Market/edit', '0', '', '', '0', '0');
INSERT INTO `movesay_menu` VALUES ('154', '登陆日志', '3', '4', 'User/log', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('91', '状态修改', '88', '4', 'Config/market_add', '1', '', '', '0', '0');
INSERT INTO `movesay_menu` VALUES ('92', '图形验证码', '95', '7', 'Verify/code', '1', '', '网站配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('93', '手机验证码', '95', '7', 'Verify/mobile', '1', '', '网站配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('94', '邮件验证码', '95', '7', 'Verify/email', '1', '', '网站配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('95', '其他配置', '7', '7', 'Config/qita', '0', '', '网站配置', '0', 'retweet');
INSERT INTO `movesay_menu` VALUES ('96', '推广奖励', '8', '1', 'Invit/index', '0', '', '推广管理', '0', 'share');
INSERT INTO `movesay_menu` VALUES ('97', '推广配置', '8', '2', 'Invit/config', '1', '', '推广管理', '0', 'cog');
INSERT INTO `movesay_menu` VALUES ('98', '数据备份', '9', '3', 'Tools/database?type=export', '0', '', '首页', '0', 'floppy-saved');
INSERT INTO `movesay_menu` VALUES ('99', '数据还原', '9', '4', 'Tools/database?type=import', '0', '', '首页', '0', 'open');
INSERT INTO `movesay_menu` VALUES ('100', '清理缓存', '9', '4', 'Tools/delcahe', '0', '', '其他', '0', 'trash');
INSERT INTO `movesay_menu` VALUES ('101', '其他模块调用', '9', '4', 'Tools/invoke', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('102', '优化表', '9', '4', 'Tools/optimize', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('103', '修复表', '9', '4', 'Tools/repair', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('104', '删除备份文件', '9', '4', 'Tools/del', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('105', '备份数据库', '9', '4', 'Tools/export', '1', '', '其他', '0', '');
INSERT INTO `movesay_menu` VALUES ('106', '还原数据库', '9', '4', 'Tools/import', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('107', '导出数据库', '9', '4', 'Tools/excel', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('108', '导出Excel', '9', '4', 'Tools/exportExcel', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('109', '导入Excel', '9', '4', 'Tools/importExecl', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('110', '扩展管理', '10', '0', 'ExtA/index', '0', '', '扩展管理', '0', 'th');
INSERT INTO `movesay_menu` VALUES ('173', '确认到账', '159', '100', 'Finance/myczQueren', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('174', '编辑添加', '160', '1', 'Finance/myczTypeEdit', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('115', '图片', '111', '0', 'Shop/images', '0', '', '云购商城', '0', '0');
INSERT INTO `movesay_menu` VALUES ('116', '菜单管理', '7', '5', 'Menu/index', '1', '', '开发组', '0', 'list');
INSERT INTO `movesay_menu` VALUES ('117', '排序', '116', '5', 'Menu/sort', '0', '', '开发组', '0', '0');
INSERT INTO `movesay_menu` VALUES ('118', '添加', '116', '5', 'Menu/add', '0', '', '开发组', '0', '0');
INSERT INTO `movesay_menu` VALUES ('119', '编辑', '116', '5', 'Menu/edit', '0', '', '开发组', '0', '0');
INSERT INTO `movesay_menu` VALUES ('120', '删除', '116', '5', 'Menu/del', '0', '', '开发组', '0', '0');
INSERT INTO `movesay_menu` VALUES ('121', '是否隐藏', '116', '5', 'Menu/toogleHide', '0', '', '开发组', '0', '0');
INSERT INTO `movesay_menu` VALUES ('122', '是否开发', '116', '5', 'Menu/toogleDev', '0', '', '开发组', '0', '0');
INSERT INTO `movesay_menu` VALUES ('123', '导入文件', '7', '5', 'Menu/importFile', '1', '', '开发组', '0', 'log-in');
INSERT INTO `movesay_menu` VALUES ('124', '导入', '7', '5', 'Menu/import', '1', '', '开发组', '0', 'log-in');
INSERT INTO `movesay_menu` VALUES ('164', '虚拟币转出', '4', '7', 'Finance/myzc', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('127', '用户登录', '3', '0', 'Login/index', '1', '', '用户配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('128', '用户退出', '3', '0', 'Login/loginout', '1', '', '用户配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('129', '设置密码', '3', '0', 'User/setpwd', '1', '', '用户配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('147', '自动升级', '10', '1', 'Cloud/update', '0', '', '扩展', '0', 'wrench');
INSERT INTO `movesay_menu` VALUES ('131', '用户详情', '3', '4', 'User/detail', '1', '', '前台用户管理', '0', 'time');
INSERT INTO `movesay_menu` VALUES ('132', '后台用户详情', '3', '1', 'AdminUser/detail', '1', '', '后台用户管理', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('133', '后台用户状态', '3', '1', 'AdminUser/status', '1', '', '后台用户管理', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('134', '后台用户新增', '3', '1', 'AdminUser/add', '1', '', '后台用户管理', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('135', '后台用户编辑', '3', '1', 'AdminUser/edit', '1', '', '后台用户管理', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('12', '市场统计', '1', '1', 'Index/operate', '1', '', '首页', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('138', '编辑', '2', '1', 'Articletype/edit', '1', '', '内容管理', '0', 'list-alt');
INSERT INTO `movesay_menu` VALUES ('155', '用户钱包', '3', '5', 'User/qianbao', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('140', '编辑', '139', '2', 'Link/edit', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('141', '修改', '139', '2', 'Link/status', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('160', '人民币充值方式', '4', '3', 'Finance/myczType', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('145', '币种统计', '1', '2', 'Index/coin', '0', '', '系统', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('146', '市场统计', '1', '3', 'Index/market', '0', '', '系统', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('148', '应用管理', '10', '2', 'Cloud/game', '0', '', '扩展', '0', 'retweet');
INSERT INTO `movesay_menu` VALUES ('149', '提示文字', '7', '5', 'Config/text', '0', '', '网站配置', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('150', '文章类型', '2', '2', 'Article/type', '0', '', '内容', '0', 'list-alt');
INSERT INTO `movesay_menu` VALUES ('151', '广告管理', '2', '3', 'Article/adver', '0', '', '内容', '0', 'list-alt');
INSERT INTO `movesay_menu` VALUES ('152', '友情链接', '2', '4', 'Article/link', '0', '', '内容', '0', 'list-alt');
INSERT INTO `movesay_menu` VALUES ('157', '用户财产', '3', '7', 'User/coin', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('158', '联系地址', '3', '8', 'User/goods', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('170', '队列状态', '9', '5', 'Tools/queue', '0', '', '其他', '0', 'time');
INSERT INTO `movesay_menu` VALUES ('171', '钱包检查', '9', '5', 'Tools/qianbao', '0', '', '其他', '0', 'time');
INSERT INTO `movesay_menu` VALUES ('175', '状态修改', '160', '2', 'Finance/myczTypeStatus', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('176', '上传图片', '160', '2', 'Finance/myczTypeImage', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('177', '修改状态', '161', '2', 'Finance/mytxStatus', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('178', '导出选中', '161', '3', 'Finance/mytxExcel', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('179', '正在处理', '161', '4', 'Finance/mytxChuli', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('180', '撤销提现', '161', '5', 'Finance/mytxChexiao', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('181', '确认提现', '161', '6', 'Finance/mytxQueren', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('182', '确认转出', '164', '6', 'Finance/myzcQueren', '1', '', '财务', '0', 'home');

-- -----------------------------
-- Table structure for `movesay_message`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_message`;
CREATE TABLE `movesay_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `addip` varchar(200) NOT NULL,
  `addr` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_message_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_message_log`;
CREATE TABLE `movesay_message_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `addip` varchar(200) NOT NULL,
  `addr` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_money`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_money`;
CREATE TABLE `movesay_money` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `num` bigint(20) unsigned NOT NULL DEFAULT '0',
  `deal` int(11) unsigned NOT NULL DEFAULT '0',
  `tian` int(11) unsigned NOT NULL,
  `fee` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='投资理财表';


-- -----------------------------
-- Table structure for `movesay_money_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_money_log`;
CREATE TABLE `movesay_money_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `num` int(11) unsigned NOT NULL,
  `fee` decimal(20,8) unsigned NOT NULL,
  `feea` decimal(20,8) unsigned NOT NULL,
  `tian` int(11) unsigned NOT NULL,
  `tiana` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='理财记录表';


-- -----------------------------
-- Table structure for `movesay_mycz`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_mycz`;
CREATE TABLE `movesay_mycz` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `num` int(11) unsigned NOT NULL,
  `mum` int(11) unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `tradeno` varchar(50) NOT NULL,
  `remark` varchar(250) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='充值记录表';

-- -----------------------------
-- Records of `movesay_mycz`
-- -----------------------------
INSERT INTO `movesay_mycz` VALUES ('3', '2', '1000', '0', 'alipay', 'BV933982', '', '0', '1467292321', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('4', '2', '1000', '0', 'bank', 'DJ492272', '', '0', '1467292341', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('5', '2', '1000', '0', 'weixin', 'QC521779', '', '0', '1467292349', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('6', '2', '10', '0', 'alipay', 'DQ163469', '', '0', '1467348020', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('7', '2', '10', '0', 'alipay', 'KY922424', '', '0', '1467348259', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('8', '2', '10', '0', 'alipay', 'KH657215', '', '0', '1467348259', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('9', '2', '10', '0', 'alipay', 'JA234722', '', '0', '1467348273', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('10', '2', '111', '0', 'bank', 'VH451642', '', '0', '1467349910', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('11', '2', '10', '0', 'weixin', 'AG227497', '', '0', '1467350734', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('12', '2', '100', '0', 'bank', 'NG743391', '', '0', '1467350746', '0', '3');
INSERT INTO `movesay_mycz` VALUES ('13', '2', '100', '0', 'weixin', 'LB943743', '', '0', '1467350809', '0', '3');
INSERT INTO `movesay_mycz` VALUES ('14', '2', '10', '0', 'weixin', 'SJ954671', '', '0', '1467350814', '0', '3');
INSERT INTO `movesay_mycz` VALUES ('15', '2', '10', '0', 'weixin', 'JI742952', '', '0', '1467351096', '0', '3');
INSERT INTO `movesay_mycz` VALUES ('16', '2', '10', '0', 'alipay', 'PW298533', '', '0', '1467351290', '0', '3');

-- -----------------------------
-- Table structure for `movesay_mycz_type`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_mycz_type`;
CREATE TABLE `movesay_mycz_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `max` varchar(200) NOT NULL COMMENT '名称',
  `min` varchar(200) NOT NULL COMMENT '名称',
  `img` varchar(200) NOT NULL COMMENT '名称',
  `kaihu` varchar(200) NOT NULL COMMENT '名称',
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(355) DEFAULT NULL,
  `truename` varchar(200) NOT NULL COMMENT '名称',
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='充值类型';

-- -----------------------------
-- Records of `movesay_mycz_type`
-- -----------------------------
INSERT INTO `movesay_mycz_type` VALUES ('1', '20000', '10', '5775e2c222348.png', '11', '8888888', '8888', '朱盾', 'alipay', '支付宝支付', '需要在联系方式里面设置支付宝账号', '0', '0', '0', '1');
INSERT INTO `movesay_mycz_type` VALUES ('4', '20000', '10', '5775fc73495ff.png', '', '', '', '优特科技', 'weixin', '微信支付', '需要在联系方式里面设置微信账号', '0', '0', '0', '1');
INSERT INTO `movesay_mycz_type` VALUES ('7', '50000', '100', '', '中国银行深圳市科技园支行', '888888888888', '222888888', '优特科技', 'bank', '网银支付', '需要在联系方式里面按照格式天数收款银行账号', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `movesay_mytx`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_mytx`;
CREATE TABLE `movesay_mytx` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `num` int(11) unsigned NOT NULL,
  `fee` decimal(20,2) unsigned NOT NULL,
  `mum` decimal(20,2) unsigned NOT NULL,
  `truename` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `bank` varchar(250) NOT NULL,
  `bankprov` varchar(50) NOT NULL,
  `bankcity` varchar(50) NOT NULL,
  `bankaddr` varchar(50) NOT NULL,
  `bankcard` varchar(200) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='提现记录表';


-- -----------------------------
-- Table structure for `movesay_myzc`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_myzc`;
CREATE TABLE `movesay_myzc` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `username` varchar(200) NOT NULL,
  `coinname` varchar(200) NOT NULL,
  `txid` varchar(200) NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `fee` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`),
  KEY `coinname` (`coinname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_myzr`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_myzr`;
CREATE TABLE `movesay_myzr` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `username` varchar(200) NOT NULL,
  `coinname` varchar(200) NOT NULL,
  `txid` varchar(200) NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `fee` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `coinname` (`coinname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_pool`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_pool`;
CREATE TABLE `movesay_pool` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `ico` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `tian` int(11) unsigned NOT NULL,
  `limit` varchar(50) NOT NULL,
  `power` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='矿机类型表';


-- -----------------------------
-- Table structure for `movesay_pool_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_pool_log`;
CREATE TABLE `movesay_pool_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `ico` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `tian` int(11) unsigned NOT NULL,
  `limit` varchar(50) NOT NULL,
  `power` varchar(50) NOT NULL,
  `num` int(11) unsigned NOT NULL,
  `use` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='矿机管理';


-- -----------------------------
-- Table structure for `movesay_prompt`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_prompt`;
CREATE TABLE `movesay_prompt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL,
  `mytx` varchar(200) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_shop`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_shop`;
CREATE TABLE `movesay_shop` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `coinlist` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `price_1` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `num` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `deal` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `content` text NOT NULL,
  `max` varchar(255) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `status` (`status`),
  KEY `deal` (`deal`),
  KEY `price` (`price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商城商品表';


-- -----------------------------
-- Table structure for `movesay_shop_addr`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_shop_addr`;
CREATE TABLE `movesay_shop_addr` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL DEFAULT '0',
  `truename` varchar(50) NOT NULL DEFAULT '0',
  `moble` varchar(500) NOT NULL,
  `name` varchar(500) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_shop_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_shop_log`;
CREATE TABLE `movesay_shop_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) NOT NULL,
  `shopid` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `coinname` varchar(50) NOT NULL DEFAULT '0.00',
  `num` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `mum` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `addr` varchar(50) NOT NULL DEFAULT '0.0000',
  `sort` int(11) unsigned NOT NULL,
  `fee` decimal(20,8) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='购物记录表';


-- -----------------------------
-- Table structure for `movesay_shop_type`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_shop_type`;
CREATE TABLE `movesay_shop_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品分类';


-- -----------------------------
-- Table structure for `movesay_text`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_text`;
CREATE TABLE `movesay_text` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_text`
-- -----------------------------
INSERT INTO `movesay_text` VALUES ('1', 'user_moble', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467279597', '0', '1');
INSERT INTO `movesay_text` VALUES ('2', 'user_alipay', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467279632', '0', '1');
INSERT INTO `movesay_text` VALUES ('3', 'game_issue', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467279637', '0', '1');
INSERT INTO `movesay_text` VALUES ('4', 'finance_index', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467285974', '0', '1');
INSERT INTO `movesay_text` VALUES ('5', 'game_issue_log', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467285987', '0', '1');
INSERT INTO `movesay_text` VALUES ('6', 'user_index', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286032', '0', '1');
INSERT INTO `movesay_text` VALUES ('7', 'finance_mycz', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286037', '0', '1');
INSERT INTO `movesay_text` VALUES ('8', 'finance_myzr', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286094', '0', '1');
INSERT INTO `movesay_text` VALUES ('9', 'finance_myjp', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286101', '0', '1');
INSERT INTO `movesay_text` VALUES ('10', 'finance_mywt', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286626', '0', '1');
INSERT INTO `movesay_text` VALUES ('11', 'finance_mycj', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286630', '0', '1');
INSERT INTO `movesay_text` VALUES ('12', 'finance_mytj', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286632', '0', '1');
INSERT INTO `movesay_text` VALUES ('13', 'finance_mywd', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286636', '0', '1');
INSERT INTO `movesay_text` VALUES ('14', 'finance_mytx', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286642', '0', '1');
INSERT INTO `movesay_text` VALUES ('15', 'finance_myzc', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467291702', '0', '1');
INSERT INTO `movesay_text` VALUES ('16', 'user_ga', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292038', '0', '1');
INSERT INTO `movesay_text` VALUES ('17', 'user_nameauth', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292042', '0', '1');
INSERT INTO `movesay_text` VALUES ('18', 'user_bank', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292073', '0', '1');
INSERT INTO `movesay_text` VALUES ('19', 'user_tpwdset', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292136', '0', '1');
INSERT INTO `movesay_text` VALUES ('20', 'user_qianbao', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292148', '0', '1');
INSERT INTO `movesay_text` VALUES ('21', 'user_goods', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292242', '0', '1');
INSERT INTO `movesay_text` VALUES ('22', 'game_issue_buy', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292443', '0', '1');

-- -----------------------------
-- Table structure for `movesay_trade`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_trade`;
CREATE TABLE `movesay_trade` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `market` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `deal` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `fee` decimal(20,8) unsigned NOT NULL,
  `type` tinyint(2) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `market_type_status` (`market`,`type`,`status`),
  KEY `num_deal` (`num`,`deal`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COMMENT='交易下单表';

-- -----------------------------
-- Records of `movesay_trade`
-- -----------------------------
INSERT INTO `movesay_trade` VALUES ('1', '2', 'btc_cny', '100.00000000', '24.40000000', '0.00000000', '2440.00000000', '0.00000000', '1', '0', '1467290821', '0', '0');
INSERT INTO `movesay_trade` VALUES ('2', '2', 'btc_cny', '5000.00000000', '42.00000000', '0.00000000', '210000.00000000', '0.00000000', '2', '0', '1467290838', '0', '0');
INSERT INTO `movesay_trade` VALUES ('3', '2', 'btc_cny', '4568.00000000', '12.00000000', '0.00000000', '54816.00000000', '0.00000000', '2', '0', '1467290857', '0', '0');
INSERT INTO `movesay_trade` VALUES ('4', '2', 'btc_cny', '3500.00000000', '124.00000000', '0.00000000', '434000.00000000', '0.00000000', '1', '0', '1467290879', '0', '0');
INSERT INTO `movesay_trade` VALUES ('5', '2', 'btc_cny', '4012.00000000', '12.20000000', '0.00000000', '48946.40000000', '0.00000000', '1', '0', '1467290901', '0', '0');
INSERT INTO `movesay_trade` VALUES ('6', '2', 'btc_cny', '8452.00000000', '54.00000000', '0.00000000', '456408.00000000', '0.00000000', '2', '0', '1467290918', '0', '0');
INSERT INTO `movesay_trade` VALUES ('7', '2', 'btc_cny', '1486.00000000', '147.30000000', '0.00000000', '218887.80000000', '0.00000000', '1', '0', '1467290964', '0', '0');
INSERT INTO `movesay_trade` VALUES ('8', '2', 'btc_cny', '4350.00000000', '301.00000000', '2.00000000', '1309350.00000000', '0.00000000', '1', '0', '1467290997', '0', '0');
INSERT INTO `movesay_trade` VALUES ('9', '2', 'btc_cny', '4400.00000000', '10.60000000', '0.50000000', '46640.00000000', '0.00000000', '2', '0', '1467291026', '0', '0');
INSERT INTO `movesay_trade` VALUES ('10', '2', 'btc_cny', '4350.00000000', '1.00000000', '1.00000000', '4350.00000000', '0.00000000', '2', '0', '1467291031', '0', '1');
INSERT INTO `movesay_trade` VALUES ('11', '2', 'btc_cny', '4350.00000000', '1.00000000', '1.00000000', '4350.00000000', '0.00000000', '2', '0', '1467291036', '0', '1');
INSERT INTO `movesay_trade` VALUES ('12', '2', 'btc_cny', '4400.00000000', '0.30000000', '0.30000000', '1320.00000000', '0.00000000', '1', '0', '1467291050', '0', '1');
INSERT INTO `movesay_trade` VALUES ('13', '2', 'btc_cny', '4568.00000000', '0.10000000', '0.10000000', '456.80000000', '0.00000000', '1', '0', '1467291059', '0', '1');
INSERT INTO `movesay_trade` VALUES ('14', '2', 'btc_cny', '4400.00000000', '0.10000000', '0.10000000', '440.00000000', '0.00000000', '1', '0', '1467291073', '0', '1');
INSERT INTO `movesay_trade` VALUES ('15', '2', 'ltc_cny', '20.00000000', '1245.00000000', '0.00000000', '24900.00000000', '0.00000000', '1', '0', '1467291151', '0', '0');
INSERT INTO `movesay_trade` VALUES ('16', '2', 'ltc_cny', '30.00000000', '476.00000000', '2.00000000', '14280.00000000', '0.00000000', '2', '0', '1467291169', '0', '0');
INSERT INTO `movesay_trade` VALUES ('17', '2', 'ltc_cny', '40.00000000', '453.00000000', '0.00000000', '18120.00000000', '0.00000000', '2', '0', '1467291186', '0', '0');
INSERT INTO `movesay_trade` VALUES ('18', '2', 'ltc_cny', '54.00000000', '45.00000000', '0.00000000', '2430.00000000', '0.00000000', '2', '0', '1467291198', '0', '0');
INSERT INTO `movesay_trade` VALUES ('19', '2', 'ltc_cny', '32.40000000', '786.00000000', '0.00000000', '25466.40000000', '0.00000000', '2', '0', '1467291211', '0', '0');
INSERT INTO `movesay_trade` VALUES ('20', '2', 'ltc_cny', '777.00000000', '888.00000000', '0.00000000', '689976.00000000', '0.00000000', '2', '0', '1467291230', '0', '0');
INSERT INTO `movesay_trade` VALUES ('21', '2', 'ltc_cny', '25.00000000', '453.00000000', '0.00000000', '11325.00000000', '0.00000000', '1', '0', '1467291240', '0', '0');
INSERT INTO `movesay_trade` VALUES ('22', '2', 'ltc_cny', '10.00000000', '453.00000000', '0.00000000', '4530.00000000', '0.00000000', '1', '0', '1467291249', '0', '0');
INSERT INTO `movesay_trade` VALUES ('23', '2', 'ltc_cny', '1.00000000', '7777.00000000', '0.00000000', '7777.00000000', '0.00000000', '1', '0', '1467291259', '0', '0');
INSERT INTO `movesay_trade` VALUES ('24', '2', 'ltc_cny', '27.00000000', '1000.00000000', '874.00000000', '27000.00000000', '0.00000000', '1', '0', '1467291272', '0', '0');
INSERT INTO `movesay_trade` VALUES ('25', '2', 'ltc_cny', '27.00000000', '42.00000000', '42.00000000', '1134.00000000', '0.00000000', '2', '0', '1467291282', '0', '1');
INSERT INTO `movesay_trade` VALUES ('26', '2', 'ltc_cny', '27.00000000', '45.00000000', '45.00000000', '1215.00000000', '0.00000000', '2', '0', '1467291287', '0', '1');
INSERT INTO `movesay_trade` VALUES ('27', '2', 'ltc_cny', '27.00000000', '786.00000000', '786.00000000', '21222.00000000', '0.00000000', '2', '0', '1467291295', '0', '1');
INSERT INTO `movesay_trade` VALUES ('28', '2', 'ltc_cny', '27.00000000', '1.00000000', '1.00000000', '27.00000000', '0.00000000', '2', '0', '1467291307', '0', '1');
INSERT INTO `movesay_trade` VALUES ('29', '2', 'ltc_cny', '30.00000000', '1.00000000', '1.00000000', '30.00000000', '0.00000000', '1', '0', '1467291314', '0', '1');
INSERT INTO `movesay_trade` VALUES ('30', '2', 'ltc_cny', '30.00000000', '1.00000000', '1.00000000', '30.00000000', '0.00000000', '1', '0', '1467291319', '0', '1');
INSERT INTO `movesay_trade` VALUES ('31', '2', 'ytc_cny', '10.00000000', '1000.00000000', '553.00000000', '10000.00000000', '0.00000000', '1', '0', '1467291499', '0', '0');
INSERT INTO `movesay_trade` VALUES ('32', '2', 'ytc_cny', '1.00000000', '10000.00000000', '0.00000000', '10000.00000000', '0.00000000', '1', '0', '1467291511', '0', '0');
INSERT INTO `movesay_trade` VALUES ('33', '2', 'ytc_cny', '5.00000000', '4537.00000000', '0.00000000', '22685.00000000', '0.00000000', '1', '0', '1467291516', '0', '0');
INSERT INTO `movesay_trade` VALUES ('34', '2', 'ytc_cny', '3.00000000', '1453.00000000', '0.00000000', '4359.00000000', '0.00000000', '1', '0', '1467291524', '0', '0');
INSERT INTO `movesay_trade` VALUES ('35', '2', 'ytc_cny', '8.00000000', '42341.00000000', '0.00000000', '338728.00000000', '0.00000000', '1', '0', '1467291531', '0', '0');
INSERT INTO `movesay_trade` VALUES ('36', '2', 'ytc_cny', '11.00000000', '4753.00000000', '490.00000000', '52283.00000000', '0.00000000', '2', '0', '1467291543', '0', '0');
INSERT INTO `movesay_trade` VALUES ('37', '2', 'ytc_cny', '20.00000000', '4123.00000000', '0.00000000', '82460.00000000', '0.00000000', '2', '0', '1467291548', '0', '0');
INSERT INTO `movesay_trade` VALUES ('38', '2', 'ytc_cny', '45.00000000', '120.00000000', '0.00000000', '5400.00000000', '0.00000000', '2', '0', '1467291559', '0', '0');
INSERT INTO `movesay_trade` VALUES ('39', '2', 'ytc_cny', '35.00000000', '7786.00000000', '0.00000000', '272510.00000000', '0.00000000', '2', '0', '1467291570', '0', '0');
INSERT INTO `movesay_trade` VALUES ('40', '2', 'ytc_cny', '14.50000000', '955.00000000', '0.00000000', '13847.50000000', '0.00000000', '2', '0', '1467291585', '0', '0');
INSERT INTO `movesay_trade` VALUES ('41', '2', 'ytc_cny', '12.00000000', '312.00000000', '0.00000000', '3744.00000000', '0.00000000', '2', '0', '1467291592', '0', '0');
INSERT INTO `movesay_trade` VALUES ('42', '2', 'ytc_cny', '11.00000000', '1.00000000', '1.00000000', '11.00000000', '0.00000000', '1', '0', '1467291605', '0', '1');
INSERT INTO `movesay_trade` VALUES ('43', '2', 'ytc_cny', '10.00000000', '453.00000000', '453.00000000', '4530.00000000', '0.00000000', '2', '0', '1467291610', '0', '1');
INSERT INTO `movesay_trade` VALUES ('44', '2', 'ytc_cny', '10.00000000', '45.00000000', '45.00000000', '450.00000000', '0.00000000', '2', '0', '1467291620', '0', '1');
INSERT INTO `movesay_trade` VALUES ('45', '2', 'ytc_cny', '10.00000000', '55.00000000', '55.00000000', '550.00000000', '0.00000000', '2', '0', '1467291624', '0', '1');
INSERT INTO `movesay_trade` VALUES ('46', '2', 'ytc_cny', '11.00000000', '444.00000000', '444.00000000', '4884.00000000', '0.00000000', '1', '0', '1467291632', '0', '1');
INSERT INTO `movesay_trade` VALUES ('47', '2', 'ytc_cny', '11.00000000', '45.00000000', '45.00000000', '495.00000000', '0.00000000', '1', '0', '1467291640', '0', '1');

-- -----------------------------
-- Table structure for `movesay_trade_json`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_trade_json`;
CREATE TABLE `movesay_trade_json` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `market` varchar(100) NOT NULL,
  `data` varchar(500) NOT NULL,
  `type` varchar(100) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `market` (`market`),
  KEY `market_type_status` (`market`,`type`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8 COMMENT='交易图表表';

-- -----------------------------
-- Records of `movesay_trade_json`
-- -----------------------------
INSERT INTO `movesay_trade_json` VALUES ('1', 'btc_cny', '[1467291032,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '1', '0', '1467291032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2', 'btc_cny', '[1467290880,\"2.30000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '3', '0', '1467290880', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3', 'btc_cny', '[1467291060,\"0.20000000\",\"4400.00000000\",\"4400.00000000\",\"4400.00000000\",\"4400.00000000\"]', '3', '0', '1467291060', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4', 'btc_cny', '[1467291000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '5', '0', '1467291000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5', 'btc_cny', '[1467291000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '10', '0', '1467291000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6', 'btc_cny', '[1467290700,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '15', '0', '1467290700', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7', 'btc_cny', '[1467289800,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '30', '0', '1467289800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8', 'btc_cny', '[1467288000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '60', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9', 'btc_cny', '[1467288000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '120', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10', 'btc_cny', '[1467288000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '240', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11', 'btc_cny', '[1467288000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '360', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12', 'btc_cny', '[1467288000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '720', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13', 'btc_cny', '[1467288000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '1440', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14', 'btc_cny', '[1467288000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '10080', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15', 'btc_cny', '', '1', '0', '1467291092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('16', 'btc_cny', '', '3', '0', '1467291240', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('17', 'btc_cny', '', '5', '0', '1467291300', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('18', 'ltc_cny', '[1467291282,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '1', '0', '1467291282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('19', 'ltc_cny', '[1467291240,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '3', '0', '1467291240', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('20', 'ltc_cny', '[1467291000,\"873.00000000\",\"27.00000000\",\"27.00000000\",\"27.00000000\",\"27.00000000\"]', '5', '0', '1467291000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('21', 'ltc_cny', '[1467291300,\"3.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '5', '0', '1467291300', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('22', 'ltc_cny', '[1467291000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '10', '0', '1467291000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('23', 'ltc_cny', '[1467290700,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '15', '0', '1467290700', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('24', 'ltc_cny', '[1467289800,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '30', '0', '1467289800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('25', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '60', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('26', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '120', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('27', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '240', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('28', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '360', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('29', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '720', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('30', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '1440', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('31', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '10080', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('32', 'ltc_cny', '', '1', '0', '1467291342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('33', 'ltc_cny', '', '3', '0', '1467291420', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('34', 'btc_cny', '', '10', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('35', 'btc_cny', '', '15', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('36', 'btc_cny', '', '30', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('37', 'btc_cny', '', '60', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('38', 'ltc_cny', '', '5', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('39', 'ltc_cny', '', '10', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('40', 'ltc_cny', '', '15', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('41', 'ltc_cny', '', '30', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('42', 'ltc_cny', '', '60', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('43', 'ytc_cny', '[1467291605,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '1', '0', '1467291605', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('44', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '3', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('45', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '5', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('46', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '10', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('47', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '15', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('48', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '30', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('49', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '60', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('50', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '120', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('51', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '240', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('52', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '360', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('53', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '720', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('54', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '1440', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('55', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '10080', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('56', 'ytc_cny', '', '1', '0', '1467291665', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('57', 'ytc_cny', '', '3', '0', '1467291780', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('58', 'ytc_cny', '', '5', '0', '1467291900', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('59', 'ytc_cny', '', '10', '0', '1467292200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('60', 'ytc_cny', '', '15', '0', '1467292500', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('61', 'ytc_cny', '', '30', '0', '1467293400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('62', 'btc_cny', '', '120', '0', '1467295200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('63', 'ltc_cny', '', '120', '0', '1467295200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('64', 'ytc_cny', '', '60', '0', '1467295200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('65', 'ytc_cny', '', '120', '0', '1467298800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('66', 'btc_cny', '', '240', '0', '1467302400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('67', 'btc_cny', '', '240', '0', '1467316800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('68', 'btc_cny', '', '240', '0', '1467331200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('69', 'btc_cny', '', '240', '0', '1467345600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('70', 'btc_cny', '', '360', '0', '1467309600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('71', 'btc_cny', '', '360', '0', '1467331200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('72', 'btc_cny', '', '720', '0', '1467331200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('73', 'ltc_cny', '', '240', '0', '1467302400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('74', 'ltc_cny', '', '240', '0', '1467316800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('75', 'ltc_cny', '', '240', '0', '1467331200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('76', 'ltc_cny', '', '240', '0', '1467345600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('77', 'ltc_cny', '', '360', '0', '1467309600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('78', 'ltc_cny', '', '360', '0', '1467331200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('79', 'ltc_cny', '', '720', '0', '1467331200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('80', 'ytc_cny', '', '240', '0', '1467306000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('81', 'ytc_cny', '', '240', '0', '1467320400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('82', 'ytc_cny', '', '240', '0', '1467334800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('83', 'ytc_cny', '', '360', '0', '1467313200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('84', 'ytc_cny', '', '360', '0', '1467334800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('85', 'ytc_cny', '', '720', '0', '1467334800', '0', '0');

-- -----------------------------
-- Table structure for `movesay_trade_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_trade_log`;
CREATE TABLE `movesay_trade_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `peerid` int(11) unsigned NOT NULL,
  `market` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `fee_buy` decimal(20,8) unsigned NOT NULL,
  `fee_sell` decimal(20,8) unsigned NOT NULL,
  `type` tinyint(2) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `peerid` (`peerid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=gbk;

-- -----------------------------
-- Records of `movesay_trade_log`
-- -----------------------------
INSERT INTO `movesay_trade_log` VALUES ('1', '2', '2', 'btc_cny', '4350.00000000', '1.00000000', '4350.00000000', '0.00000000', '0.00000000', '2', '0', '1467291032', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('2', '2', '2', 'btc_cny', '4350.00000000', '1.00000000', '4350.00000000', '0.00000000', '0.00000000', '2', '0', '1467291036', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('3', '2', '2', 'btc_cny', '4400.00000000', '0.30000000', '1320.00000000', '0.00000000', '0.00000000', '1', '0', '1467291050', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('4', '2', '2', 'btc_cny', '4400.00000000', '0.10000000', '440.00000000', '0.00000000', '0.00000000', '1', '0', '1467291060', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('5', '2', '2', 'btc_cny', '4400.00000000', '0.10000000', '440.00000000', '0.00000000', '0.00000000', '1', '0', '1467291073', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('6', '2', '2', 'ltc_cny', '27.00000000', '42.00000000', '1134.00000000', '0.00000000', '0.00000000', '2', '0', '1467291282', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('7', '2', '2', 'ltc_cny', '27.00000000', '45.00000000', '1215.00000000', '0.00000000', '0.00000000', '2', '0', '1467291288', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('8', '2', '2', 'ltc_cny', '27.00000000', '786.00000000', '21222.00000000', '0.00000000', '0.00000000', '2', '0', '1467291295', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('9', '2', '2', 'ltc_cny', '27.00000000', '1.00000000', '27.00000000', '0.00000000', '0.00000000', '2', '0', '1467291307', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('10', '2', '2', 'ltc_cny', '30.00000000', '1.00000000', '30.00000000', '0.00000000', '0.00000000', '1', '0', '1467291314', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('11', '2', '2', 'ltc_cny', '30.00000000', '1.00000000', '30.00000000', '0.00000000', '0.00000000', '1', '0', '1467291319', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('12', '2', '2', 'ytc_cny', '11.00000000', '1.00000000', '11.00000000', '0.00000000', '0.00000000', '1', '0', '1467291605', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('13', '2', '2', 'ytc_cny', '10.00000000', '453.00000000', '4530.00000000', '0.00000000', '0.00000000', '2', '0', '1467291610', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('14', '2', '2', 'ytc_cny', '10.00000000', '45.00000000', '450.00000000', '0.00000000', '0.00000000', '2', '0', '1467291620', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('15', '2', '2', 'ytc_cny', '10.00000000', '55.00000000', '550.00000000', '0.00000000', '0.00000000', '2', '0', '1467291624', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('16', '2', '2', 'ytc_cny', '11.00000000', '444.00000000', '4884.00000000', '0.00000000', '0.00000000', '1', '0', '1467291632', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('17', '2', '2', 'ytc_cny', '11.00000000', '45.00000000', '495.00000000', '0.00000000', '0.00000000', '1', '0', '1467291640', '0', '1');

-- -----------------------------
-- Table structure for `movesay_user`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user`;
CREATE TABLE `movesay_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `moble` varchar(50) NOT NULL,
  `mobletime` int(11) unsigned NOT NULL,
  `password` varchar(32) NOT NULL,
  `tpwdsetting` varchar(32) NOT NULL,
  `paypassword` varchar(32) NOT NULL,
  `invit` varchar(32) NOT NULL,
  `invit_1` varchar(50) NOT NULL,
  `invit_2` varchar(50) NOT NULL,
  `invit_3` varchar(50) NOT NULL,
  `truename` varchar(32) NOT NULL,
  `idcard` varchar(32) NOT NULL,
  `logins` int(11) unsigned NOT NULL,
  `ga` varchar(50) NOT NULL,
  `addip` varchar(50) NOT NULL,
  `addr` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `email` varchar(200) DEFAULT NULL COMMENT '邮箱',
  `alipay` varchar(200) DEFAULT NULL COMMENT '支付宝',
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='用户信息表';

-- -----------------------------
-- Records of `movesay_user`
-- -----------------------------
INSERT INTO `movesay_user` VALUES ('1', 'movesay', '', '0', 'b887cbf3cbbc67a332b47eab6fadbc89', '1', '0a7de7a81d7e87b6f2cde05d0e692d07', 'RLSHFK', '0', '0', '0', '牛一', '420117198804074311', '0', '', '127.0.0.1', '未分配或者内网IP', '0', '1459584765', '0', '1', '', '');
INSERT INTO `movesay_user` VALUES ('2', 'BTC10000', '', '0', 'e10adc3949ba59abbe56e057f20f883e', '1', 'fcea920f7412b5da7be0cf42b8c93759', 'EXHGTU', '0', '0', '0', '牛牛', '430822198712120000', '2', '', '121.34.129.214', '未分配或者内网IP', '0', '1467279524', '0', '1', '', '');
INSERT INTO `movesay_user` VALUES ('3', 'yjj123', '', '0', 'e10adc3949ba59abbe56e057f20f883e', '1', 'c33367701511b4f6020ec61ded352059', 'QMHJWR', '0', '0', '0', '的广泛的', '111111111111111111', '1', '', '112.95.136.101', '未分配或者内网IP', '0', '1467285932', '0', '1', '', '');

-- -----------------------------
-- Table structure for `movesay_user_bank`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_bank`;
CREATE TABLE `movesay_user_bank` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `name` varchar(200) NOT NULL,
  `bank` varchar(200) NOT NULL,
  `bankprov` varchar(200) NOT NULL,
  `bankcity` varchar(200) NOT NULL,
  `bankaddr` varchar(200) NOT NULL,
  `bankcard` varchar(200) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_user_bank`
-- -----------------------------
INSERT INTO `movesay_user_bank` VALUES ('1', '2', '广东', '平安银行', '广东', '深圳', '科技园支行', '8888888888888888', '0', '1467292115', '0', '1');

-- -----------------------------
-- Table structure for `movesay_user_bank_type`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_bank_type`;
CREATE TABLE `movesay_user_bank_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL,
  `mytx` varchar(200) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='常用银行地址';

-- -----------------------------
-- Records of `movesay_user_bank_type`
-- -----------------------------
INSERT INTO `movesay_user_bank_type` VALUES ('4', 'boc', '中国银行', 'http://www.boc.cn/', 'img_56937003683ce.jpg', '', '', '0', '1452503043', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('5', 'abc', '农业银行', 'http://www.abchina.com/cn/', 'img_569370458b18d.jpg', '', '', '0', '1452503109', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('6', 'bccb', '北京银行', 'http://www.bankofbeijing.com.cn/', 'img_569370588dcdc.jpg', '', '', '0', '1452503128', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('8', 'ccb', '建设银行', 'http://www.ccb.com/', 'img_5693709bbd20f.jpg', '', '', '0', '1452503195', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('9', 'ceb', '光大银行', 'http://www.bankofbeijing.com.cn/', 'img_569370b207cc8.jpg', '', '', '0', '1452503218', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('10', 'cib', '兴业银行', 'http://www.cib.com.cn/cn/index.html', 'img_569370d29bf59.jpg', '', '', '0', '1452503250', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('11', 'citic', '中信银行', 'http://www.ecitic.com/', 'img_569370fb7a1b3.jpg', '', '', '0', '1452503291', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('12', 'cmb', '招商银行', 'http://www.cmbchina.com/', 'img_5693710a9ac9c.jpg', '', '', '0', '1452503306', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('13', 'cmbc', '民生银行', 'http://www.cmbchina.com/', 'img_5693711f97a9d.jpg', '', '', '0', '1452503327', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('14', 'comm', '交通银行', 'http://www.bankcomm.com/BankCommSite/default.shtml', 'img_5693713076351.jpg', '', '', '0', '1452503344', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('16', 'gdb', '广发银行', 'http://www.cgbchina.com.cn/', 'img_56937154bebc5.jpg', '', '', '0', '1452503380', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('17', 'icbc', '工商银行', 'http://www.icbc.com.cn/icbc/', 'img_56937162db7f5.jpg', '', '', '0', '1452503394', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('19', 'psbc', '邮政银行', 'http://www.psbc.com/portal/zh_CN/index.html', 'img_5693717eefaa3.jpg', '', '', '0', '1452503422', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('20', 'spdb', '浦发银行', 'http://www.spdb.com.cn/chpage/c1/', 'img_5693718f1d70e.jpg', '', '', '0', '1452503439', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('21', 'szpab', '平安银行', 'http://bank.pingan.com/', '56c2e4c9aff85.jpg', '', '', '0', '1455613129', '0', '1');

-- -----------------------------
-- Table structure for `movesay_user_coin`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_coin`;
CREATE TABLE `movesay_user_coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL,
  `cny` decimal(20,8) unsigned NOT NULL,
  `cnyd` decimal(20,8) unsigned NOT NULL,
  `btc` decimal(20,8) unsigned NOT NULL,
  `btcd` decimal(20,8) unsigned NOT NULL,
  `btcb` varchar(200) NOT NULL,
  `ltc` decimal(20,8) unsigned NOT NULL,
  `ltcd` decimal(20,8) unsigned NOT NULL,
  `ltcb` varchar(200) NOT NULL,
  `ytc` decimal(20,8) unsigned NOT NULL,
  `ytcd` decimal(20,8) unsigned NOT NULL,
  `ytcb` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='用户币种表';

-- -----------------------------
-- Records of `movesay_user_coin`
-- -----------------------------
INSERT INTO `movesay_user_coin` VALUES ('1', '1', '0.00000000', '0.00000000', '0.00000000', '0.00000000', '', '0.00000000', '0.00000000', '', '0.00000000', '0.00000000', '');
INSERT INTO `movesay_user_coin` VALUES ('2', '2', '7562898.80000000', '2437100.20000000', '9881.90000000', '118.10000000', '', '97354.00000000', '2646.00000000', '', '82461.00000000', '17559.00000000', '');
INSERT INTO `movesay_user_coin` VALUES ('3', '3', '10000000.00000000', '0.00000000', '1000000.00000000', '0.00000000', '', '1000000.00000000', '0.00000000', '', '1000000.00000000', '0.00000000', '');

-- -----------------------------
-- Table structure for `movesay_user_goods`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_goods`;
CREATE TABLE `movesay_user_goods` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `name` varchar(200) NOT NULL,
  `truename` varchar(200) NOT NULL,
  `idcard` varchar(200) NOT NULL,
  `moble` varchar(200) NOT NULL,
  `addr` varchar(200) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_user_goods`
-- -----------------------------
INSERT INTO `movesay_user_goods` VALUES ('1', '2', '123', '请问', '430821198802023333', '13888888888', '啊发而非阿瑟发全国', '0', '1467292285', '0', '1');

-- -----------------------------
-- Table structure for `movesay_user_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_log`;
CREATE TABLE `movesay_user_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL,
  `type` varchar(200) NOT NULL,
  `remark` varchar(200) NOT NULL,
  `addip` varchar(200) NOT NULL,
  `addr` varchar(200) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='用户记录表';

-- -----------------------------
-- Records of `movesay_user_log`
-- -----------------------------
INSERT INTO `movesay_user_log` VALUES ('1', '3', '登录', '通过用户名登录', '112.95.136.101', '未分配或者内网IP', '0', '1467286436', '0', '1');
INSERT INTO `movesay_user_log` VALUES ('2', '2', '登录', '通过用户名登录', '121.34.129.214', '未分配或者内网IP', '0', '1467349383', '0', '1');
INSERT INTO `movesay_user_log` VALUES ('3', '2', '登录', '通过用户名登录', '121.34.129.214', '未分配或者内网IP', '0', '1467349889', '0', '1');

-- -----------------------------
-- Table structure for `movesay_user_qianbao`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_qianbao`;
CREATE TABLE `movesay_user_qianbao` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `coinname` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `addr` varchar(200) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `coinname` (`coinname`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户钱包表';

-- -----------------------------
-- Records of `movesay_user_qianbao`
-- -----------------------------
INSERT INTO `movesay_user_qianbao` VALUES ('1', '2', 'btc', '比特1', '7fc388730328525271a39bae0becd54f75bc0d5f ', '0', '1467292195', '0', '1');
INSERT INTO `movesay_user_qianbao` VALUES ('2', '2', 'ltc', '莱特1', '7fc388730328525271a39bae0becd54f75bc0d5f ', '0', '1467292222', '0', '1');

-- -----------------------------
-- Table structure for `movesay_user_shopaddr`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_shopaddr`;
CREATE TABLE `movesay_user_shopaddr` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL DEFAULT '0',
  `truename` varchar(200) NOT NULL DEFAULT '0',
  `moble` varchar(500) NOT NULL,
  `name` varchar(500) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_version`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_version`;
CREATE TABLE `movesay_version` (
  `name` varchar(50) NOT NULL COMMENT '版本号',
  `number` int(11) NOT NULL COMMENT '序列号，一般用日期数字标示',
  `title` varchar(50) NOT NULL COMMENT '版本名',
  `create_time` int(11) NOT NULL COMMENT '发布时间',
  `update_time` int(11) NOT NULL COMMENT '更新的时间',
  `log` text NOT NULL COMMENT '更新日志',
  `url` varchar(150) NOT NULL COMMENT '链接到的远程文章',
  `is_current` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`name`),
  KEY `id` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='自动更新表';

-- -----------------------------
-- Records of `movesay_version`
-- -----------------------------
INSERT INTO `movesay_version` VALUES ('2.4.7', '10025', '更新人民币充值功能', '1467352025', '0', '更新人民币充值功能\r\n优化软件不能自动到账\r\n优化前台充值弹窗的状态', 'http://101.201.199.224/Update/download/2.4.7.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.6', '10024', '优化财务部分', '1467346688', '1467350864', '优化充值提现转入转出', 'http://101.201.199.224/Update/download/2.4.6.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.2.8', '10006', '优化撤销委托', '1461724928', '0', '优化撤销委托出现的小数误差问题', 'http://auth.movesay.com/Update/download/2.2.8.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.1', '10009', '更新每日卖出限制', '1463659822', '0', '每日限制卖出计算说明\r\n\r\n比如系统设置10%   \r\n假如用户现在有100个币\r\n那么今天他可以卖10个\r\n如果这10个卖了\r\n按照计算他还剩余90个 \r\n按照上面的比例他应该还可以卖9个\r\n但是今天他已经卖过10个所以不能再卖了\r\n\r\n最新版在币种配置里面设置这个百分比参数\r\n\r\n优化核心部分代码', 'http://101.201.199.224/Update/download/2.3.1.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.0', '10008', '系统授权更新', '1463372848', '0', '因官网网站备案掉了更新授权功能', 'http://101.201.199.224/Update/download/2.3.0.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.2.9', '10007', '更新优化', '1463025696', '0', '优化撤销挂单\r\n优化充值管理\r\n...', 'http://101.201.199.224/Update/download/2.2.9.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.2', '10020', '优化后台用户编辑', '1467185261', '1467277842', '优化后台用户编辑', 'http://101.201.199.224/Update/download/2.4.2.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.1', '10019', '优化扩展功能', '1467119925', '1467277816', '优化扩展功能', 'http://101.201.199.224/Update/download/2.4.1.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.0', '10018', '更新后台用户管理部分', '1467111754', '1467277791', '更新后台用户管理部分', 'http://101.201.199.224/Update/download/2.4.0.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.9', '10017', '更新后台内容管理', '1467105573', '0', '更新后台内容管理', 'http://101.201.199.224/Update/download/2.3.9.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.8', '10016', '更新权限', '1467096687', '0', '更新权限部分（还未完善）', 'http://101.201.199.224/Update/download/2.3.8.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.7', '10015', '修复更新', '1466394377', '0', '修复首页下拉导航条显示bug\r\n修复交易界面导航条下拉bug', 'http://101.201.199.224/Update/download/2.3.7.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.6', '10014', '增加交易评价后台管理', '1465530871', '0', '更新完成 记得清理缓存\r\n后台所有操作都要清理缓存才能生效\r\n\r\n增加交易评价后台管理  交易---币种评价\r\n增加委托管理缺少市场筛选功能\r\n增加交易记录缺少市场筛选功能\r\n优化登陆验证码后台控制在设置--其他设置里面可以设置是否开启需要验证码\r\n增加  设置其他设置里面 控制前台首页是否显示全站累计成交额\r\n增加元宝网首页模板，可在后台其他配置里面设置\r\n\r\n这次更新需要改动首页模板文件\r\n需要改动前台底部公共文件\r\n如果自己改过模板请先自行备份好\r\n\r\n后期版本更新预告\r\n1.充值部分\r\n2.发布应用理财，话费，集市\r\n3.用户财务明细\r\n\r\n针对破解或者盗版\r\n我们会有相应政策，坚决打击\r\n\r\n\r\n', 'http://101.201.199.224/Update/download/2.3.6.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.5', '10013', '更新用户登录去掉验证码部分', '1465212260', '0', '更新用户登录去掉验证码\r\n更新登录注册可能存在的漏洞\r\n更新版本泄露检查\r\n\r\n如果发现版本从你们这边泄露我们有权终止你的平台更新\r\n\r\n需要改动网站底部文件和网站首页文件\r\n请修改过模板的自行做好备份\r\n', 'http://101.201.199.224/Update/download/2.3.5.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.4', '10012', '后台交易管理添加撤销委托功能', '1464765371', '0', '后台交易管理添加撤销委托功能\r\n更新完成请后台清理一下缓存\r\n请更新之后仔细测试确认没有问题\r\n不要更新之后就不管了', 'http://101.201.199.224/Update/download/2.3.4.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.3', '10011', '增加新币投票功能', '1464695124', '0', '增加新币投票功能\r\n优化系统应用部分\r\n更新了前台头部文件', 'http://101.201.199.224/Update/download/2.3.3.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.2', '10010', '页面提示功能', '1464681746', '0', '增加每个页面带提示功能\r\n这次更新之后前台模板再不会大面积改动了\r\n\r\n更新完成后台清理一下缓存\r\n在设置--提示文字里面可以配置\r\n如果没有叨叨请多刷新一下基本设置页面\r\n', 'http://101.201.199.224/Update/download/2.3.2.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.5', '10023', '优化财务部分', '1467270688', '1467277927', '优化人民币充值 提现\r\n优化虚拟币转入 转出\r\n\r\n需要重新配置充值方式', 'http://101.201.199.224/Update/download/2.4.5.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.4', '10022', '更新后台交易管理部分', '1467266348', '1467277897', '更新后台交易管理部分', 'http://101.201.199.224/Update/download/2.4.4.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.3', '10021', '优化后台菜单部分', '1467265786', '1467277868', '优化后台菜单部分', 'http://101.201.199.224/Update/download/2.4.3.zip', '0', '0');

-- -----------------------------
-- Table structure for `movesay_version_game`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_version_game`;
CREATE TABLE `movesay_version_game` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `number` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='应用管理表';

-- -----------------------------
-- Records of `movesay_version_game`
-- -----------------------------
INSERT INTO `movesay_version_game` VALUES ('1', 'shop', '云购商城', '0');
INSERT INTO `movesay_version_game` VALUES ('2', 'fenhong', '分红中心', '0');
INSERT INTO `movesay_version_game` VALUES ('3', 'huafei', '话费充值', '0');
INSERT INTO `movesay_version_game` VALUES ('4', 'issue', '认购中心', '0');
INSERT INTO `movesay_version_game` VALUES ('5', 'vote', '新币投票', '0');
INSERT INTO `movesay_version_game` VALUES ('6', 'money', '理财中心', '0');
INSERT INTO `movesay_version_game` VALUES ('7', 'bazaar', '集市交易', '0');
