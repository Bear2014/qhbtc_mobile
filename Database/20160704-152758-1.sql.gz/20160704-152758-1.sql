-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : mydbbtc.cltb6pznmc6g.ap-northeast-1.rds.amazonaws.com
-- Port     : 3306
-- Database : move
-- 
-- Part : #1
-- Date : 2016-07-04 15:27:58
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `movesay_admin`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_admin`;
CREATE TABLE `movesay_admin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `username` char(16) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `moble` varchar(50) NOT NULL,
  `password` char(32) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `last_login_time` int(11) unsigned NOT NULL,
  `last_login_ip` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='管理员表';

-- -----------------------------
-- Records of `movesay_admin`
-- -----------------------------
INSERT INTO `movesay_admin` VALUES ('1', '', 'admin123', '', '', '0192023a7bbd73250516f069df18b500', '0', '0', '0', '0', '0', '1');
INSERT INTO `movesay_admin` VALUES ('4', '', 'movesay', '', '', '0192023a7bbd73250516f069df18b500', '0', '0', '0', '0', '0', '1');
INSERT INTO `movesay_admin` VALUES ('6', '', 'btc100', '大一', '', 'btc100', '0', '1467289686', '0', '0', '0', '1');
INSERT INTO `movesay_admin` VALUES ('7', '', 'btc1000', '啊啊啊', '13888888888', '123456', '0', '1467609223', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `movesay_adver`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_adver`;
CREATE TABLE `movesay_adver` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `url` varchar(255) NOT NULL,
  `img` varchar(250) NOT NULL,
  `type` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='广告图片表';

-- -----------------------------
-- Records of `movesay_adver`
-- -----------------------------
INSERT INTO `movesay_adver` VALUES ('15', '最专业的交易平台', '', '5775e5ad38f6d.jpg', '', '0', '0', '0', '1');
INSERT INTO `movesay_adver` VALUES ('3', '幻灯片', '', '5779eee87de1e.jpg', 'index', '0', '1446829556', '0', '1');
INSERT INTO `movesay_adver` VALUES ('16', '图', '', '5779eecebd5bd.jpg', '', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `movesay_article`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_article`;
CREATE TABLE `movesay_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `adminid` int(10) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `hits` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `type` (`type`),
  KEY `adminid` (`adminid`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COMMENT='系统文章表';

-- -----------------------------
-- Records of `movesay_article`
-- -----------------------------
INSERT INTO `movesay_article` VALUES ('1', '办公环境', '<p>\r\n	<span style=\"font-size:16px;\">2016年6月11日正式上线</span>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>', '1', 'aboutus', '0', '0', '1447196517', '0', '1');
INSERT INTO `movesay_article` VALUES ('2', '法律声明', '<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<br />\r\n</p>', '1', 'aboutus', '0', '0', '1447196754', '0', '1');
INSERT INTO `movesay_article` VALUES ('3', '用户协议', '', '1', 'aboutus', '0', '0', '1447196832', '0', '1');
INSERT INTO `movesay_article` VALUES ('4', '资质证明', '', '1', 'aboutus', '0', '0', '1447196898', '0', '1');
INSERT INTO `movesay_article` VALUES ('5', '联系我们', '', '1', 'aboutus', '0', '0', '1447197626', '0', '1');
INSERT INTO `movesay_article` VALUES ('6', '关于我们', '', '1', 'aboutus', '0', '0', '1441733195', '0', '1');
INSERT INTO `movesay_article` VALUES ('8', '新人必看--登录注册详细说明', '', '1', 'help', '0', '0', '0', '0', '1');
INSERT INTO `movesay_article` VALUES ('9', '新人必看--平台交易详细说明', '', '1', 'help', '0', '0', '1447197238', '0', '1');
INSERT INTO `movesay_article` VALUES ('10', '新人必看--自助充值详细说明', '目前支持支付宝充值 &nbsp;充值成功后立即到账&nbsp;', '1', 'help', '0', '0', '1447197283', '0', '1');
INSERT INTO `movesay_article` VALUES ('11', '新人必看--申请提现详细说明', '关于提现说明 每次提现收取1%手续费 &nbsp;需要完成实名认证', '1', 'help', '0', '0', '1447197343', '0', '1');
INSERT INTO `movesay_article` VALUES ('12', '新人必看--修改密码详细说明', '即将公布', '1', 'help', '0', '0', '1447197369', '0', '1');
INSERT INTO `movesay_article` VALUES ('13', '新人必看--实名认证详细说明', '', '1', 'help', '0', '0', '1447196898', '0', '1');
INSERT INTO `movesay_article` VALUES ('21', '这里是最新公告', '', '1', 'notice', '0', '0', '1452514770', '0', '1');
INSERT INTO `movesay_article` VALUES ('26', '新人必看--应用中心详细说明', '', '1', 'help', '0', '0', '1447196898', '0', '1');
INSERT INTO `movesay_article` VALUES ('27', '这是帮助中心文章', '', '1', 'help', '0', '0', '1452514759', '0', '1');
INSERT INTO `movesay_article` VALUES ('30', '这是行业资讯文章', '', '1', 'news', '0', '0', '1452514748', '0', '1');
INSERT INTO `movesay_article` VALUES ('32', '这里是最新公告', '', '1', 'notice', '0', '0', '1452514770', '0', '1');
INSERT INTO `movesay_article` VALUES ('49', '这里是最新公告', '', '1', 'notice', '0', '0', '1452514770', '0', '1');
INSERT INTO `movesay_article` VALUES ('50', '2016年6月16日提现到账公告', '', '1', 'news', '0', '0', '1447196898', '0', '1');
INSERT INTO `movesay_article` VALUES ('64', '澳维币即将上线', '澳维币即将上线', '1', 'notice', '0', '0', '1447196898', '0', '1');
INSERT INTO `movesay_article` VALUES ('65', '区块链上的分布式物联网', '<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	想象一下你的洗衣机，当洗涤剂不够时可以自动联系供应商，并进行自助下订单购物，进行自我维护，从外部资源处下载新的洗衣程序，根据电价的变化周期来安排最经济的洗衣计划表，还能和它的传感器互动来决定最优化的洗衣环境；再想象一辆汽车，实时联网，可以智能的选择最合适的零件和服务；还有这样的制造厂，它们的机械在没有人工干预的情况下，知道自己的哪个部位什么时候需要修理。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	以上的这些场景，在物联网（the Internet of Things IoT）的帮助下将会成为现实。事实上，那些曾不适应电脑的的产业已经被数十亿计的连接互联网的物联网设备改变；还没有被改变的产业，最终将在这样的浪潮中被迫跟上这种步伐。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	<img src=\"http://7xqy72.com1.z0.glb.clouddn.com/public/resources/pic/news/2016/06/30/c0h1pzUyRV_IoT.jpg\" style=\"height:auto;\" />\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	未来的可能性是无限的，特别是当物联网和其它技术结合所产生的力量，比如和机器学习结合。然而，数十亿的智能设备之间想要产生互动，或者和它们的拥有者互动，那么就会出现一些大问题。当现存的支持物联网通信的模型无法应对这样的挑战时，相关的技术公司和一些研究人员希望通过区块链技术来解决它们，这个技术就是大名鼎鼎的<a name=\"tuilink_a_5dfe53e3dre3\" href=\"http://www.tuiunion.com/tuilink/redirect/8/?domain=www.btckan.com\" target=\"_black\">比特币</a>背后的基石。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	<strong>中心化模型的问题</strong>\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	当前的物联网生态依赖于中心化系统，中介通信模型，也就是我们熟知的服务器/客户端（server/client）模型。拥有巨大计算能力和存储空间的云服务器与被标记和验证的设备相连。设备间的只通过互联网连接，即使它们只相隔几英尺。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	这种模型在通用的计算设备连接中运行了几十年，它还会存在于小规模的物联网网络中，正如我们现在所看到的那些。然而在未来逐渐增长为大规模的物联网生态上，这种模型就会显得无能了。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	现存的物联网方案是昂贵的，因为它的基础设施和维护费用极高，它需要中心云服务、大规模服务器集群和网络设备。当物联网设备以数十亿级别的速度增长时，它们之间要处理的通信量更是惊人，这样以来的费用会大幅度的增长。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	即使这种经济上和工程上的挑战不是问题，那么云服务器依然存在瓶颈，还有就是它出现一个故障点就会导致整个网络的崩溃。如果将来人类的生命健康依赖于物联网，那么这个问题就非常非常的严重。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	另外，不同设备间的多样化所有权，和它们支持的云服务架构多元化让机器对机器（machine-to-machine M2M）通信很困难。没有一个单独的设备可以连接其他所有设备，不同的云服务提供商也不会保证它们之间的互操作性和兼容性。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	<strong>分布式物联网（IoT）网络</strong>\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	物联网的分布式方案可以解决以上的很多问题。采用标准化的点对点通信模型处理成千上万设备间的交易，这有效的削减了成本，包括部署和维护大型数据中心的费用，而且可以通过成千上万的物联网设备把计算需求和存储需求去中心化。这将避免由于一个节点的失败而导致整个网络的崩溃。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	可是，建立点对点通信也有它自己的问题，其中首要问题是安全。我们都知道，物联网的安全不仅仅只是要保护敏感数据。解决方案必须在大规模物联网网络中保护隐私安全，还要为交易提供一些验证形式和共识形式，来避免被欺诈和偷盗。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	<strong>区块链方案</strong>\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	对于点对点通信平台问题，<a href=\"http://www.btckan.com/redirect?url=+http%3A%2F%2F8btc.com%2Farticle-44-1.html\">区块链</a>给出了精妙的解决方案，这种技术在网络节点间创建一种相互共享的分布式数字账簿，来记录交易，而不是把这些交易账簿存储于一个中心服务器。参与者通过区块链来记录交易。这个技术使用加密技术认证识别参与节点，保证它们安全的在账簿中添加交易记录。交易是被这个网络中的节点所验证和确认，所以这就消除了中心验证的必要性。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	这个账簿是防干扰和不可被恶意者修改的，因为它不单独存在于本地独立设备，它也不可能被中间人攻击，因为交易不是可被拦截的单独一个线程。区块链让去信任化、点对点通信成为现实，而且它在金融服务领域的价值已经通过加密货币（如<a name=\"tuilink_a_5dfe53e3dre3\" href=\"http://www.tuiunion.com/tuilink/redirect/8/?domain=www.btckan.com\" target=\"_black\">比特币</a>）证明，它在没有第三方支付参与的情况下为点对点支付做保障。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	科技公司现在试图让区块链的实用性与网联网领域磨合。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	这个概念可以直接解决物联网的规模化问题，不需要传统的昂贵资源就可以让数十亿计的设备共享于一个相同网络。区块链也可以解决不同供应商间的权威冲突，它提供了一个标准，让每个人有平等的权益。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	这将打通M2M(机器对机器)间的通信，在当前的模型中，这是无法实现的，这也让一些全新的使用案例成为现实。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	<strong>在物联网中混合使用区块链</strong>\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	物联网和区块链的结合正蓄势待发，创业公司和科技巨头都非常看好。IBM和三星引入他们的概念证明，ADEPT使用区块链技术支持下一代物联网生态，每天将会产生千亿计的交易。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	IBM作为最早研究把区块链用于物联网中的企业之一，IBM的Paul Brody 这样描述：新设备被工厂组装完成后在一个通用的区块链中注册，在被出售后转移进一个区域区块链，在这个区块链上它们可以与其它设备自主互动。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	物联网和区块链的结合让循环经济和资产流体化成为可能，资源可以被共享和再利用，而不是消费一次就处理掉。区块链平台领导者以太坊举办的物联网黑客马拉松中，一个区块链驱动的物联网概念被测试，其中还有很多非常有创意的项目，其中包括能源分享、电力燃气账单等领域中的项目。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	Filament是一个投身于物联网和区块链的创业公司，它专注于工业应用，像农业、制造业、石油和天然气等。Filament 使用一种名叫Taps的无线传感器，组成低功耗自治网状网络，来收集数据，监控资产，而且不需要云服务或中心网络服务器的参与。这家公司使用区块链技术识别认证设备，通过提供这样的网络和数据服务来获得收入，当然是以<a name=\"tuilink_a_5dfe53e3dre3\" href=\"http://www.tuiunion.com/tuilink/redirect/8/?domain=www.btckan.com\" target=\"_black\">比特币</a>为支付方式。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	Chain of Things 是一个联盟，他们的任务是探索区块链在处理物联网规模化和安全问题中所能扮演的角色。他们在最近伦敦举行的黑客马拉松中展示了区块链 和物联网的使用案例，包括一种太阳能堆栈设计，它可以提供可靠地、可验证的再生资源数据，加速刺激结算，减少其中的欺诈。这个系统加强了太阳能面板和数据记录器的连接过程，跟踪太阳能的生产量，安全的把这些数据提交给节点，节点把这些数据记录在分布式账簿中，然后在范围更广的全球节点网络同步。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	<strong>警示和挑战</strong>\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	把区块链技术应用于物联网并不是没有缺点的，还有一些问题需要解决。其一就是，在<a name=\"tuilink_a_5dfe53e3dre3\" href=\"http://www.tuiunion.com/tuilink/redirect/8/?domain=www.btckan.com\" target=\"_black\">比特币</a>开发者之间争吵不断的区块链基础问题，这个问题产生于，随着这个网络的发展，交易量和体积越来越大，当区块链技术应用于物联网时，这个问题也不可避免。科技公司也承认这是一种挑战，然而有一些解决方案正在测试，其中包括侧链、树链和迷你区块等方案。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	能源消耗也是一个问题，加密和验证区块链交易是一种计算力集约操作，需要消耗大量的电力资源，这是物联网设备所缺少的。与此同时，还需要较大的存储空间，随着账簿的增长，节点的存储空间需求也越来越大。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	还有，如Machina Research 的研究者 Jeremy Green所说，以区块链作为驱动的自治物联网对制造商来说，最大的挑战时寻求一种商业模型，其中包括持续盈利的长期合作伙伴，而且需要一个商业和经济模型的大转型。\r\n</p>\r\n<p style=\"color:#333333;font-family:ff-tisa-web-pro-1, ff-tisa-web-pro-2, \'Lucida Grande\', \'Helvetica Neue\', Helvetica, Arial, \'Hiragino Sans GB\', \'Hiragino Sans GB W3\', \'Microsoft YaHei UI\', \'Microsoft YaHei\', \'WenQuanYi Micro Hei\', sans-serif;font-size:15px;background-color:#FCFCFC;\">\r\n	物联网产业发展飞速，区块链是否是解决物联网面临的困难的关键，现在下结论还为时过早。它还不完美，然而与物联网结合非常的有希望，分布式自治网络将成为解决问题的关键因素。\r\n</p>', '1', 'news', '0', '0', '1467287166', '0', '1');

-- -----------------------------
-- Table structure for `movesay_article_type`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_article_type`;
CREATE TABLE `movesay_article_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `index` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='分组分类别';

-- -----------------------------
-- Records of `movesay_article_type`
-- -----------------------------
INSERT INTO `movesay_article_type` VALUES ('1', 'news', '行业资讯', '行业资讯', '1', '2', '0', '0', '1');
INSERT INTO `movesay_article_type` VALUES ('2', 'notice', '最新公告', '最新公告', '1', '1', '0', '0', '1');
INSERT INTO `movesay_article_type` VALUES ('3', 'help', '帮助中心', '帮助中心', '1', '3', '0', '0', '1');
INSERT INTO `movesay_article_type` VALUES ('4', 'aboutus', '关于我们', '关于我们', '0', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `movesay_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_auth_extend`;
CREATE TABLE `movesay_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_auth_extend`
-- -----------------------------
INSERT INTO `movesay_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `movesay_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `movesay_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `movesay_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `movesay_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `movesay_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `movesay_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `movesay_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `movesay_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_auth_group`;
CREATE TABLE `movesay_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_auth_group`
-- -----------------------------
INSERT INTO `movesay_auth_group` VALUES ('1', 'admin', '1', '资讯管理员', '拥有网站文章资讯相关权限', '1', '134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189,192,193,194,195,196,197,198,199,200,201,204,205,206,207,208,209,212,213,214,217,218,219,220,221,222,223,224,225,226,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,');
INSERT INTO `movesay_auth_group` VALUES ('3', 'admin', '1', '超级管理员', '超级管理员组,拥有系统所有权限', '1', '134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,151,152,153,154,155,156,157,158,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,179,180,181,182,183,184,185,186,187,188,189,192,193,194,195,196,197,200,201,204,205,206,207,208,209,212,213,214,218,219,220,221,222,223,224,225,226,228,229,230,231,232,233,234,235,236,237,238,239,240,241,242,243,244,245,246,247,248,251,252,253,254,255,256,257,258,259,260,261,262,263,264,265,266,267,268,269,270,271,272,273,274,275,');
INSERT INTO `movesay_auth_group` VALUES ('2', 'admin', '1', '财务管理组', '拥有网站资金相关的权限', '1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195');
INSERT INTO `movesay_auth_group` VALUES ('4', 'admin', '1', '资讯管理员', '拥有网站文章资讯相关权限11', '-1', '');
INSERT INTO `movesay_auth_group` VALUES ('5', 'admin', '1', '资讯管理员', '拥有网站文章资讯相关权限', '1', '');
INSERT INTO `movesay_auth_group` VALUES ('6', 'admin', '1', '财务管理组', '拥有网站资金相关的权限333', '1', '');

-- -----------------------------
-- Table structure for `movesay_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_auth_group_access`;
CREATE TABLE `movesay_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_auth_group_access`
-- -----------------------------
INSERT INTO `movesay_auth_group_access` VALUES ('2', '3');
INSERT INTO `movesay_auth_group_access` VALUES ('3', '1');
INSERT INTO `movesay_auth_group_access` VALUES ('7', '3');

-- -----------------------------
-- Table structure for `movesay_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_auth_rule`;
CREATE TABLE `movesay_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=283 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_auth_rule`
-- -----------------------------
INSERT INTO `movesay_auth_rule` VALUES ('228', 'admin', '1', 'Admin/Coin/edit', '编辑', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('227', 'admin', '1', 'Admin/Config/bank_edit', '编辑', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('226', 'admin', '1', 'Admin/Config/bank', '银行配置', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('225', 'admin', '1', 'Admin/Trade/comment', '币种评论', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('224', 'admin', '1', 'Admin/Finance/mytx', '人民币提现', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('223', 'admin', '1', 'Admin/Finance/mytxExcel', '导出选中', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('222', 'admin', '1', 'Admin/Article/adver', '广告管理', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('221', 'admin', '1', 'Admin/Index/market', '市场统计', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('220', 'admin', '1', 'Admin/Finance/myczType', '人民币充值方式', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('219', 'admin', '1', 'Admin/Tools/database?type=export', '数据备份', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('218', 'admin', '1', 'Admin/Config/contact', '客服配置', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('217', 'admin', '1', 'Admin/Issuelog/index', '认购记录', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Mycztype/status', '状态修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Mycz/status', '修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('214', 'admin', '1', 'Admin/AuthManager/index', '权限列表', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Usercoin/edit', '财产修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Trade/chat', '交易聊天', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Chat/status', '修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Chat/edit', '编辑', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Finance/mytxStatus', '修改状态', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Finance/myczTypeImage', '上传图片', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Finance/myczTypeStatus', '状态修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('206', 'admin', '1', 'Admin/Article/type', '文章类型', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('205', 'admin', '1', 'Admin/Cloud/game', '应用管理', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('204', 'admin', '1', 'Admin/Index/coin', '币种统计', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('203', 'admin', '1', 'Admin/Link/status', '修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('202', 'admin', '1', 'Admin/Link/edit', '编辑', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('201', 'admin', '1', 'Admin/Invit/config', '推广配置', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('200', 'admin', '1', 'Admin/Config/moble', '短信配置', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('199', 'admin', '1', 'Admin/Issue/status', '认购修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('198', 'admin', '1', 'Admin/Issue/edit', '认购编辑', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('197', 'admin', '1', 'Admin/Tradelog/index', '交易记录', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('196', 'admin', '1', 'Admin/Finance/mycz', '人民币充值', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('195', 'admin', '1', 'Admin/User/index_status', '修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('194', 'admin', '1', 'Admin/User/index_edit', '编辑', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('193', 'admin', '1', 'Admin/Trade/log', '成交记录', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('192', 'admin', '1', 'Admin/User/adminUser', '管理员管理', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('191', 'admin', '1', 'Admin/Adver/status', '修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('190', 'admin', '1', 'Admin/Adver/edit', '编辑', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('189', 'admin', '1', 'Admin/Article/images', '上传图片', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('188', 'admin', '1', 'Admin/Articletype/edit', '编辑', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('187', 'admin', '1', 'Admin/Index/operate', '市场统计', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('186', 'admin', '1', 'AdminUser/edit', '后台用户编辑', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('185', 'admin', '1', 'AdminUser/add', '后台用户新增', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('184', 'admin', '1', 'AdminUser/status', '后台用户状态', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('183', 'admin', '1', 'AdminUser/detail', '后台用户详情', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('182', 'admin', '1', 'Admin/Cloud/update', '自动升级', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('181', 'admin', '1', 'Admin/Finance/myczTypeEdit', '编辑添加', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('180', 'admin', '1', 'Admin/Invit/index', '推广奖励', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('179', 'admin', '1', 'Admin/Config/index', '基本配置', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('178', 'admin', '1', 'Admin/Issue/index', '认购管理', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('177', 'admin', '1', 'Admin/Trade/index', '委托管理', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('176', 'admin', '1', 'Admin/Finance/type_status', '状态修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('175', 'admin', '1', 'Admin/Finance/type', '类型', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('174', 'admin', '1', 'Admin/Finance/config', '配置', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('173', 'admin', '1', 'Admin/Finance/index', '财务明细', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('172', 'admin', '1', 'Admin/User/config', '用户配置', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('171', 'admin', '1', 'Admin/User/index', '用户管理', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('170', 'admin', '1', 'Admin/Text/status', '修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('169', 'admin', '1', 'Admin/Text/edit', '编辑', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('168', 'admin', '1', 'Admin/Text/index', '提示文字', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('167', 'admin', '1', 'Admin/Article/status', '修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('166', 'admin', '1', 'Admin/Article/edit', '编辑', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('165', 'admin', '1', 'Admin/Article/index', '文章管理', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('164', 'admin', '1', 'Admin/Index/index', '系统概览', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('163', 'admin', '2', 'Admin/Cloud/index', '扩展', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Tools/index', '工具', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Invit/index', '运营', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Config/index', '设置', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Game/index', '应用', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Trade/index', '交易', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Finance/index', '财务', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('156', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Article/index', '内容', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Index/index', '系统', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('153', 'admin', '1', 'Admin/User/setpwd', '设置密码', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('152', 'admin', '1', 'Admin/Login/loginout', '用户退出', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('151', 'admin', '1', 'Admin/Login/index', '用户登录', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('150', 'admin', '1', 'Admin/Shop/images', '图片', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('149', 'admin', '1', 'Admin/ExtA/index', '扩展管理', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('148', 'admin', '1', 'Admin/Trade/chexiao', '撤销挂单', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('147', 'admin', '1', 'Admin/Trade/status', '修改状态', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('146', 'admin', '1', 'Admin/AuthManager/addToModel', '模型添加到用户组', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('145', 'admin', '1', 'Admin/AuthManager/addToCategory', '分类添加到用户组', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('144', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '用户组移除', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('143', 'admin', '1', 'Admin/AuthManager/addToGroup', '添加到用户组', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('142', 'admin', '1', 'Admin/AuthManager/group', '用户组', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('141', 'admin', '1', 'Admin/AuthManager/tree', '成员列表授权', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('140', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('139', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('138', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('137', 'admin', '1', 'Admin/AuthManager/changeStatus', '改变状态', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('136', 'admin', '1', 'Admin/AuthManager/writeGroup', '更新用户组', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('135', 'admin', '1', 'Admin/AuthManager/editgroup', '编辑用户组', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('134', 'admin', '1', 'Admin/AuthManager/createGroup', '新增用户组', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('229', 'admin', '1', 'Admin/Coin/status', '状态修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('230', 'admin', '1', 'Admin/Market/edit', '编辑市场', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('231', 'admin', '1', 'Admin/User/log', '登陆日志', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('232', 'admin', '1', 'Admin/Config/market_add', '状态修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('233', 'admin', '1', 'Admin/Tools/database?type=import', '数据还原', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('234', 'admin', '1', 'Admin/Tools/delcahe', '清理缓存', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('235', 'admin', '1', 'Admin/Tools/invoke', '其他模块调用', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('236', 'admin', '1', 'Admin/Tools/optimize', '优化表', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('237', 'admin', '1', 'Admin/Tools/repair', '修复表', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('238', 'admin', '1', 'Admin/Tools/del', '删除备份文件', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('239', 'admin', '1', 'Admin/Tools/export', '备份数据库', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('240', 'admin', '1', 'Admin/Tools/import', '还原数据库', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('241', 'admin', '1', 'Admin/Tools/excel', '导出数据库', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('242', 'admin', '1', 'Admin/Tools/exportExcel', '导出Excel', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('243', 'admin', '1', 'Admin/Tools/importExecl', '导入Excel', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('244', 'admin', '1', 'Admin/User/detail', '用户详情', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('245', 'admin', '1', 'Admin/Article/link', '友情链接', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('246', 'admin', '1', 'Admin/Finance/mytxChuli', '正在处理', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('247', 'admin', '1', 'Admin/Finance/mytxConfig', '人民币提现配置', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('248', 'admin', '1', 'Admin/Trade/market', '交易市场', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('249', 'admin', '1', 'Admin/Mytx/status', '状态修改', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('250', 'admin', '1', 'Admin/Mytx/excel', '取消', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('251', 'admin', '1', 'Admin/Mytx/exportExcel', '导入excel', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('252', 'admin', '1', 'Admin/Coin/index', '币种配置', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('253', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('254', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('255', 'admin', '1', 'Admin/Menu/add', '添加', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('256', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('257', 'admin', '1', 'Admin/Menu/del', '删除', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('258', 'admin', '1', 'Admin/Menu/toogleHide', '是否隐藏', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('259', 'admin', '1', 'Admin/Menu/toogleDev', '是否开发', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('260', 'admin', '1', 'Admin/Menu/importFile', '导入文件', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('261', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('262', 'admin', '1', 'Admin/User/qianbao', '用户钱包', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('263', 'admin', '1', 'Admin/Config/text', '提示文字', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('264', 'admin', '1', 'Admin/Tools/queue', '队列状态', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('265', 'admin', '1', 'Admin/Tools/qianbao', '钱包检查', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('266', 'admin', '1', 'Admin/Finance/mytxChexiao', '撤销提现', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('267', 'admin', '1', 'Admin/User/bank', '提现地址', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('268', 'admin', '1', 'Admin/Finance/myzr', '虚拟币转入', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('269', 'admin', '1', 'Admin/Trade/invit', '交易推荐', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('270', 'admin', '1', 'Admin/Market/index', '市场配置', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('271', 'admin', '1', 'Admin/Finance/mytxQueren', '确认提现', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('272', 'admin', '1', 'Admin/Finance/myzcQueren', '确认转出', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('273', 'admin', '1', 'Admin/Verify/code', '图形验证码', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('274', 'admin', '1', 'Admin/Verify/mobile', '手机验证码', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('275', 'admin', '1', 'Admin/Verify/email', '邮件验证码', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('276', 'admin', '1', 'Admin/Config/qita', '其他配置', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('277', 'admin', '1', 'Admin/Finance/myzc', '虚拟币转出', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('278', 'admin', '1', 'Admin/User/coin', '用户财产', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('279', 'admin', '1', 'Admin/User/myzc_qr', '确认转出', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('280', 'admin', '1', 'Admin/User/goods', '联系地址', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('281', 'admin', '1', 'Admin/Finance/myczStatus', '修改状态', '1', '');
INSERT INTO `movesay_auth_rule` VALUES ('282', 'admin', '1', 'Admin/Finance/myczQueren', '确认到账', '1', '');

-- -----------------------------
-- Table structure for `movesay_bazaar`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_bazaar`;
CREATE TABLE `movesay_bazaar` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `coin` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `deal` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `fee` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='集市交易表';


-- -----------------------------
-- Table structure for `movesay_bazaar_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_bazaar_log`;
CREATE TABLE `movesay_bazaar_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `peerid` int(11) unsigned NOT NULL,
  `coin` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `fee` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`),
  KEY `peerid` (`peerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='集市交易记录表';


-- -----------------------------
-- Table structure for `movesay_category`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_category`;
CREATE TABLE `movesay_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `movesay_category`
-- -----------------------------
INSERT INTO `movesay_category` VALUES ('1', 'blog', '默认', '0', '0', '10', '', '', '', '', '', '', '', '2', '2,1', '0', '0', '1', '0', '0', '1', '', '1379474947', '1382701539', '1', '0');
INSERT INTO `movesay_category` VALUES ('2', 'default_blog', '默认分类', '1', '1', '10', '', '', '', '', '', '', '', '2', '2,1,3', '0', '1', '1', '0', '1', '1', '', '1379475028', '1386839751', '1', '31');

-- -----------------------------
-- Table structure for `movesay_chat`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_chat`;
CREATE TABLE `movesay_chat` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` varchar(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文字聊天表';


-- -----------------------------
-- Table structure for `movesay_coin`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_coin`;
CREATE TABLE `movesay_coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `img` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `fee_bili` varchar(50) NOT NULL,
  `endtime` int(11) unsigned NOT NULL COMMENT '',
  `addtime` int(11) unsigned NOT NULL,
  `status` int(4) unsigned NOT NULL,
  `dj_zj` varchar(200) NOT NULL,
  `dj_dk` varchar(200) NOT NULL,
  `dj_yh` varchar(200) NOT NULL,
  `dj_mm` varchar(200) NOT NULL,
  `zr_zs` varchar(50) NOT NULL,
  `zr_jz` varchar(50) NOT NULL,
  `zr_dz` varchar(50) NOT NULL,
  `zr_sm` varchar(50) NOT NULL,
  `zc_sm` varchar(50) NOT NULL,
  `zc_fee` varchar(50) NOT NULL,
  `zc_user` varchar(50) NOT NULL,
  `zc_min` varchar(50) NOT NULL,
  `zc_max` varchar(50) NOT NULL,
  `zc_jz` varchar(50) NOT NULL,
  `zc_zd` varchar(50) NOT NULL,
  `js_yw` varchar(50) NOT NULL,
  `js_sm` text NOT NULL,
  `js_qb` varchar(50) NOT NULL,
  `js_ym` varchar(50) NOT NULL,
  `js_gw` varchar(50) NOT NULL,
  `js_lt` varchar(50) NOT NULL,
  `js_wk` varchar(50) NOT NULL,
  `cs_yf` varchar(50) NOT NULL,
  `cs_sf` varchar(50) NOT NULL,
  `cs_fb` varchar(50) NOT NULL,
  `cs_qk` varchar(50) NOT NULL,
  `cs_zl` varchar(50) NOT NULL,
  `cs_cl` varchar(50) NOT NULL,
  `cs_zm` varchar(50) NOT NULL,
  `cs_nd` varchar(50) NOT NULL,
  `cs_jl` varchar(50) NOT NULL,
  `cs_ts` varchar(50) NOT NULL,
  `cs_bz` varchar(50) NOT NULL,
  `tp_zs` varchar(50) NOT NULL,
  `tp_js` varchar(50) NOT NULL,
  `tp_yy` varchar(50) NOT NULL,
  `tp_qj` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COMMENT='币种配置表';

-- -----------------------------
-- Records of `movesay_coin`
-- -----------------------------
INSERT INTO `movesay_coin` VALUES ('1', 'cny', 'rmb', '人民币', 'cny.png', '0', '', '0', '0', '1', '182.254.134.191', '0', '0', '0', '0', '1', '0', '0', '0', '', '', '', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `movesay_coin` VALUES ('43', 'btc', 'qbb', '比特币', '5774fdc823ff6.jpg', '0', '100', '0', '0', '1', '', '', '', '', '0', '1', '1', '', '', '0.01', '0', '0', '10000', '1', '10', 'bitcoin', '<div class=\"para\" style=\"font-size:14px;color:#333333;font-family:arial, 宋体, sans-serif;background-color:#FFFFFF;\">\r\n	&nbsp; &nbsp; &nbsp; &nbsp;比特币（BitCoin）的概念最初由中本聪在2009年提出，根据中本聪的思路设计发布的开源软件以及建构其上的<a target=\"_blank\" href=\"http://baike.baidu.com/view/3280.htm\">P2P</a>网络。比特币是一种P2P形式的数字货币。点对点的传输意味着一个去中心化的支付系统。\r\n</div>\r\n<div class=\"para\" style=\"font-size:14px;color:#333333;font-family:arial, 宋体, sans-serif;background-color:#FFFFFF;\">\r\n	与大多数货币不同，比特币不依靠特定货币机构发行，它依据特定算法，通过大量的计算产生，比特币经济使用整个P2P网络中众多节点构成的<a target=\"_blank\" href=\"http://baike.baidu.com/view/68389.htm\">分布式数据库</a>来确认并记录所有的交易行为，并使用密码学的设计来确保货币流通各个环节<a target=\"_blank\" href=\"http://baike.baidu.com/view/421194.htm\">安全性</a>。P2P的去中心化特性与算法本身可以确保无法通过大量制造比特币来人为操控币值。基于密码学的设计可以使比特币只能被真实的拥有者转移或支付。这同样确保了货币所有权与流通交易的匿名性。比特币与其他<a target=\"_blank\" href=\"http://baike.baidu.com/view/16260.htm\">虚拟货币</a>最大的不同，是其总数量非常有限，具有极强的稀缺性。该货币系统曾在4年内只有不超过1050万个，之后的总数量将被永久限制在2100万个。\r\n</div>\r\n<div class=\"para\" style=\"font-size:14px;color:#333333;font-family:arial, 宋体, sans-serif;background-color:#FFFFFF;\">\r\n	比特币可以用来兑现，可以兑换成大多数国家的货币。使用者可以用比特币购买一些<a target=\"_blank\" href=\"http://baike.baidu.com/view/73493.htm\">虚拟物品</a>，比如网络游戏当中的衣服、<a target=\"_blank\" href=\"http://baike.baidu.com/view/54792.htm\">帽子</a>、装备等，只要有人接受，也可以使用比特币购买现实生活当中的物品。\r\n</div>', 'https://bitcoin.org/en/download', 'https://github.com/bitcoin/bitcoin', 'https://bitcoin.org', 'https://bitcointalk.org', 'https://en.bitcoin.it/wiki/Comparison_of_mining_po', 'Dorian S. Nakamoto', 'SHA-256', '2009/01/09', '600秒/块', '21000000', '14750000', 'pow', '2016', '50', '虚拟币始创者，受众最广，被信任最高', '确认时间长', '1', '5', '5', '5');
INSERT INTO `movesay_coin` VALUES ('44', 'ltc', 'qbb', '莱特币', '5774fef268879.png', '0', '0', '0', '0', '1', '', '', '', '', '0', '1', '3', '', '', '0.01', '0', '0', '10000', '1', '100', 'Litecoin', '<div class=\"para\" style=\"font-size:14px;color:#333333;font-family:arial, 宋体, sans-serif;background-color:#FFFFFF;\">\r\n	&nbsp; &nbsp; &nbsp; &nbsp; 莱特币Litecoin（简写：LTC，货币符号：Ł<span style=\"font-weight:700;\"></span>）是一种基于“点对点”(peer-to-peer)技术的<a target=\"_blank\" href=\"http://baike.baidu.com/view/1490463.htm\">网络货币</a>，也是MIT/X11许可下的一个开源软件项目。它可以帮助用户即时付款给世界上任何一个人。\r\n</div>\r\n<div class=\"para\" style=\"font-size:14px;color:#333333;font-family:arial, 宋体, sans-serif;background-color:#FFFFFF;\">\r\n	莱特币受到了<a target=\"_blank\" href=\"http://baike.baidu.com/subview/5784548/12216829.htm\">比特币</a>（BTC）的启发，并且在技术上具有相同的实现原理，莱特币的创造和转让基于一种开源的加密协议，不受到任何中央机构的管理。莱特币旨在改进比特币，与其相比，莱特币具有三种显著差异。第一，莱特币网络每2.5分钟（而不是10分钟）就可以处理一个块，因此可以提供更快的交易确认。第二，莱特币网络预期产出8400万个莱特币，是比特币网络发行货币量的四倍之多。第三，莱特币在其工作量证明算法中使用了由Colin Percival首次提出的scrypt加密算法，这使得相比于比特币，在普通计算机上进行莱特币挖掘更为容易。每一个莱特币被分成100,000,000个更小的单位，通过八位小数来界定。\r\n</div>', 'https://litecoin.org/zh_CN/', 'https://github.com/litecoin-project', 'https://litecoin.org/', 'http://explorer.litecoin.net/', 'https://litecointalk.org/', 'Charls Lee', 'Scrypt', '2011/10/7', '150秒/块', '84000000', '35123000', 'PoW', '2016 Blocks', '50LTC', '人气高、国内几大交易网站支持、开发能力强', '推广止步不前', '1', '5', '5', '5');
INSERT INTO `movesay_coin` VALUES ('46', 'avc', 'qbb', '澳维币', '577a0a8553e5c.png', '0', '0', '0', '0', '1', '', '', '', '', '0', '1', '1', '', '', '0', '0', '0', '10000', '1', '100', 'auvcoin', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- -----------------------------
-- Table structure for `movesay_coin_comment`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_coin_comment`;
CREATE TABLE `movesay_coin_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `content` varchar(500) NOT NULL,
  `cjz` int(11) unsigned NOT NULL,
  `tzy` int(11) unsigned NOT NULL,
  `xcd` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_coin_comment`
-- -----------------------------
INSERT INTO `movesay_coin_comment` VALUES ('1', '2', 'ltc', '莱特是银', '0', '0', '0', '0', '1467291380', '0', '1');
INSERT INTO `movesay_coin_comment` VALUES ('2', '2', 'btc', '比特是金', '0', '0', '0', '0', '1467291420', '0', '1');
INSERT INTO `movesay_coin_comment` VALUES ('3', '2', 'ytc', '优特好', '0', '0', '0', '0', '1467291676', '0', '1');

-- -----------------------------
-- Table structure for `movesay_config`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_config`;
CREATE TABLE `movesay_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `web_name` varchar(200) NOT NULL,
  `web_title` varchar(200) NOT NULL,
  `web_logo` varchar(200) NOT NULL,
  `web_llogo_small` varchar(200) NOT NULL,
  `web_keywords` varchar(200) NOT NULL,
  `web_description` varchar(200) NOT NULL,
  `web_close` varchar(50) NOT NULL,
  `web_close_cause` varchar(200) NOT NULL,
  `web_icp` varchar(50) NOT NULL,
  `web_cnzz` text NOT NULL,
  `web_reg` text NOT NULL,
  `web_waring` text NOT NULL,
  `market_mr` varchar(50) NOT NULL,
  `xnb_mr` varchar(50) NOT NULL,
  `rmb_mr` varchar(50) NOT NULL,
  `moble_type` text NOT NULL,
  `moble_url` text NOT NULL,
  `moble_user` text NOT NULL,
  `moble_pwd` text NOT NULL,
  `contact_moble` text NOT NULL,
  `contact_weibo` text NOT NULL,
  `contact_tqq` text NOT NULL,
  `contact_qq` text NOT NULL,
  `contact_qqun` text NOT NULL,
  `contact_weixin` text NOT NULL,
  `contact_weixin_img` text NOT NULL,
  `contact_email` text NOT NULL,
  `contact_alipay` text NOT NULL,
  `contact_alipay_img` text NOT NULL,
  `contact_bank` text NOT NULL,
  `user_truename` text NOT NULL,
  `user_moble` text NOT NULL,
  `user_alipay` text NOT NULL,
  `user_bank` text NOT NULL,
  `mycz_min` text NOT NULL,
  `mycz_max` text NOT NULL,
  `mytx_min` text NOT NULL,
  `mytx_max` text NOT NULL,
  `mytx_bei` text NOT NULL,
  `mytx_coin` text NOT NULL,
  `mytx_fee` text NOT NULL,
  `trade_min` text NOT NULL,
  `trade_max` text NOT NULL,
  `trade_limit` text NOT NULL,
  `trade_text_index` text NOT NULL,
  `trade_text_entrust` text NOT NULL,
  `trade_text_log` text NOT NULL,
  `issue_ci` text NOT NULL,
  `issue_jian` text NOT NULL,
  `issue_min` text NOT NULL,
  `issue_max` text NOT NULL,
  `money_min` text NOT NULL,
  `money_max` text NOT NULL,
  `money_bei` text NOT NULL,
  `invit_type` text NOT NULL,
  `invit_fee1` text NOT NULL,
  `invit_fee2` text NOT NULL,
  `invit_fee3` text NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  `index_html` varchar(50) DEFAULT NULL,
  `invit_text_txt` text,
  `top_name` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- -----------------------------
-- Records of `movesay_config`
-- -----------------------------
INSERT INTO `movesay_config` VALUES ('1', '澳维科技', '澳维交易平台', '577a0d7756a02.jpg', '577a0d7756cff.jpg', '澳维币交易所,比特币交易平台，莱特币交易平台', '澳维科技交易所', '0', '升级中...', '粤ICP备88888888号-1', '<script type=\"text/javascript\">var cnzz_protocol = ((\"https:\" == document.location.protocol) ? \" https://\" : \" http://\");document.write(unescape(\"%3Cspan id=\'cnzz_stat_icon_1256773398\'%3E%3C/span%3E%3Cscript src=\'\" + cnzz_protocol + \"s11.cnzz.com/z_stat.php%3Fid%3D1256773398\' type=\'text/javascript\'%3E%3C/script%3E\"));</script>', '<div style=\"text-align:center;\">\r\n	<div style=\"text-align:left;\">\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			用户协议\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; &nbsp; &nbsp;澳维科技交易平台所提供的各项服务的所有权和运作权均归澳维科技有限公司所有。澳维科技交易平台用户注册使用协议（以下简称“本协议”） 系由澳维科技交易平台用户与澳维科技有限公司就澳维科技交易平台的各项服务所订立的相关权利义务规范。用户通过访问或使用本网站， 即表示接受并同意本协议的所有条件和条款。澳维科技有限公司作为澳维科技交易平台的运营者依据本协议为用户提供服务。不愿接受本协议条款的， 不得访问或使用本网站。澳维科技有限公司有权对本协议条款进行修改，修改后的协议一旦公布即有效代替原来的协议。用户可随时查阅最新协议。\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			服务内容\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、澳维科技有限公司运用自己的系统，通过互联网络等方式为用户提供虚拟币的交易服务。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、用户必须自行准备如下设备和承担如下开支：&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ①上网设备，包括并不限于电脑或者其他上网终端、调制解调器及其他上网装置。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ②上网开支，包括并不限于网络接入费、上网设备租用费、手机流量费等。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			3、用户提供的注册资料，用户必须同意：\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ①提供中华人民共和国大陆地区合法、真实、准确、详尽的个人资料。\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ②如有变动，及时更新用户资料。如果用户提供的注册资料不合法、不真实、不准确、不详尽的，用户需承担因此引起的相应责任及后果， 并且澳维科技有限公司保留终止用户使用澳维科技交易平台各项服务的权利。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			服务的提供、修改及终止\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、用户在接受澳维科技交易平台各项服务的同时，同意接受澳维科技交易平台提供的各类信息服务。 用户在此授权澳维科技有限公司可以向其电子邮件、手机、通信地址等发送商业信息。 用户有权选择不接受澳维科技交易平台提供的各类信息服务，并进入澳维科技交易平台相关页面进行更改。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、澳维科技交易平台保留随时修改或中断服务而不需通知用户的权利。澳维科技交易平台有权行使修改或中断服务的权利， 不需对用户或任何无直接关系的第三方负责。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			3、用户对本协议的修改有异议，或对澳维科技交易平台的服务不满，可以行使如下权利：&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ①停止使用澳维科技交易平台的网络服务。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ②通过客服等渠道告知澳维科技交易平台停止对其服务。 结束服务后，用户使用澳维科技交易平台网络服务的权利立即终止。 在此情况下，澳维科技交易平台没有义务传送任何未处理的信息或未完成的服务给用户或任何无直接关系的第三方。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			用户信息的保密\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、本协议所称之澳维科技交易平台用户信息是指符合法律、法规及相关规定，并符合下述范围的信息：\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ①用户注册澳维科技账户时，向澳维科技交易平台提供的个人信息。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ②用户在使用澳维科技交易平台服务、参加网站活动或访问网站网页时，澳维科技交易平台自动接收并记录的用户浏览器端或手机客户端数据， 包括但不限于IP地址、网站中的资料及用户要求取用的网页记录。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ③澳维科技交易平台从商业伙伴处合法获取的用户个人信息。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ④其它澳维科技交易平台通过合法途径获取的用户个人信息。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、澳维科技有限公司承诺：非经法定原因或用户事先许可，不会向任何第三方透露用户的密码、姓名、 手机号码等非公开信息。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			3、在下述法定情况下，用户的个人信息将会被部分或全部披露：&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ①经用户同意向用户本人或其他第三方披露。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ②根据法律、法规等相关规定，或行政机构要求，向行政、司法机构或其他法律规定的第三方披露。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ③其它澳维科技有限公司根据法律、法规等相关规定进行的披露。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			用户权利\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、用户的用户名、密码和安全性：&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; ①用户有权选择是否成为澳维科技交易平台用户，用户选择成为澳维科技交易平台注册用户时，可自行输入手机号为帐号。 用户名和帐号使用应遵守相关法律法规并符合网络道德。用户名和帐号中不能含有任何侮辱、威胁、淫秽、 谩骂等侵害他人合法权益的文字。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp;②用户一旦注册成功，成为澳维科技交易平台的用户，将得到用户名和密码， 并对以此组用户名和密码登入系统后所发生的所有活动和事件负责，自行承担一切使用该用户名的言语、 行为等而直接或者间接导致的法律责任。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp;③用户有义务妥善保管澳维科技交易平台账号、用户名和密码，用户将对用户名和密码安全负全部责任。 因用户原因导致用户名或密码泄露而造成的任何法律后果由用户本人负责，由于用户自身原因泄露这些信息导致的财产损失， 本站不负相关责任。由于本站是交易网站，登录密码、提现密码、交易密码等不得使用相同密码，否则会有安全隐患， 相关责任由用户自身承担。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			④用户密码遗失的，可以通过绑定的手机号码重置密码。用户若发现任何非法使用用户名或存在其他安全漏洞的情况， 应立即告知澳维科技交易平台运营平台。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑤澳维科技交易平台不会向任何用户索取密码，不会让用户往任何非本站交易中心里提供的帐户打款， 请大家不要相信任何非澳维科技有限公司提供的打折、优惠等诈骗信息，往非澳维科技交易平台提供的账户、 地址里打款或币造成的损失本站不负责任。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、用户有权根据网站相关规定，在发布信息等贡献后，取得澳维科技交易平台给予的奖励。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			3、用户有权修改其个人账户中各项可修改信息，自行录入介绍性文字，自行决定是否提供非必填项的内容。4、用户有权参加澳维科技交易平台组织提供的各项线上、线下活动。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			5、用户有权根据澳维科技交易平台网站规定，享受澳维科技交易平台提供的其它各类服务。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			用户义务\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、不得利用本站危害国家安全、泄露国家秘密，不得侵犯国家社会集体的和公民的合法权益，不得利用本站制作、 复制和传播下列信息：&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			①煽动抗拒、破坏宪法和法律、行政法规实施的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			②煽动颠覆国家政权，推翻社会主义制度的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			③煽动分裂国家、破坏国家统一的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			④煽动民族仇恨、民族歧视，破坏民族团结的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑤捏造或者歪曲事实，散布谣言，扰乱社会秩序的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑥宣扬封建迷信、淫秽、色情、赌博、暴力、凶杀、恐怖、教唆犯罪的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑦公然侮辱他人或者捏造事实诽谤他人的，或者进行其他恶意攻击的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑧损害国家机关信誉的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑨其他违反宪法和法律行政法规的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			⑩进行商业广告行为的。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、用户不得通过任何手段恶意注册澳维科技交易平台网站帐号，包括但不限于以牟利、炒作、套现、 获奖等为目的多个账号注册。用户亦不得盗用其他用户帐号,或者利用澳维科技交易平台以及交易平台漏洞刷取澳维科技。 如用户违反上述规定，则澳维科技交易平台有权直接采取一切必要的措施，包括但不限于删除用户发布的内容、 取消用户在网站获得的虚拟财富，暂停或查封用户帐号，取消因违规所获利益，乃至通过诉讼形式追究用户法律责任等。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			3、禁止用户将澳维科技交易平台以任何形式作为从事各种非法活动的场所、平台或媒介。 未经澳维科技交易平台运营平台的授权或许可，用户不得借用本站的名义从事任何商业活动， 也不得以任何形式将澳维科技交易平台作为从事商业活动的场所、平台或媒介。如用户违反上述规定， 则澳维科技交易平台运营平台有权直接采取一切必要的措施，包括但不限于删除用户发布的内容、取消用户在网站获得的虚拟财富， 暂停或查封用户帐号，取消因违规所获利益，乃至通过诉讼形式追究用户法律责任等。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			4、用户在澳维科技交易平台以各种形式发布的一切信息，均应符合国家法律法规等相关规定及网站相关规定， 符合社会公序良俗，并不侵犯任何第三方主体的合法权益，否则用户自行承担因此产生的一切法律后果， 且澳维科技有限公司因此受到的损失，有权向用户追偿。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			5、按照澳维科技有限公司的要求准确提供并及时更新您正确、最新及完整的身份信息及相关资料。 若澳维科技有限公司有合理理由怀疑您提供的身份信息即相关资料错误、不实、过失或不完整的， 澳维科技有限公司有权要求您补充相关资料来证明您身份的真实性。若您不能及时配合提供， 澳维科技有限公司有权暂停或终止向您提供服务。澳维科技有限公司对此不承担任何责任， 您将承担因此产生的任何直接或间接支出。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			6、用户应当有独立的风险承担能力，以及具备相应的民事行为能力，注册实名认证用户应为中国大陆地区公民， 年龄限制在16周岁~70周岁。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			拒绝担保与免责\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、澳维科技交易平台作为“网络服务提供者”的第三方平台，不担保网站平台上的信息及服务能充分满足用户的需求。 对于用户在接受澳维科技交易平台的服务过程中可能遇到的错误、侮辱、诽谤、不作为、淫秽、色情或亵渎事件， 澳维科技交易平台不承担法律责任。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、基于互联网的特殊性，澳维科技交易平台也不担保服务不会受中断，对服务的及时性、安全性都不作担保， 不承担非因澳维科技交易平台导致的责任。 澳维科技交易平台力图使用户能对本网站进行安全访问和使用， 但澳维科技交易平台不声明也不保证本网站或其服务器是不含病毒或其它潜在有害因素的。 因此用户应使用业界公认的软件查杀任何自澳维科技交易平台下载文件中的病毒。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			3、澳维科技交易平台不对用户所发布信息的保存、修改、删除或储存失败负责。 对网站上的非因澳维科技交易平台故意所导致的排字错误、疏忽等不承担责任。 澳维科技交易平台有权但无义务， 改善或更正本网站任何部分之疏漏、错误。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			4、除非澳维科技交易平台以书面形式明确约定，澳维科技交易平台对于用户以任何方式（包括但不限于包含、经由、连接或下载 ）从本网站所获得的任何内容信息，包括但不限于广告等，不保证其准确性、完整性、可靠性； 对于用户因本网站上的内容信息而购买、获取的任何产品、服务、信息或资料，澳维科技交易平台不承担责任。 用户自行承担使用本网站信息内容所导致的风险。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			5、澳维科技交易平台内所有用户所发表的用户评论，仅代表用户个人观点， 并不表示本网站赞同其观点或证实其描述，本网站不承担用户评论引发的任何法律责任。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			6、澳维科技有限公司有权删除澳维科技交易平台内各类不符合法律或协议规定的信息，而保留不通知用户的权利。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			7、所有发给用户的通告，澳维科技交易平台都将通过正式的页面公告、站内信、电子邮件、客服电话、 手机短信或常规的信件送达。任何非经澳维科技交易平台正规渠道获得的中奖、优惠等活动或信息， 澳维科技交易平台不承担法律责任。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			适用法律和裁判地点\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			1、因用户使用澳维科技交易平台而引起或与之相关的一切争议、权利主张或其它事项， 均受中华人民共和国法律的管辖。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			2、用户和澳维科技有限公司发生争议的，应首先本着诚信原则通过协商加以解决。 如果协商不成，则应向澳维科技有限公司所在地人民法院提起诉讼。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			可分性\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			如果本协议的任何条款被视为不合法、无效或因任何原因而无法执行，则此等规定应视为可分割， 不影响任何其它条款的法律效力。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			<br />\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			冲突选择\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			本协议是澳维科技有限公司与用户注册成为澳维科技交易平台用户，使用澳维科技交易平台服务之间的重要法律文件， 澳维科技有限公司或者用户的任何其他书面或者口头意思表示与本协议不一致的，均应当以本协议为准。&nbsp;\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;\r\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 澳维科技有限公司\r\n		</p>\r\n		<p class=\"MsoNormal\" align=\"left\">\r\n			&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;\r\n&nbsp; 2016年1月1日\r\n		</p>\r\n		<p>\r\n			<br />\r\n		</p>\r\n<br />\r\n	</div>\r\n</div>\r\n<p>\r\n	<span style=\"font-size:10px;color:#E56600;\"></span> \r\n</p>', '数字资产的交易存在极高风险(预挖、暴涨暴跌、庄家操控、团队解散、技术缺陷等)，作为全球的虚拟数字货币，他们都是全天24小时交易，没有涨跌限制，价格容易因为庄家、全球政府的政策影响而大幅波动，我们强烈建议您在自身能承受的风险范围内，参与虚拟货币交易，澳维网仅为数字货币的爱好者提供一个自由的网上交换平台，对币的投资价值不承担任何审查、担保、赔偿的责任，如果您不能接受，请不要进行交易！谢谢！', 'btc_cny', 'btc', 'cny', '1', 'http://utf8.sms.webchinese.cn', 'btc10000', 'c59a91906d969730df05', '13888888888', 'http://weibo.com/', 'http://t.qq.com/', '88888888|88888888', '00000000|22222222', '888888888', '577504af69bde.png', '88888888@qq.com', '88888888@qq.com', '577504af69fc0.png', '中国银行|优特科技|0000 0000 0000 0000', '2', '2', '2', '2', '10', '100000', '100', '10000', '100', 'cny', '1', '1', '10000000', '10', '', '&lt;span&gt;&lt;span&gt;长时间委托交易未成功的,自行点击--&lt;/span&gt;&lt;span style=&quot;color:#EE33EE;&quot;&gt;撤销&lt;/span&gt;&lt;span&gt;--重新定价委托,委托交易买入成功后,扣除相应的手续费,委托交易卖出&lt;/span&gt;&lt;span&gt;成功后,&lt;/span&gt;&lt;span&gt;扣除相应的手续费.&lt;/span&gt;&lt;/span&gt;', '&lt;span&gt;&lt;span&gt;你委托买入或者卖出成功交易后的记录.&lt;/span&gt;&lt;/span&gt;', '5', '24', '1', '100000', '100', '100000', '100', '1', '5', '3', '2', '1467617244', '0', 'index3', '澳维科技', '客户电话：4000-000-000 邮箱：www.auvcoin.com  工作日:9-19时 节假日:9-18时');

-- -----------------------------
-- Table structure for `movesay_fenhong`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_fenhong`;
CREATE TABLE `movesay_fenhong` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `coinjian` varchar(50) NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_fenhong_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_fenhong_log`;
CREATE TABLE `movesay_fenhong_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `coinjian` varchar(50) NOT NULL,
  `fenzong` varchar(50) NOT NULL,
  `fenchi` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_finance`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_finance`;
CREATE TABLE `movesay_finance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `userid` int(11) unsigned NOT NULL COMMENT '用户id',
  `coinname` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '币种',
  `num_a` decimal(20,8) unsigned NOT NULL COMMENT '之前正常',
  `num_b` decimal(20,8) unsigned NOT NULL COMMENT '之前冻结',
  `num` decimal(20,8) unsigned NOT NULL COMMENT '之前总计',
  `fee` decimal(20,8) unsigned NOT NULL COMMENT '操作数量',
  `type` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '操作类型',
  `name` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '操作名称',
  `nameid` int(11) NOT NULL COMMENT '操作详细',
  `remark` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '操作备注',
  `mum_a` decimal(20,8) unsigned NOT NULL COMMENT '剩余正常',
  `mum_b` decimal(20,8) unsigned NOT NULL COMMENT '剩余冻结',
  `mum` decimal(20,8) unsigned NOT NULL COMMENT '剩余总计',
  `move` varchar(50) CHARACTER SET utf8 NOT NULL COMMENT '附加',
  `addtime` int(11) unsigned NOT NULL COMMENT '添加时间',
  `status` tinyint(4) unsigned NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `coinname` (`coinname`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -----------------------------
-- Records of `movesay_finance`
-- -----------------------------
INSERT INTO `movesay_finance` VALUES ('1', '2', 'cny', '7562898.80000000', '2437100.20000000', '9999999.00000000', '10.00000000', '1', 'mycz', '16', '人民币充值-人工到账', '7562908.80000000', '2437100.20000000', '10000009.00000000', '8771417567c217ba74d128104a836a71', '1467353433', '0');
INSERT INTO `movesay_finance` VALUES ('2', '2', 'cny', '7562908.80000000', '2437100.20000000', '10000009.00000000', '10.00000000', '1', 'mycz', '15', '人民币充值-人工到账', '7562918.80000000', '2437100.20000000', '10000019.00000000', '8f09dc3fb47c34decbd297fcc144fdc7', '1467357883', '1');
INSERT INTO `movesay_finance` VALUES ('3', '2', 'cny', '7562918.80000000', '2437100.20000000', '10000019.00000000', '49999.00000000', '1', 'mycz', '18', '人民币充值-人工到账', '7612917.80000000', '2437100.20000000', '10050018.00000000', '73a87ed3cfae54c17432b0db24dab849', '1467360090', '1');
INSERT INTO `movesay_finance` VALUES ('4', '2', 'cny', '7612917.80000000', '2437100.20000000', '10050018.00000000', '49999.00000000', '1', 'mycz', '17', '人民币充值-人工到账', '7662916.80000000', '2437100.20000000', '10100017.00000000', '53edc45aa13e9dcafe3af816ff72200f', '1467360095', '1');
INSERT INTO `movesay_finance` VALUES ('5', '2', 'cny', '7662916.80000000', '2437100.20000000', '10100017.00000000', '1000.00000000', '1', 'mycz', '5', '人民币充值-人工到账', '7663916.80000000', '2437100.20000000', '10101017.00000000', '8b1d6d9202b76b144cc01206f8f90ca8', '1467360110', '1');
INSERT INTO `movesay_finance` VALUES ('6', '2', 'cny', '7663916.80000000', '2437100.20000000', '10101017.00000000', '8000.00000000', '2', 'mytx', '1', '人民币提现-申请提现', '7655916.80000000', '2437100.20000000', '10093017.00000000', 'db6ff11f28fc84b883678ddbee96b4b1', '1467360198', '1');
INSERT INTO `movesay_finance` VALUES ('7', '3', 'cny', '10000000.00000000', '0.00000000', '10000000.00000000', '100.00000000', '1', 'mycz', '19', '人民币充值-人工到账', '10000100.00000000', '0.00000000', '10000100.00000000', '3007d59119b6ac51859da9d50eb9c529', '1467614778', '0');

-- -----------------------------
-- Table structure for `movesay_footer`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_footer`;
CREATE TABLE `movesay_footer` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_footer`
-- -----------------------------
INSERT INTO `movesay_footer` VALUES ('1', '1', '关于我们', '/Article/index/type/aboutus.html', '', '1', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('2', '1', '联系我们', '/Article/index/type/aboutus.html', '', '1', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('3', '1', '资质证明', '/Article/index/type/aboutus.html', '', '1', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('4', '1', '用户协议', '/Article/index/type/aboutus.html', '', '1', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('5', '1', '法律声明', '/Article/index/type/aboutus.html', '', '1', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('6', '1', '1', '/', 'footer_1.png', '2', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('7', '1', '1', 'http://www.szfw.org/', 'footer_2.png', '2', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('8', '1', '1', 'http://www.miibeian.gov.cn/', 'footer_3.png', '2', '', '1', '111', '0', '1');
INSERT INTO `movesay_footer` VALUES ('9', '1', '1', 'http://www.cyberpolice.cn/', 'footer_4.png', '2', '', '1', '111', '0', '1');

-- -----------------------------
-- Table structure for `movesay_invit`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_invit`;
CREATE TABLE `movesay_invit` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `invit` int(11) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `fee` decimal(20,8) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `invit` (`invit`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='推广奖励表';


-- -----------------------------
-- Table structure for `movesay_issue`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_issue`;
CREATE TABLE `movesay_issue` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `buycoin` varchar(50) NOT NULL,
  `num` bigint(20) unsigned NOT NULL,
  `deal` int(11) unsigned NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `limit` int(11) unsigned NOT NULL,
  `time` varchar(255) NOT NULL,
  `tian` varchar(255) NOT NULL,
  `ci` varchar(255) NOT NULL,
  `jian` varchar(255) NOT NULL,
  `min` varchar(255) NOT NULL,
  `max` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `invit_coin` varchar(50) NOT NULL,
  `invit_1` varchar(50) NOT NULL,
  `invit_2` varchar(50) NOT NULL,
  `invit_3` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`),
  KEY `coinname` (`coinname`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='认购发行表';

-- -----------------------------
-- Records of `movesay_issue`
-- -----------------------------
INSERT INTO `movesay_issue` VALUES ('1', '澳维币第一期认购', 'avc', 'cny', '5000000', '4254603', '0.01000000', '10000', '2016-06-30 00:00:00', '180', '5', '24', '', '', '这里是介绍', 'cny', '', '', '', '0', '1467614656', '0', '1');

-- -----------------------------
-- Table structure for `movesay_issue_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_issue_log`;
CREATE TABLE `movesay_issue_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `buycoin` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` int(20) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `ci` int(11) unsigned NOT NULL,
  `jian` varchar(255) NOT NULL,
  `unlock` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='认购记录表';

-- -----------------------------
-- Records of `movesay_issue_log`
-- -----------------------------
INSERT INTO `movesay_issue_log` VALUES ('1', '2', '优特币第一期认购', 'ytc', 'cny', '0.01000000', '100', '1.00000000', '5', '24', '1', '0', '1467292452', '1467292452', '0');

-- -----------------------------
-- Table structure for `movesay_link`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_link`;
CREATE TABLE `movesay_link` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL,
  `mytx` varchar(200) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='常用银行地址';

-- -----------------------------
-- Records of `movesay_link`
-- -----------------------------
INSERT INTO `movesay_link` VALUES ('4', 'boc', '中国银行', 'http://www.boc.cn/', 'img_56937003683ce.jpg', '', '', '0', '1452503043', '0', '1');
INSERT INTO `movesay_link` VALUES ('5', 'abc', '农业银行', 'http://www.abchina.com/cn/', 'img_569370458b18d.jpg', '', '', '0', '1452503109', '0', '1');
INSERT INTO `movesay_link` VALUES ('6', 'bccb', '北京银行', 'http://www.bankofbeijing.com.cn/', 'img_569370588dcdc.jpg', '', '', '0', '1452503128', '0', '1');
INSERT INTO `movesay_link` VALUES ('8', 'ccb', '建设银行', 'http://www.ccb.com/', 'img_5693709bbd20f.jpg', '', '', '0', '1452503195', '0', '1');
INSERT INTO `movesay_link` VALUES ('9', 'ceb', '光大银行', 'http://www.bankofbeijing.com.cn/', 'img_569370b207cc8.jpg', '', '', '0', '1452503218', '0', '1');
INSERT INTO `movesay_link` VALUES ('10', 'cib', '兴业银行', 'http://www.cib.com.cn/cn/index.html', 'img_569370d29bf59.jpg', '', '', '0', '1452503250', '0', '1');
INSERT INTO `movesay_link` VALUES ('11', 'citic', '中信银行', 'http://www.ecitic.com/', 'img_569370fb7a1b3.jpg', '', '', '0', '1452503291', '0', '1');
INSERT INTO `movesay_link` VALUES ('12', 'cmb', '招商银行', 'http://www.cmbchina.com/', 'img_5693710a9ac9c.jpg', '', '', '0', '1452503306', '0', '1');
INSERT INTO `movesay_link` VALUES ('13', 'cmbc', '民生银行', 'http://www.cmbchina.com/', 'img_5693711f97a9d.jpg', '', '', '0', '1452503327', '0', '1');
INSERT INTO `movesay_link` VALUES ('14', 'comm', '交通银行', 'http://www.bankcomm.com/BankCommSite/default.shtml', 'img_5693713076351.jpg', '', '', '0', '1452503344', '0', '1');
INSERT INTO `movesay_link` VALUES ('16', 'gdb', '广发银行', 'http://www.cgbchina.com.cn/', 'img_56937154bebc5.jpg', '', '', '0', '1452503380', '0', '1');
INSERT INTO `movesay_link` VALUES ('17', 'icbc', '工商银行', 'http://www.icbc.com.cn/icbc/', 'img_56937162db7f5.jpg', '', '', '0', '1452503394', '0', '1');
INSERT INTO `movesay_link` VALUES ('19', 'psbc', '邮政银行', 'http://www.psbc.com/portal/zh_CN/index.html', 'img_5693717eefaa3.jpg', '', '', '0', '1452503422', '0', '1');
INSERT INTO `movesay_link` VALUES ('20', 'spdb', '浦发银行', 'http://www.spdb.com.cn/chpage/c1/', 'img_5693718f1d70e.jpg', '', '', '0', '1452503439', '0', '1');
INSERT INTO `movesay_link` VALUES ('21', 'szpab', '平安银行', 'http://bank.pingan.com/', '56c2e4c9aff85.jpg', '', '', '0', '1455613129', '0', '1');

-- -----------------------------
-- Table structure for `movesay_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_log`;
CREATE TABLE `movesay_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` int(20) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `unlock` int(11) unsigned NOT NULL,
  `ci` int(11) unsigned NOT NULL,
  `recycle` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `coinname` (`coinname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_market`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_market`;
CREATE TABLE `movesay_market` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `round` varchar(255) NOT NULL,
  `fee_buy` varchar(255) NOT NULL,
  `fee_sell` varchar(255) NOT NULL,
  `buy_min` varchar(255) NOT NULL,
  `buy_max` varchar(255) NOT NULL,
  `sell_min` varchar(255) NOT NULL,
  `sell_max` varchar(255) NOT NULL,
  `trade_min` varchar(255) NOT NULL,
  `trade_max` varchar(255) NOT NULL,
  `invit_buy` varchar(50) NOT NULL,
  `invit_sell` varchar(50) NOT NULL,
  `invit_1` varchar(50) NOT NULL,
  `invit_2` varchar(50) NOT NULL,
  `invit_3` varchar(50) NOT NULL,
  `zhang` varchar(255) NOT NULL,
  `die` varchar(255) NOT NULL,
  `hou_price` varchar(255) NOT NULL,
  `tendency` varchar(1000) NOT NULL,
  `zoushi` text NOT NULL,
  `trade` int(11) unsigned NOT NULL,
  `new_price` decimal(20,8) unsigned NOT NULL,
  `buy_price` decimal(20,8) unsigned NOT NULL,
  `sell_price` decimal(20,8) unsigned NOT NULL,
  `min_price` decimal(20,8) unsigned NOT NULL,
  `max_price` decimal(20,8) unsigned NOT NULL,
  `volume` decimal(20,8) unsigned NOT NULL,
  `change` decimal(20,8) NOT NULL,
  `api_min` decimal(20,8) unsigned NOT NULL,
  `api_max` decimal(20,8) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='行情配置表';

-- -----------------------------
-- Records of `movesay_market`
-- -----------------------------
INSERT INTO `movesay_market` VALUES ('3', 'btc_cny', '2', '0', '0', '', '', '', '', '', '', '0', '0', '', '', '', '', '', '4399.00000000', '[[1467358021,\"4400.00000000\"],[1467372421,0],[1467386821,0],[1467401221,0],[1467415621,0],[1467430021,0],[1467444421,0],[1467458821,0],[1467473221,0],[1467487621,0],[1467502021,0],[1467516421,0],[1467530821,0],[1467545221,0],[1467559621,0],[1467574021,0],[1467588421,0],[1467602821,\"4599.00000000\"],[1467617221,0]]', '', '1', '4599.00000000', '4568.00000000', '4599.00000000', '4400.00000000', '4599.00000000', '22.10000000', '4.54650000', '0.00000000', '0.00000000', '0', '0', '0', '1');
INSERT INTO `movesay_market` VALUES ('4', 'ltc_cny', '2', '', '', '', '', '', '', '', '', '0', '0', '', '', '', '', '', '30.00000000', '[[1467358021,0],[1467372421,0],[1467386821,0],[1467401221,0],[1467415621,0],[1467430021,0],[1467444421,0],[1467458821,0],[1467473221,0],[1467487621,0],[1467502021,0],[1467516421,0],[1467530821,0],[1467545221,0],[1467559621,0],[1467574021,0],[1467588421,0],[1467602821,\"30.00000000\"],[1467617221,0]]', '', '1', '30.00000000', '27.00000000', '30.00000000', '30.00000000', '30.00000000', '45.00000000', '0.00000000', '0.00000000', '0.00000000', '0', '0', '0', '1');
INSERT INTO `movesay_market` VALUES ('7', 'avc_cny', '', '', '', '', '', '', '', '', '', '1', '1', '', '', '', '', '', '', '[[1467358021,0],[1467372421,0],[1467386821,0],[1467401221,0],[1467415621,0],[1467430021,0],[1467444421,0],[1467458821,0],[1467473221,0],[1467487621,0],[1467502021,0],[1467516421,0],[1467530821,0],[1467545221,0],[1467559621,0],[1467574021,0],[1467588421,0],[1467602821,0],[1467617221,0]]', '', '1', '0.00000000', '0.00000000', '0.00000000', '0.00000000', '0.00000000', '0.00000000', '0.00000000', '0.00000000', '0.00000000', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `movesay_market_json`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_market_json`;
CREATE TABLE `movesay_market_json` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `data` varchar(500) CHARACTER SET utf8 NOT NULL,
  `type` varchar(100) CHARACTER SET utf8 NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -----------------------------
-- Records of `movesay_market_json`
-- -----------------------------
INSERT INTO `movesay_market_json` VALUES ('1', 'btc_cny', '[\"1921.50000000\",\"45478.00000000\",\"0.00000000\",\"0.00000000\"]', '', '0', '1467302399', '0', '0');
INSERT INTO `movesay_market_json` VALUES ('2', 'btc_cny', '[\"4.00000000\",\"17598.00000000\",\"0.00000000\",\"0.00000000\"]', '', '0', '1467388799', '0', '0');

-- -----------------------------
-- Table structure for `movesay_menu`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_menu`;
CREATE TABLE `movesay_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `ico_name` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=183 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_menu`
-- -----------------------------
INSERT INTO `movesay_menu` VALUES ('1', '系统', '0', '1', 'Index/index', '0', '', '', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('2', '内容', '0', '1', 'Article/index', '0', '', '', '0', 'list-alt');
INSERT INTO `movesay_menu` VALUES ('3', '用户', '0', '1', 'User/index', '0', '', '', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('4', '财务', '0', '1', 'Finance/index', '0', '', '', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('5', '交易', '0', '1', 'Trade/index', '0', '', '', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('6', '应用', '0', '1', 'Game/index', '0', '', '', '0', 'globe');
INSERT INTO `movesay_menu` VALUES ('7', '设置', '0', '1', 'Config/index', '0', '', '', '0', 'cog');
INSERT INTO `movesay_menu` VALUES ('8', '运营', '0', '1', 'Invit/index', '0', '', '', '0', 'share');
INSERT INTO `movesay_menu` VALUES ('9', '工具', '0', '1', 'Tools/index', '0', '', '', '0', 'wrench');
INSERT INTO `movesay_menu` VALUES ('10', '扩展', '0', '1', 'Cloud/index', '0', '', '', '0', 'tasks');
INSERT INTO `movesay_menu` VALUES ('11', '系统概览', '1', '1', 'Index/index', '0', '', '系统', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('13', '文章管理', '2', '1', 'Article/index', '0', '', '内容', '0', 'list-alt');
INSERT INTO `movesay_menu` VALUES ('14', '编辑', '13', '1', 'Article/edit', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('15', '修改', '13', '1', 'Article/status', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('16', '上传图片', '13', '2', 'Article/images', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('156', '提现地址', '3', '6', 'User/bank', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('18', '编辑', '17', '2', 'Adver/edit', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('19', '修改', '17', '2', 'Adver/status', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('153', '管理员管理', '3', '2', 'User/adminUser', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('21', '编辑', '20', '3', 'Chat/edit', '1', '', '聊天管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('22', '修改', '20', '3', 'Chat/status', '1', '', '聊天管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('23', '提示文字', '2', '1', 'Text/index', '1', '', '提示管理', '0', 'exclamation-sign');
INSERT INTO `movesay_menu` VALUES ('24', '编辑', '23', '1', 'Text/edit', '1', '', '提示管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('25', '修改', '23', '1', 'Text/status', '1', '', '提示管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('26', '用户管理', '3', '1', 'User/index', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('163', '虚拟币转入', '4', '6', 'Finance/myzr', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('162', '人民币提现配置', '4', '5', 'Finance/mytxConfig', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('161', '人民币提现', '4', '4', 'Finance/mytx', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('165', '成交记录', '5', '2', 'Trade/log', '0', '', '交易', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('166', '交易聊天', '5', '3', 'Trade/chat', '0', '', '交易', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('32', '确认转出', '26', '8', 'User/myzc_qr', '1', '', '用户管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('33', '用户配置', '3', '1', 'User/config', '1', '', '前台用户管理', '0', 'cog');
INSERT INTO `movesay_menu` VALUES ('34', '编辑', '33', '2', 'User/index_edit', '1', '', '用户管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('35', '修改', '33', '2', 'User/index_status', '1', '', '用户管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('37', '财产修改', '26', '3', 'Usercoin/edit', '1', '', '用户管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('38', '权限列表', '3', '3', 'AuthManager/index', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('39', '新增用户组', '38', '0', 'AuthManager/createGroup', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('40', '编辑用户组', '38', '0', 'AuthManager/editgroup', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('41', '更新用户组', '38', '0', 'AuthManager/writeGroup', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('42', '改变状态', '38', '0', 'AuthManager/changeStatus', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('43', '访问授权', '38', '0', 'AuthManager/access', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('44', '分类授权', '38', '0', 'AuthManager/category', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('45', '成员授权', '38', '0', 'AuthManager/user', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('46', '成员列表授权', '38', '0', 'AuthManager/tree', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('47', '用户组', '38', '0', 'AuthManager/group', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('48', '添加到用户组', '38', '0', 'AuthManager/addToGroup', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('49', '用户组移除', '38', '0', 'AuthManager/removeFromGroup', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('50', '分类添加到用户组', '38', '0', 'AuthManager/addToCategory', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('51', '模型添加到用户组', '38', '0', 'AuthManager/addToModel', '1', '', '权限管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('52', '财务明细', '4', '1', 'Finance/index', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('53', '配置', '52', '1', 'Finance/config', '1', '', '', '0', '0');
INSERT INTO `movesay_menu` VALUES ('159', '人民币充值', '4', '2', 'Finance/mycz', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('55', '类型', '52', '1', 'Finance/type', '1', '', '', '0', '0');
INSERT INTO `movesay_menu` VALUES ('56', '状态修改', '52', '1', 'Finance/type_status', '1', '', '', '0', '0');
INSERT INTO `movesay_menu` VALUES ('169', '交易推荐', '5', '6', 'Trade/invit', '0', '', '交易', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('172', '修改状态', '159', '100', 'Finance/myczStatus', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('168', '交易市场', '5', '5', 'Trade/market', '0', '', '交易', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('60', '修改', '57', '3', 'Mycz/status', '1', '', '充值管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('61', '状态修改', '57', '3', 'Mycztype/status', '1', '', '充值管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('167', '币种评论', '5', '4', 'Trade/comment', '0', '', '交易', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('64', '状态修改', '62', '5', 'Mytx/status', '1', '', '提现管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('65', '取消', '62', '5', 'Mytx/excel', '1', '', '提现管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('66', '导入excel', '9', '5', 'Mytx/exportExcel', '1', '', '提现管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('68', '委托管理', '5', '1', 'Trade/index', '0', '', '交易', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('69', '交易记录', '5', '2', 'Tradelog/index', '0', '', '交易管理', '0', 'time');
INSERT INTO `movesay_menu` VALUES ('70', '修改状态', '68', '0', 'Trade/status', '1', '', '交易管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('71', '撤销挂单', '68', '0', 'Trade/chexiao', '1', '', '交易管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('72', '认购管理', '6', '1', 'Issue/index', '0', '', '认购管理', '0', 'tasks');
INSERT INTO `movesay_menu` VALUES ('74', '认购编辑', '72', '2', 'Issue/edit', '1', '', '认购管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('75', '认购修改', '72', '2', 'Issue/status', '1', '', '认购管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('76', '认购记录', '6', '3', 'Issuelog/index', '0', '', '认购管理', '0', 'time');
INSERT INTO `movesay_menu` VALUES ('79', '基本配置', '7', '1', 'Config/index', '0', '', '网站配置', '0', 'cog');
INSERT INTO `movesay_menu` VALUES ('80', '短信配置', '7', '2', 'Config/moble', '0', '', '网站配置', '0', 'comment');
INSERT INTO `movesay_menu` VALUES ('81', '客服配置', '7', '3', 'Config/contact', '0', '', '网站配置', '0', 'headphones');
INSERT INTO `movesay_menu` VALUES ('82', '银行配置', '79', '4', 'Config/bank', '0', '', '网站配置', '0', 'credit-card');
INSERT INTO `movesay_menu` VALUES ('83', '编辑', '82', '4', 'Config/bank_edit', '1', '', '网站配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('84', '币种配置', '7', '5', 'Coin/index', '0', '', '网站配置', '0', 'signal');
INSERT INTO `movesay_menu` VALUES ('85', '编辑', '84', '4', 'Coin/edit', '0', '', '网站配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('87', '状态修改', '84', '4', 'Coin/status', '1', '', '网站配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('88', '市场配置', '7', '6', 'Market/index', '0', '', '网站配置', '0', 'signal');
INSERT INTO `movesay_menu` VALUES ('89', '编辑市场', '88', '4', 'Market/edit', '0', '', '', '0', '0');
INSERT INTO `movesay_menu` VALUES ('154', '登陆日志', '3', '4', 'User/log', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('91', '状态修改', '88', '4', 'Config/market_add', '1', '', '', '0', '0');
INSERT INTO `movesay_menu` VALUES ('92', '图形验证码', '95', '7', 'Verify/code', '1', '', '网站配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('93', '手机验证码', '95', '7', 'Verify/mobile', '1', '', '网站配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('94', '邮件验证码', '95', '7', 'Verify/email', '1', '', '网站配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('95', '其他配置', '7', '7', 'Config/qita', '0', '', '网站配置', '0', 'retweet');
INSERT INTO `movesay_menu` VALUES ('96', '推广奖励', '8', '1', 'Invit/index', '0', '', '推广管理', '0', 'share');
INSERT INTO `movesay_menu` VALUES ('97', '推广配置', '8', '2', 'Invit/config', '1', '', '推广管理', '0', 'cog');
INSERT INTO `movesay_menu` VALUES ('98', '数据备份', '9', '3', 'Tools/database?type=export', '0', '', '首页', '0', 'floppy-saved');
INSERT INTO `movesay_menu` VALUES ('99', '数据还原', '9', '4', 'Tools/database?type=import', '0', '', '首页', '0', 'open');
INSERT INTO `movesay_menu` VALUES ('100', '清理缓存', '9', '4', 'Tools/delcahe', '0', '', '其他', '0', 'trash');
INSERT INTO `movesay_menu` VALUES ('101', '其他模块调用', '9', '4', 'Tools/invoke', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('102', '优化表', '9', '4', 'Tools/optimize', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('103', '修复表', '9', '4', 'Tools/repair', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('104', '删除备份文件', '9', '4', 'Tools/del', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('105', '备份数据库', '9', '4', 'Tools/export', '1', '', '其他', '0', '');
INSERT INTO `movesay_menu` VALUES ('106', '还原数据库', '9', '4', 'Tools/import', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('107', '导出数据库', '9', '4', 'Tools/excel', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('108', '导出Excel', '9', '4', 'Tools/exportExcel', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('109', '导入Excel', '9', '4', 'Tools/importExecl', '1', '', '其他', '0', '0');
INSERT INTO `movesay_menu` VALUES ('110', '扩展管理', '10', '0', 'ExtA/index', '0', '', '扩展管理', '0', 'th');
INSERT INTO `movesay_menu` VALUES ('173', '确认到账', '159', '100', 'Finance/myczQueren', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('174', '编辑添加', '160', '1', 'Finance/myczTypeEdit', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('115', '图片', '111', '0', 'Shop/images', '0', '', '云购商城', '0', '0');
INSERT INTO `movesay_menu` VALUES ('116', '菜单管理', '7', '5', 'Menu/index', '1', '', '开发组', '0', 'list');
INSERT INTO `movesay_menu` VALUES ('117', '排序', '116', '5', 'Menu/sort', '0', '', '开发组', '0', '0');
INSERT INTO `movesay_menu` VALUES ('118', '添加', '116', '5', 'Menu/add', '0', '', '开发组', '0', '0');
INSERT INTO `movesay_menu` VALUES ('119', '编辑', '116', '5', 'Menu/edit', '0', '', '开发组', '0', '0');
INSERT INTO `movesay_menu` VALUES ('120', '删除', '116', '5', 'Menu/del', '0', '', '开发组', '0', '0');
INSERT INTO `movesay_menu` VALUES ('121', '是否隐藏', '116', '5', 'Menu/toogleHide', '0', '', '开发组', '0', '0');
INSERT INTO `movesay_menu` VALUES ('122', '是否开发', '116', '5', 'Menu/toogleDev', '0', '', '开发组', '0', '0');
INSERT INTO `movesay_menu` VALUES ('123', '导入文件', '7', '5', 'Menu/importFile', '1', '', '开发组', '0', 'log-in');
INSERT INTO `movesay_menu` VALUES ('124', '导入', '7', '5', 'Menu/import', '1', '', '开发组', '0', 'log-in');
INSERT INTO `movesay_menu` VALUES ('164', '虚拟币转出', '4', '7', 'Finance/myzc', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('127', '用户登录', '3', '0', 'Login/index', '1', '', '用户配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('128', '用户退出', '3', '0', 'Login/loginout', '1', '', '用户配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('129', '设置密码', '3', '0', 'User/setpwd', '1', '', '用户配置', '0', '0');
INSERT INTO `movesay_menu` VALUES ('147', '自动升级', '10', '1', 'Cloud/update', '0', '', '扩展', '0', 'wrench');
INSERT INTO `movesay_menu` VALUES ('131', '用户详情', '3', '4', 'User/detail', '1', '', '前台用户管理', '0', 'time');
INSERT INTO `movesay_menu` VALUES ('132', '后台用户详情', '3', '1', 'AdminUser/detail', '1', '', '后台用户管理', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('133', '后台用户状态', '3', '1', 'AdminUser/status', '1', '', '后台用户管理', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('134', '后台用户新增', '3', '1', 'AdminUser/add', '1', '', '后台用户管理', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('135', '后台用户编辑', '3', '1', 'AdminUser/edit', '1', '', '后台用户管理', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('12', '市场统计', '1', '1', 'Index/operate', '1', '', '首页', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('138', '编辑', '2', '1', 'Articletype/edit', '1', '', '内容管理', '0', 'list-alt');
INSERT INTO `movesay_menu` VALUES ('155', '用户钱包', '3', '5', 'User/qianbao', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('140', '编辑', '139', '2', 'Link/edit', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('141', '修改', '139', '2', 'Link/status', '1', '', '内容管理', '0', '0');
INSERT INTO `movesay_menu` VALUES ('160', '人民币充值方式', '4', '3', 'Finance/myczType', '0', '', '财务', '0', 'th-list');
INSERT INTO `movesay_menu` VALUES ('145', '币种统计', '1', '2', 'Index/coin', '0', '', '系统', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('146', '市场统计', '1', '3', 'Index/market', '0', '', '系统', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('148', '应用管理', '10', '2', 'Cloud/game', '0', '', '扩展', '0', 'retweet');
INSERT INTO `movesay_menu` VALUES ('149', '提示文字', '7', '5', 'Config/text', '0', '', '网站配置', '0', 'stats');
INSERT INTO `movesay_menu` VALUES ('150', '文章类型', '2', '2', 'Article/type', '0', '', '内容', '0', 'list-alt');
INSERT INTO `movesay_menu` VALUES ('151', '广告管理', '2', '3', 'Article/adver', '0', '', '内容', '0', 'list-alt');
INSERT INTO `movesay_menu` VALUES ('152', '友情链接', '2', '4', 'Article/link', '0', '', '内容', '0', 'list-alt');
INSERT INTO `movesay_menu` VALUES ('157', '用户财产', '3', '7', 'User/coin', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('158', '联系地址', '3', '8', 'User/goods', '0', '', '用户', '0', 'user');
INSERT INTO `movesay_menu` VALUES ('170', '队列状态', '9', '5', 'Tools/queue', '0', '', '其他', '0', 'time');
INSERT INTO `movesay_menu` VALUES ('171', '钱包检查', '9', '5', 'Tools/qianbao', '0', '', '其他', '0', 'time');
INSERT INTO `movesay_menu` VALUES ('175', '状态修改', '160', '2', 'Finance/myczTypeStatus', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('176', '上传图片', '160', '2', 'Finance/myczTypeImage', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('177', '修改状态', '161', '2', 'Finance/mytxStatus', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('178', '导出选中', '161', '3', 'Finance/mytxExcel', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('179', '正在处理', '161', '4', 'Finance/mytxChuli', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('180', '撤销提现', '161', '5', 'Finance/mytxChexiao', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('181', '确认提现', '161', '6', 'Finance/mytxQueren', '1', '', '财务', '0', 'home');
INSERT INTO `movesay_menu` VALUES ('182', '确认转出', '164', '6', 'Finance/myzcQueren', '1', '', '财务', '0', 'home');

-- -----------------------------
-- Table structure for `movesay_message`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_message`;
CREATE TABLE `movesay_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `addip` varchar(200) NOT NULL,
  `addr` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_message_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_message_log`;
CREATE TABLE `movesay_message_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `addip` varchar(200) NOT NULL,
  `addr` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_money`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_money`;
CREATE TABLE `movesay_money` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `num` bigint(20) unsigned NOT NULL DEFAULT '0',
  `deal` int(11) unsigned NOT NULL DEFAULT '0',
  `tian` int(11) unsigned NOT NULL,
  `fee` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='投资理财表';


-- -----------------------------
-- Table structure for `movesay_money_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_money_log`;
CREATE TABLE `movesay_money_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `num` int(11) unsigned NOT NULL,
  `fee` decimal(20,8) unsigned NOT NULL,
  `feea` decimal(20,8) unsigned NOT NULL,
  `tian` int(11) unsigned NOT NULL,
  `tiana` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='理财记录表';


-- -----------------------------
-- Table structure for `movesay_mycz`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_mycz`;
CREATE TABLE `movesay_mycz` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `num` int(11) unsigned NOT NULL,
  `mum` int(11) unsigned NOT NULL,
  `type` varchar(50) NOT NULL,
  `tradeno` varchar(50) NOT NULL,
  `remark` varchar(250) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='充值记录表';

-- -----------------------------
-- Records of `movesay_mycz`
-- -----------------------------
INSERT INTO `movesay_mycz` VALUES ('3', '2', '1000', '0', 'alipay', 'BV933982', '', '0', '1467292321', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('4', '2', '1000', '0', 'bank', 'DJ492272', '', '0', '1467292341', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('5', '2', '1000', '1000', 'weixin', 'QC521779', '', '0', '1467292349', '1467360110', '2');
INSERT INTO `movesay_mycz` VALUES ('6', '2', '10', '0', 'alipay', 'DQ163469', '', '0', '1467348020', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('7', '2', '10', '0', 'alipay', 'KY922424', '', '0', '1467348259', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('8', '2', '10', '0', 'alipay', 'KH657215', '', '0', '1467348259', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('9', '2', '10', '0', 'alipay', 'JA234722', '', '0', '1467348273', '0', '0');
INSERT INTO `movesay_mycz` VALUES ('10', '2', '111', '0', 'bank', 'VH451642', '', '0', '1467349910', '0', '3');
INSERT INTO `movesay_mycz` VALUES ('11', '2', '10', '0', 'weixin', 'AG227497', '', '0', '1467350734', '0', '3');
INSERT INTO `movesay_mycz` VALUES ('12', '2', '100', '0', 'bank', 'NG743391', '', '0', '1467350746', '0', '3');
INSERT INTO `movesay_mycz` VALUES ('13', '2', '100', '0', 'weixin', 'LB943743', '', '0', '1467350809', '0', '3');
INSERT INTO `movesay_mycz` VALUES ('14', '2', '10', '0', 'weixin', 'SJ954671', '', '0', '1467350814', '0', '3');
INSERT INTO `movesay_mycz` VALUES ('15', '2', '10', '10', 'weixin', 'JI742952', '', '0', '1467351096', '1467357883', '2');
INSERT INTO `movesay_mycz` VALUES ('16', '2', '10', '10', 'alipay', 'PW298533', '', '0', '1467351290', '1467353433', '2');
INSERT INTO `movesay_mycz` VALUES ('17', '2', '49999', '49999', 'bank', 'XM647119', '', '0', '1467360034', '1467360095', '2');
INSERT INTO `movesay_mycz` VALUES ('18', '2', '49999', '49999', 'bank', 'KD842963', '', '0', '1467360048', '1467360090', '2');
INSERT INTO `movesay_mycz` VALUES ('19', '3', '100', '100', 'bank', 'IV555336', '', '0', '1467595081', '1467614778', '2');

-- -----------------------------
-- Table structure for `movesay_mycz_type`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_mycz_type`;
CREATE TABLE `movesay_mycz_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `max` varchar(200) NOT NULL COMMENT '名称',
  `min` varchar(200) NOT NULL COMMENT '名称',
  `img` varchar(200) NOT NULL COMMENT '名称',
  `kaihu` varchar(200) NOT NULL COMMENT '名称',
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(355) DEFAULT NULL,
  `truename` varchar(200) NOT NULL COMMENT '名称',
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='充值类型';

-- -----------------------------
-- Records of `movesay_mycz_type`
-- -----------------------------
INSERT INTO `movesay_mycz_type` VALUES ('1', '20000', '10', '5775e2c222348.png', '11', '8888888', '8888', '朱盾', 'alipay', '支付宝支付', '需要在联系方式里面设置支付宝账号', '0', '0', '0', '1');
INSERT INTO `movesay_mycz_type` VALUES ('4', '20000', '10', '5775fc73495ff.png', '', '', '', '优特科技', 'weixin', '微信支付', '需要在联系方式里面设置微信账号', '0', '0', '0', '1');
INSERT INTO `movesay_mycz_type` VALUES ('7', '50000', '100', '', '中国银行深圳市科技园支行', '888888888888', '222888888', '优特科技', 'bank', '网银支付', '需要在联系方式里面按照格式天数收款银行账号', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `movesay_mytx`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_mytx`;
CREATE TABLE `movesay_mytx` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `num` int(11) unsigned NOT NULL,
  `fee` decimal(20,2) unsigned NOT NULL,
  `mum` decimal(20,2) unsigned NOT NULL,
  `truename` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `bank` varchar(250) NOT NULL,
  `bankprov` varchar(50) NOT NULL,
  `bankcity` varchar(50) NOT NULL,
  `bankaddr` varchar(50) NOT NULL,
  `bankcard` varchar(200) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='提现记录表';

-- -----------------------------
-- Records of `movesay_mytx`
-- -----------------------------
INSERT INTO `movesay_mytx` VALUES ('1', '2', '8000', '80.00', '7920.00', '牛牛', '广东', '平安银行', '广东', '深圳', '科技园支行', '8888888888888888', '0', '1467360198', '0', '1');

-- -----------------------------
-- Table structure for `movesay_myzc`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_myzc`;
CREATE TABLE `movesay_myzc` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `username` varchar(200) NOT NULL,
  `coinname` varchar(200) NOT NULL,
  `txid` varchar(200) NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `fee` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`),
  KEY `coinname` (`coinname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_myzr`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_myzr`;
CREATE TABLE `movesay_myzr` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `username` varchar(200) NOT NULL,
  `coinname` varchar(200) NOT NULL,
  `txid` varchar(200) NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `fee` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `coinname` (`coinname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_pool`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_pool`;
CREATE TABLE `movesay_pool` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `ico` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `tian` int(11) unsigned NOT NULL,
  `limit` varchar(50) NOT NULL,
  `power` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='矿机类型表';


-- -----------------------------
-- Table structure for `movesay_pool_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_pool_log`;
CREATE TABLE `movesay_pool_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `coinname` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `ico` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `tian` int(11) unsigned NOT NULL,
  `limit` varchar(50) NOT NULL,
  `power` varchar(50) NOT NULL,
  `num` int(11) unsigned NOT NULL,
  `use` int(11) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='矿机管理';


-- -----------------------------
-- Table structure for `movesay_prompt`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_prompt`;
CREATE TABLE `movesay_prompt` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL,
  `mytx` varchar(200) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_shop`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_shop`;
CREATE TABLE `movesay_shop` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `coinlist` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `price_1` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `num` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `deal` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `content` text NOT NULL,
  `max` varchar(255) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `status` (`status`),
  KEY `deal` (`deal`),
  KEY `price` (`price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商城商品表';


-- -----------------------------
-- Table structure for `movesay_shop_addr`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_shop_addr`;
CREATE TABLE `movesay_shop_addr` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL DEFAULT '0',
  `truename` varchar(50) NOT NULL DEFAULT '0',
  `moble` varchar(500) NOT NULL,
  `name` varchar(500) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_shop_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_shop_log`;
CREATE TABLE `movesay_shop_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) NOT NULL,
  `shopid` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `coinname` varchar(50) NOT NULL DEFAULT '0.00',
  `num` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `mum` decimal(20,8) unsigned NOT NULL DEFAULT '0.00000000',
  `addr` varchar(50) NOT NULL DEFAULT '0.0000',
  `sort` int(11) unsigned NOT NULL,
  `fee` decimal(20,8) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='购物记录表';


-- -----------------------------
-- Table structure for `movesay_shop_type`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_shop_type`;
CREATE TABLE `movesay_shop_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品分类';


-- -----------------------------
-- Table structure for `movesay_text`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_text`;
CREATE TABLE `movesay_text` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_text`
-- -----------------------------
INSERT INTO `movesay_text` VALUES ('1', 'user_moble', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467279597', '0', '1');
INSERT INTO `movesay_text` VALUES ('2', 'user_alipay', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467279632', '0', '1');
INSERT INTO `movesay_text` VALUES ('3', 'game_issue', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467279637', '0', '1');
INSERT INTO `movesay_text` VALUES ('4', 'finance_index', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467285974', '0', '1');
INSERT INTO `movesay_text` VALUES ('5', 'game_issue_log', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467285987', '0', '1');
INSERT INTO `movesay_text` VALUES ('6', 'user_index', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286032', '0', '1');
INSERT INTO `movesay_text` VALUES ('7', 'finance_mycz', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286037', '0', '1');
INSERT INTO `movesay_text` VALUES ('8', 'finance_myzr', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286094', '0', '1');
INSERT INTO `movesay_text` VALUES ('9', 'finance_myjp', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286101', '0', '1');
INSERT INTO `movesay_text` VALUES ('10', 'finance_mywt', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286626', '0', '1');
INSERT INTO `movesay_text` VALUES ('11', 'finance_mycj', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286630', '0', '1');
INSERT INTO `movesay_text` VALUES ('12', 'finance_mytj', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286632', '0', '1');
INSERT INTO `movesay_text` VALUES ('13', 'finance_mywd', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286636', '0', '1');
INSERT INTO `movesay_text` VALUES ('14', 'finance_mytx', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467286642', '0', '1');
INSERT INTO `movesay_text` VALUES ('15', 'finance_myzc', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467291702', '0', '1');
INSERT INTO `movesay_text` VALUES ('16', 'user_ga', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292038', '0', '1');
INSERT INTO `movesay_text` VALUES ('17', 'user_nameauth', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292042', '0', '1');
INSERT INTO `movesay_text` VALUES ('18', 'user_bank', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292073', '0', '1');
INSERT INTO `movesay_text` VALUES ('19', 'user_tpwdset', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292136', '0', '1');
INSERT INTO `movesay_text` VALUES ('20', 'user_qianbao', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292148', '0', '1');
INSERT INTO `movesay_text` VALUES ('21', 'user_goods', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292242', '0', '1');
INSERT INTO `movesay_text` VALUES ('22', 'game_issue_buy', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467292443', '0', '1');
INSERT INTO `movesay_text` VALUES ('23', 'user_password', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467354725', '0', '1');
INSERT INTO `movesay_text` VALUES ('24', 'user_paypassword', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467354727', '0', '1');
INSERT INTO `movesay_text` VALUES ('25', 'user_log', '', '<span style=\"color:#0096E0;line-height:21px;background-color:#FFFFFF;\"><span>请在后台修改此处内容</span></span><span style=\"color:#0096E0;line-height:21px;font-family:\'Microsoft Yahei\', \'Sim sun\', tahoma, \'Helvetica,Neue\', Helvetica, STHeiTi, Arial, sans-serif;background-color:#FFFFFF;\">,<span style=\"color:#EE33EE;\">详细信息</span></span>', '0', '1467354847', '0', '1');

-- -----------------------------
-- Table structure for `movesay_trade`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_trade`;
CREATE TABLE `movesay_trade` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `market` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `deal` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `fee` decimal(20,8) unsigned NOT NULL,
  `type` tinyint(2) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `market_type_status` (`market`,`type`,`status`),
  KEY `num_deal` (`num`,`deal`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 COMMENT='交易下单表';

-- -----------------------------
-- Records of `movesay_trade`
-- -----------------------------
INSERT INTO `movesay_trade` VALUES ('1', '2', 'btc_cny', '100.00000000', '24.40000000', '0.00000000', '2440.00000000', '0.00000000', '1', '0', '1467290821', '0', '0');
INSERT INTO `movesay_trade` VALUES ('2', '2', 'btc_cny', '5000.00000000', '42.00000000', '0.00000000', '210000.00000000', '0.00000000', '2', '0', '1467290838', '0', '0');
INSERT INTO `movesay_trade` VALUES ('3', '2', 'btc_cny', '4568.00000000', '12.00000000', '12.00000000', '54816.00000000', '0.00000000', '2', '0', '1467290857', '0', '1');
INSERT INTO `movesay_trade` VALUES ('4', '2', 'btc_cny', '3500.00000000', '124.00000000', '0.00000000', '434000.00000000', '0.00000000', '1', '0', '1467290879', '0', '0');
INSERT INTO `movesay_trade` VALUES ('5', '2', 'btc_cny', '4012.00000000', '12.20000000', '0.00000000', '48946.40000000', '0.00000000', '1', '0', '1467290901', '0', '0');
INSERT INTO `movesay_trade` VALUES ('6', '2', 'btc_cny', '8452.00000000', '54.00000000', '0.00000000', '456408.00000000', '0.00000000', '2', '0', '1467290918', '0', '0');
INSERT INTO `movesay_trade` VALUES ('7', '2', 'btc_cny', '1486.00000000', '147.30000000', '0.00000000', '218887.80000000', '0.00000000', '1', '0', '1467290964', '0', '0');
INSERT INTO `movesay_trade` VALUES ('8', '2', 'btc_cny', '4350.00000000', '301.00000000', '2.00000000', '1309350.00000000', '0.00000000', '1', '0', '1467290997', '0', '0');
INSERT INTO `movesay_trade` VALUES ('9', '2', 'btc_cny', '4400.00000000', '10.60000000', '10.60000000', '46640.00000000', '0.00000000', '2', '0', '1467291026', '0', '1');
INSERT INTO `movesay_trade` VALUES ('10', '2', 'btc_cny', '4350.00000000', '1.00000000', '1.00000000', '4350.00000000', '0.00000000', '2', '0', '1467291031', '0', '1');
INSERT INTO `movesay_trade` VALUES ('11', '2', 'btc_cny', '4350.00000000', '1.00000000', '1.00000000', '4350.00000000', '0.00000000', '2', '0', '1467291036', '0', '1');
INSERT INTO `movesay_trade` VALUES ('12', '2', 'btc_cny', '4400.00000000', '0.30000000', '0.30000000', '1320.00000000', '0.00000000', '1', '0', '1467291050', '0', '1');
INSERT INTO `movesay_trade` VALUES ('13', '2', 'btc_cny', '4568.00000000', '0.10000000', '0.10000000', '456.80000000', '0.00000000', '1', '0', '1467291059', '0', '1');
INSERT INTO `movesay_trade` VALUES ('14', '2', 'btc_cny', '4400.00000000', '0.10000000', '0.10000000', '440.00000000', '0.00000000', '1', '0', '1467291073', '0', '1');
INSERT INTO `movesay_trade` VALUES ('15', '2', 'ltc_cny', '20.00000000', '1245.00000000', '0.00000000', '24900.00000000', '0.00000000', '1', '0', '1467291151', '0', '0');
INSERT INTO `movesay_trade` VALUES ('16', '2', 'ltc_cny', '30.00000000', '476.00000000', '47.00000000', '14280.00000000', '0.00000000', '2', '0', '1467291169', '0', '0');
INSERT INTO `movesay_trade` VALUES ('17', '2', 'ltc_cny', '40.00000000', '453.00000000', '0.00000000', '18120.00000000', '0.00000000', '2', '0', '1467291186', '0', '0');
INSERT INTO `movesay_trade` VALUES ('18', '2', 'ltc_cny', '54.00000000', '45.00000000', '0.00000000', '2430.00000000', '0.00000000', '2', '0', '1467291198', '0', '0');
INSERT INTO `movesay_trade` VALUES ('19', '2', 'ltc_cny', '32.40000000', '786.00000000', '0.00000000', '25466.40000000', '0.00000000', '2', '0', '1467291211', '0', '0');
INSERT INTO `movesay_trade` VALUES ('20', '2', 'ltc_cny', '777.00000000', '888.00000000', '0.00000000', '689976.00000000', '0.00000000', '2', '0', '1467291230', '0', '0');
INSERT INTO `movesay_trade` VALUES ('21', '2', 'ltc_cny', '25.00000000', '453.00000000', '0.00000000', '11325.00000000', '0.00000000', '1', '0', '1467291240', '0', '0');
INSERT INTO `movesay_trade` VALUES ('22', '2', 'ltc_cny', '10.00000000', '453.00000000', '0.00000000', '4530.00000000', '0.00000000', '1', '0', '1467291249', '0', '0');
INSERT INTO `movesay_trade` VALUES ('23', '2', 'ltc_cny', '1.00000000', '7777.00000000', '0.00000000', '7777.00000000', '0.00000000', '1', '0', '1467291259', '0', '0');
INSERT INTO `movesay_trade` VALUES ('24', '2', 'ltc_cny', '27.00000000', '1000.00000000', '874.00000000', '27000.00000000', '0.00000000', '1', '0', '1467291272', '0', '0');
INSERT INTO `movesay_trade` VALUES ('25', '2', 'ltc_cny', '27.00000000', '42.00000000', '42.00000000', '1134.00000000', '0.00000000', '2', '0', '1467291282', '0', '1');
INSERT INTO `movesay_trade` VALUES ('26', '2', 'ltc_cny', '27.00000000', '45.00000000', '45.00000000', '1215.00000000', '0.00000000', '2', '0', '1467291287', '0', '1');
INSERT INTO `movesay_trade` VALUES ('27', '2', 'ltc_cny', '27.00000000', '786.00000000', '786.00000000', '21222.00000000', '0.00000000', '2', '0', '1467291295', '0', '1');
INSERT INTO `movesay_trade` VALUES ('28', '2', 'ltc_cny', '27.00000000', '1.00000000', '1.00000000', '27.00000000', '0.00000000', '2', '0', '1467291307', '0', '1');
INSERT INTO `movesay_trade` VALUES ('29', '2', 'ltc_cny', '30.00000000', '1.00000000', '1.00000000', '30.00000000', '0.00000000', '1', '0', '1467291314', '0', '1');
INSERT INTO `movesay_trade` VALUES ('30', '2', 'ltc_cny', '30.00000000', '1.00000000', '1.00000000', '30.00000000', '0.00000000', '1', '0', '1467291319', '0', '1');
INSERT INTO `movesay_trade` VALUES ('31', '2', 'ytc_cny', '10.00000000', '1000.00000000', '553.00000000', '10000.00000000', '0.00000000', '1', '0', '1467291499', '0', '0');
INSERT INTO `movesay_trade` VALUES ('32', '2', 'ytc_cny', '1.00000000', '10000.00000000', '0.00000000', '10000.00000000', '0.00000000', '1', '0', '1467291511', '0', '0');
INSERT INTO `movesay_trade` VALUES ('33', '2', 'ytc_cny', '5.00000000', '4537.00000000', '0.00000000', '22685.00000000', '0.00000000', '1', '0', '1467291516', '0', '0');
INSERT INTO `movesay_trade` VALUES ('34', '2', 'ytc_cny', '3.00000000', '1453.00000000', '0.00000000', '4359.00000000', '0.00000000', '1', '0', '1467291524', '0', '0');
INSERT INTO `movesay_trade` VALUES ('35', '2', 'ytc_cny', '8.00000000', '42341.00000000', '0.00000000', '338728.00000000', '0.00000000', '1', '0', '1467291531', '0', '0');
INSERT INTO `movesay_trade` VALUES ('36', '2', 'ytc_cny', '11.00000000', '4753.00000000', '490.00000000', '52283.00000000', '0.00000000', '2', '0', '1467291543', '0', '0');
INSERT INTO `movesay_trade` VALUES ('37', '2', 'ytc_cny', '20.00000000', '4123.00000000', '0.00000000', '82460.00000000', '0.00000000', '2', '0', '1467291548', '0', '0');
INSERT INTO `movesay_trade` VALUES ('38', '2', 'ytc_cny', '45.00000000', '120.00000000', '0.00000000', '5400.00000000', '0.00000000', '2', '0', '1467291559', '0', '0');
INSERT INTO `movesay_trade` VALUES ('39', '2', 'ytc_cny', '35.00000000', '7786.00000000', '0.00000000', '272510.00000000', '0.00000000', '2', '0', '1467291570', '0', '0');
INSERT INTO `movesay_trade` VALUES ('40', '2', 'ytc_cny', '14.50000000', '955.00000000', '0.00000000', '13847.50000000', '0.00000000', '2', '0', '1467291585', '0', '0');
INSERT INTO `movesay_trade` VALUES ('41', '2', 'ytc_cny', '12.00000000', '312.00000000', '0.00000000', '3744.00000000', '0.00000000', '2', '0', '1467291592', '0', '0');
INSERT INTO `movesay_trade` VALUES ('42', '2', 'ytc_cny', '11.00000000', '1.00000000', '1.00000000', '11.00000000', '0.00000000', '1', '0', '1467291605', '0', '1');
INSERT INTO `movesay_trade` VALUES ('43', '2', 'ytc_cny', '10.00000000', '453.00000000', '453.00000000', '4530.00000000', '0.00000000', '2', '0', '1467291610', '0', '1');
INSERT INTO `movesay_trade` VALUES ('44', '2', 'ytc_cny', '10.00000000', '45.00000000', '45.00000000', '450.00000000', '0.00000000', '2', '0', '1467291620', '0', '1');
INSERT INTO `movesay_trade` VALUES ('45', '2', 'ytc_cny', '10.00000000', '55.00000000', '55.00000000', '550.00000000', '0.00000000', '2', '0', '1467291624', '0', '1');
INSERT INTO `movesay_trade` VALUES ('46', '2', 'ytc_cny', '11.00000000', '444.00000000', '444.00000000', '4884.00000000', '0.00000000', '1', '0', '1467291632', '0', '1');
INSERT INTO `movesay_trade` VALUES ('47', '2', 'ytc_cny', '11.00000000', '45.00000000', '45.00000000', '495.00000000', '0.00000000', '1', '0', '1467291640', '0', '1');
INSERT INTO `movesay_trade` VALUES ('48', '2', 'btc_cny', '4399.00000000', '21.00000000', '2.00000000', '92379.00000000', '0.00000000', '1', '0', '1467360494', '0', '0');
INSERT INTO `movesay_trade` VALUES ('49', '2', 'btc_cny', '5399.00000000', '452.00000000', '0.00000000', '2440348.00000000', '0.00000000', '2', '0', '1467360524', '0', '0');
INSERT INTO `movesay_trade` VALUES ('50', '2', 'btc_cny', '7567.00000000', '77.00000000', '0.00000000', '582659.00000000', '0.00000000', '2', '0', '1467360539', '0', '0');
INSERT INTO `movesay_trade` VALUES ('51', '2', 'btc_cny', '7888.00000000', '78.00000000', '0.00000000', '615264.00000000', '0.00000000', '2', '0', '1467360551', '0', '0');
INSERT INTO `movesay_trade` VALUES ('52', '2', 'btc_cny', '5012.00000000', '44.00000000', '0.00000000', '220528.00000000', '0.00000000', '2', '0', '1467360564', '0', '0');
INSERT INTO `movesay_trade` VALUES ('53', '2', 'btc_cny', '10000.00000000', '2.00000000', '0.00000000', '20000.00000000', '0.00000000', '2', '0', '1467360581', '0', '0');
INSERT INTO `movesay_trade` VALUES ('54', '2', 'btc_cny', '4850.00000000', '77.00000000', '0.00000000', '373450.00000000', '0.00000000', '2', '0', '1467360600', '0', '0');
INSERT INTO `movesay_trade` VALUES ('55', '2', 'btc_cny', '4599.00000000', '24.00000000', '2.00000000', '110376.00000000', '0.00000000', '2', '0', '1467360614', '0', '0');
INSERT INTO `movesay_trade` VALUES ('56', '2', 'btc_cny', '1.00000000', '1.00000000', '0.00000000', '1.00000000', '0.00000000', '1', '0', '1467360626', '0', '0');
INSERT INTO `movesay_trade` VALUES ('57', '2', 'btc_cny', '2.00000000', '2.00000000', '0.00000000', '4.00000000', '0.00000000', '1', '0', '1467360630', '0', '0');
INSERT INTO `movesay_trade` VALUES ('58', '2', 'btc_cny', '3.00000000', '3.00000000', '0.00000000', '9.00000000', '0.00000000', '1', '0', '1467360633', '0', '0');
INSERT INTO `movesay_trade` VALUES ('59', '2', 'btc_cny', '4.00000000', '5.00000000', '0.00000000', '20.00000000', '0.00000000', '1', '0', '1467360637', '0', '0');
INSERT INTO `movesay_trade` VALUES ('60', '2', 'btc_cny', '5.00000000', '5.00000000', '0.00000000', '25.00000000', '0.00000000', '1', '0', '1467360640', '0', '0');
INSERT INTO `movesay_trade` VALUES ('61', '2', 'btc_cny', '6.00000000', '6.00000000', '0.00000000', '36.00000000', '0.00000000', '1', '0', '1467360647', '0', '0');
INSERT INTO `movesay_trade` VALUES ('62', '2', 'btc_cny', '7.00000000', '7.00000000', '0.00000000', '49.00000000', '0.00000000', '1', '0', '1467360651', '0', '0');
INSERT INTO `movesay_trade` VALUES ('63', '2', 'btc_cny', '20000.00000000', '2.00000000', '0.00000000', '40000.00000000', '0.00000000', '2', '0', '1467360666', '0', '0');
INSERT INTO `movesay_trade` VALUES ('64', '2', 'btc_cny', '9999.00000000', '9.00000000', '0.00000000', '89991.00000000', '0.00000000', '2', '0', '1467360676', '0', '0');
INSERT INTO `movesay_trade` VALUES ('65', '2', 'btc_cny', '4400.00000000', '1.00000000', '1.00000000', '4400.00000000', '0.00000000', '1', '0', '1467360689', '0', '1');
INSERT INTO `movesay_trade` VALUES ('66', '2', 'btc_cny', '4400.00000000', '1.00000000', '1.00000000', '4400.00000000', '0.00000000', '1', '0', '1467360694', '0', '1');
INSERT INTO `movesay_trade` VALUES ('67', '2', 'btc_cny', '4399.00000000', '1.00000000', '1.00000000', '4399.00000000', '0.00000000', '2', '0', '1467360697', '0', '1');
INSERT INTO `movesay_trade` VALUES ('68', '2', 'btc_cny', '4399.00000000', '1.00000000', '1.00000000', '4399.00000000', '0.00000000', '2', '0', '1467360700', '0', '1');
INSERT INTO `movesay_trade` VALUES ('69', '2', 'btc_cny', '4400.00000000', '1.00000000', '1.00000000', '4400.00000000', '0.00000000', '1', '0', '1467608890', '0', '1');
INSERT INTO `movesay_trade` VALUES ('70', '2', 'btc_cny', '4400.00000000', '5.40000000', '5.40000000', '23760.00000000', '0.00000000', '1', '0', '1467608895', '0', '1');
INSERT INTO `movesay_trade` VALUES ('71', '2', 'btc_cny', '4568.00000000', '24.00000000', '13.70000000', '109632.00000000', '0.00000000', '1', '0', '1467608900', '0', '0');
INSERT INTO `movesay_trade` VALUES ('72', '2', 'btc_cny', '4599.00000000', '1.00000000', '1.00000000', '4599.00000000', '0.00000000', '1', '0', '1467608914', '0', '1');
INSERT INTO `movesay_trade` VALUES ('73', '2', 'btc_cny', '4599.00000000', '1.00000000', '1.00000000', '4599.00000000', '0.00000000', '1', '0', '1467608921', '0', '1');
INSERT INTO `movesay_trade` VALUES ('74', '2', 'ltc_cny', '30.00000000', '1.00000000', '1.00000000', '30.00000000', '0.00000000', '1', '0', '1467608938', '0', '1');
INSERT INTO `movesay_trade` VALUES ('75', '2', 'ltc_cny', '30.00000000', '21.00000000', '21.00000000', '630.00000000', '0.00000000', '1', '0', '1467608941', '0', '1');
INSERT INTO `movesay_trade` VALUES ('76', '2', 'ltc_cny', '32.40000000', '12.00000000', '12.00000000', '388.80000000', '0.00000000', '1', '0', '1467608945', '0', '1');
INSERT INTO `movesay_trade` VALUES ('77', '2', 'ltc_cny', '32.40000000', '11.00000000', '11.00000000', '356.40000000', '0.00000000', '1', '0', '1467608949', '0', '1');

-- -----------------------------
-- Table structure for `movesay_trade_json`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_trade_json`;
CREATE TABLE `movesay_trade_json` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `market` varchar(100) NOT NULL,
  `data` varchar(500) NOT NULL,
  `type` varchar(100) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `market` (`market`),
  KEY `market_type_status` (`market`,`type`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=15728 DEFAULT CHARSET=utf8 COMMENT='交易图表表';

-- -----------------------------
-- Records of `movesay_trade_json`
-- -----------------------------
INSERT INTO `movesay_trade_json` VALUES ('1', 'btc_cny', '[1467291032,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '1', '0', '1467291032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2', 'btc_cny', '[1467290880,\"2.30000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '3', '0', '1467290880', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3', 'btc_cny', '[1467291060,\"0.20000000\",\"4400.00000000\",\"4400.00000000\",\"4400.00000000\",\"4400.00000000\"]', '3', '0', '1467291060', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4', 'btc_cny', '[1467291000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '5', '0', '1467291000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5', 'btc_cny', '[1467291000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '10', '0', '1467291000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6', 'btc_cny', '[1467290700,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '15', '0', '1467290700', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7', 'btc_cny', '[1467289800,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '30', '0', '1467289800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8', 'btc_cny', '[1467288000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '60', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9', 'btc_cny', '[1467288000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '120', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10', 'btc_cny', '[1467288000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '240', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11', 'btc_cny', '[1467288000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '360', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12', 'btc_cny', '[1467288000,\"2.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4400.00000000\"]', '720', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13', 'btc_cny', '[1467288000,\"6.50000000\",\"4350.00000000\",\"4400.00000000\",\"4350.00000000\",\"4399.00000000\"]', '1440', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14', 'btc_cny', '[1467288000,\"28.60000000\",\"4350.00000000\",\"4599.00000000\",\"4350.00000000\",\"4599.00000000\"]', '10080', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('18', 'ltc_cny', '[1467291282,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '1', '0', '1467291282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('19', 'ltc_cny', '[1467291240,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '3', '0', '1467291240', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('20', 'ltc_cny', '[1467291000,\"873.00000000\",\"27.00000000\",\"27.00000000\",\"27.00000000\",\"27.00000000\"]', '5', '0', '1467291000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('21', 'ltc_cny', '[1467291300,\"3.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '5', '0', '1467291300', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('22', 'ltc_cny', '[1467291000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '10', '0', '1467291000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('23', 'ltc_cny', '[1467290700,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '15', '0', '1467290700', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('24', 'ltc_cny', '[1467289800,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '30', '0', '1467289800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('25', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '60', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('26', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '120', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('27', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '240', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('28', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '360', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('29', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '720', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('30', 'ltc_cny', '[1467288000,\"876.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '1440', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('31', 'ltc_cny', '[1467288000,\"921.00000000\",\"27.00000000\",\"30.00000000\",\"27.00000000\",\"30.00000000\"]', '10080', '0', '1467288000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('32', 'ltc_cny', '', '1', '0', '1467291342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('43', 'ytc_cny', '[1467291605,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '1', '0', '1467291605', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('44', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '3', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('45', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '5', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('46', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '10', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('47', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '15', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('48', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '30', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('49', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '60', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('50', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '120', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('51', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '240', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('52', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '360', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('53', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '720', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('54', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '1440', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('55', 'ytc_cny', '[1467291600,\"1043.00000000\",\"11.00000000\",\"11.00000000\",\"10.00000000\",\"11.00000000\"]', '10080', '0', '1467291600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('56', 'ytc_cny', '', '1', '0', '1467291665', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('57', 'ytc_cny', '', '3', '0', '1467291780', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('58', 'ytc_cny', '', '5', '0', '1467291900', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('59', 'ytc_cny', '', '10', '0', '1467292200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('60', 'ytc_cny', '', '15', '0', '1467292500', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('61', 'ytc_cny', '', '30', '0', '1467293400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('64', 'ytc_cny', '', '60', '0', '1467295200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('65', 'ytc_cny', '', '120', '0', '1467298800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('72', 'btc_cny', '[1467331200,\"4.00000000\",\"4400.00000000\",\"4400.00000000\",\"4399.00000000\",\"4399.00000000\"]', '720', '0', '1467331200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('80', 'ytc_cny', '', '240', '0', '1467306000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('81', 'ytc_cny', '', '240', '0', '1467320400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('82', 'ytc_cny', '', '240', '0', '1467334800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('83', 'ytc_cny', '', '360', '0', '1467313200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('84', 'ytc_cny', '', '360', '0', '1467334800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('85', 'ytc_cny', '', '720', '0', '1467334800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('231', 'btc_cny', '[1467360000,\"4.00000000\",\"4400.00000000\",\"4400.00000000\",\"4399.00000000\",\"4399.00000000\"]', '60', '0', '1467360000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('241', 'btc_cny', '[1467360000,\"4.00000000\",\"4400.00000000\",\"4400.00000000\",\"4399.00000000\",\"4399.00000000\"]', '120', '0', '1467360000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('243', 'btc_cny', '[1467360000,\"4.00000000\",\"4400.00000000\",\"4400.00000000\",\"4399.00000000\",\"4399.00000000\"]', '240', '0', '1467360000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('245', 'btc_cny', '[1467352800,\"4.00000000\",\"4400.00000000\",\"4400.00000000\",\"4399.00000000\",\"4399.00000000\"]', '360', '0', '1467352800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('369', 'btc_cny', '[1467360000,\"4.00000000\",\"4400.00000000\",\"4400.00000000\",\"4399.00000000\",\"4399.00000000\"]', '30', '0', '1467360000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('575', 'btc_cny', '[1467360000,\"4.00000000\",\"4400.00000000\",\"4400.00000000\",\"4399.00000000\",\"4399.00000000\"]', '15', '0', '1467360000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('739', 'btc_cny', '[1467360600,\"4.00000000\",\"4400.00000000\",\"4400.00000000\",\"4399.00000000\",\"4399.00000000\"]', '10', '0', '1467360600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('1109', 'btc_cny', '[1467360600,\"4.00000000\",\"4400.00000000\",\"4400.00000000\",\"4399.00000000\",\"4399.00000000\"]', '5', '0', '1467360600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('1433', 'btc_cny', '[1467360540,\"4.00000000\",\"4400.00000000\",\"4400.00000000\",\"4399.00000000\",\"4399.00000000\"]', '3', '0', '1467360540', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2238', 'btc_cny', '[1467360632,\"1.00000000\",\"4400.00000000\",\"4400.00000000\",\"4400.00000000\",\"4400.00000000\"]', '1', '0', '1467360632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2239', 'btc_cny', '[1467360692,\"3.00000000\",\"4400.00000000\",\"4400.00000000\",\"4399.00000000\",\"4399.00000000\"]', '1', '0', '1467360692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2240', 'btc_cny', '', '1', '0', '1467360752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2241', 'btc_cny', '', '1', '0', '1467360812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2242', 'btc_cny', '', '1', '0', '1467360872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2243', 'btc_cny', '', '1', '0', '1467360932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2244', 'btc_cny', '', '1', '0', '1467360992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2245', 'btc_cny', '', '1', '0', '1467361052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2246', 'btc_cny', '', '1', '0', '1467361112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2247', 'btc_cny', '', '1', '0', '1467361172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2248', 'btc_cny', '', '1', '0', '1467361232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2249', 'btc_cny', '', '1', '0', '1467361292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2250', 'btc_cny', '', '1', '0', '1467361352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2251', 'btc_cny', '', '1', '0', '1467361412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2252', 'btc_cny', '', '1', '0', '1467361472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2253', 'btc_cny', '', '1', '0', '1467361532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2254', 'btc_cny', '', '1', '0', '1467361592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2255', 'btc_cny', '', '1', '0', '1467361652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2256', 'btc_cny', '', '1', '0', '1467361712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2257', 'btc_cny', '', '1', '0', '1467361772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2258', 'btc_cny', '', '1', '0', '1467361832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2259', 'btc_cny', '', '1', '0', '1467361892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2266', 'ytc_cny', '', '1440', '0', '1467378000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2267', 'btc_cny', '', '1', '0', '1467361892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2268', 'btc_cny', '', '1', '0', '1467361952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2269', 'btc_cny', '', '1', '0', '1467362012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2270', 'btc_cny', '', '1', '0', '1467362072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2271', 'btc_cny', '', '1', '0', '1467362132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2272', 'btc_cny', '', '1', '0', '1467362192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2273', 'btc_cny', '', '1', '0', '1467362252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2274', 'btc_cny', '', '1', '0', '1467362312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2275', 'btc_cny', '', '1', '0', '1467362372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2276', 'btc_cny', '', '1', '0', '1467362432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2277', 'btc_cny', '', '1', '0', '1467362492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2278', 'btc_cny', '', '1', '0', '1467362552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2279', 'btc_cny', '', '1', '0', '1467362612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2280', 'btc_cny', '', '1', '0', '1467362672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2281', 'btc_cny', '', '1', '0', '1467362732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2282', 'btc_cny', '', '1', '0', '1467362792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2283', 'btc_cny', '', '1', '0', '1467362852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2284', 'btc_cny', '', '1', '0', '1467362912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2285', 'btc_cny', '', '1', '0', '1467362972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2286', 'btc_cny', '', '1', '0', '1467363032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2287', 'btc_cny', '', '1', '0', '1467363092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2451', 'btc_cny', '[1467604800,\"22.10000000\",\"4400.00000000\",\"4599.00000000\",\"4400.00000000\",\"4599.00000000\"]', '240', '0', '1467604800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2462', 'btc_cny', '[1467590400,\"22.10000000\",\"4400.00000000\",\"4599.00000000\",\"4400.00000000\",\"4599.00000000\"]', '360', '0', '1467590400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2468', 'btc_cny', '[1467590400,\"22.10000000\",\"4400.00000000\",\"4599.00000000\",\"4400.00000000\",\"4599.00000000\"]', '720', '0', '1467590400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2471', 'btc_cny', '[1467547200,\"22.10000000\",\"4400.00000000\",\"4599.00000000\",\"4400.00000000\",\"4599.00000000\"]', '1440', '0', '1467547200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2472', 'ltc_cny', '', '1', '0', '1467291342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2473', 'ltc_cny', '', '1', '0', '1467291402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2474', 'ltc_cny', '', '1', '0', '1467291462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2475', 'ltc_cny', '', '1', '0', '1467291522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2476', 'ltc_cny', '', '1', '0', '1467291582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2477', 'ltc_cny', '', '1', '0', '1467291642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2478', 'ltc_cny', '', '1', '0', '1467291702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2479', 'ltc_cny', '', '1', '0', '1467291762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2480', 'ltc_cny', '', '1', '0', '1467291822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2481', 'ltc_cny', '', '1', '0', '1467291882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2482', 'ltc_cny', '', '1', '0', '1467291942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2483', 'ltc_cny', '', '1', '0', '1467292002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2484', 'ltc_cny', '', '1', '0', '1467292062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2485', 'ltc_cny', '', '1', '0', '1467292122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2486', 'ltc_cny', '', '1', '0', '1467292182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2487', 'ltc_cny', '', '1', '0', '1467292242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2488', 'ltc_cny', '', '1', '0', '1467292302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2489', 'ltc_cny', '', '1', '0', '1467292362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2490', 'ltc_cny', '', '1', '0', '1467292422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2491', 'ltc_cny', '', '1', '0', '1467292482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2492', 'ltc_cny', '', '1', '0', '1467292542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2658', 'ltc_cny', '[1467604800,\"45.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\"]', '240', '0', '1467604800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2671', 'ltc_cny', '[1467590400,\"45.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\"]', '360', '0', '1467590400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2678', 'ltc_cny', '[1467590400,\"45.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\"]', '720', '0', '1467590400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2681', 'ltc_cny', '[1467547200,\"45.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\"]', '1440', '0', '1467547200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2682', 'btc_cny', '', '1', '0', '1467363092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2683', 'btc_cny', '', '1', '0', '1467363152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2684', 'btc_cny', '', '1', '0', '1467363212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2685', 'btc_cny', '', '1', '0', '1467363272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2686', 'btc_cny', '', '1', '0', '1467363332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2687', 'btc_cny', '', '1', '0', '1467363392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2688', 'btc_cny', '', '1', '0', '1467363452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2689', 'btc_cny', '', '1', '0', '1467363512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2690', 'btc_cny', '', '1', '0', '1467363572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2691', 'btc_cny', '', '1', '0', '1467363632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2692', 'btc_cny', '', '1', '0', '1467363692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2693', 'btc_cny', '', '1', '0', '1467363752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2694', 'btc_cny', '', '1', '0', '1467363812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2695', 'btc_cny', '', '1', '0', '1467363872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2696', 'btc_cny', '', '1', '0', '1467363932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2697', 'btc_cny', '', '1', '0', '1467363992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2698', 'btc_cny', '', '1', '0', '1467364052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2699', 'btc_cny', '', '1', '0', '1467364112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2700', 'btc_cny', '', '1', '0', '1467364172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2701', 'btc_cny', '', '1', '0', '1467364232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2702', 'btc_cny', '', '1', '0', '1467364292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2842', 'btc_cny', '[1467604800,\"22.10000000\",\"4400.00000000\",\"4599.00000000\",\"4400.00000000\",\"4599.00000000\"]', '120', '0', '1467604800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2843', 'ltc_cny', '', '1', '0', '1467292542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2844', 'ltc_cny', '', '1', '0', '1467292602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2845', 'ltc_cny', '', '1', '0', '1467292662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2846', 'ltc_cny', '', '1', '0', '1467292722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2847', 'ltc_cny', '', '1', '0', '1467292782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2848', 'ltc_cny', '', '1', '0', '1467292842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2849', 'ltc_cny', '', '1', '0', '1467292902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2850', 'ltc_cny', '', '1', '0', '1467292962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2851', 'ltc_cny', '', '1', '0', '1467293022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2852', 'ltc_cny', '', '1', '0', '1467293082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2853', 'ltc_cny', '', '1', '0', '1467293142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2854', 'ltc_cny', '', '1', '0', '1467293202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2855', 'ltc_cny', '', '1', '0', '1467293262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2856', 'ltc_cny', '', '1', '0', '1467293322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2857', 'ltc_cny', '', '1', '0', '1467293382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2858', 'ltc_cny', '', '1', '0', '1467293442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2859', 'ltc_cny', '', '1', '0', '1467293502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2860', 'ltc_cny', '', '1', '0', '1467293562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2861', 'ltc_cny', '', '1', '0', '1467293622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2862', 'ltc_cny', '', '1', '0', '1467293682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('2863', 'ltc_cny', '', '1', '0', '1467293742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3011', 'btc_cny', '', '1', '0', '1467364292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3012', 'btc_cny', '', '1', '0', '1467364352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3013', 'btc_cny', '', '1', '0', '1467364412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3014', 'btc_cny', '', '1', '0', '1467364472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3015', 'btc_cny', '', '1', '0', '1467364532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3016', 'btc_cny', '', '1', '0', '1467364592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3017', 'btc_cny', '', '1', '0', '1467364652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3018', 'btc_cny', '', '1', '0', '1467364712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3019', 'btc_cny', '', '1', '0', '1467364772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3020', 'btc_cny', '', '1', '0', '1467364832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3021', 'btc_cny', '', '1', '0', '1467364892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3022', 'btc_cny', '', '1', '0', '1467364952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3023', 'btc_cny', '', '1', '0', '1467365012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3024', 'btc_cny', '', '1', '0', '1467365072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3025', 'btc_cny', '', '1', '0', '1467365132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3026', 'btc_cny', '', '1', '0', '1467365192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3027', 'btc_cny', '', '1', '0', '1467365252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3028', 'btc_cny', '', '1', '0', '1467365312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3029', 'btc_cny', '', '1', '0', '1467365372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3030', 'btc_cny', '', '1', '0', '1467365432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3031', 'btc_cny', '', '1', '0', '1467365492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3158', 'ltc_cny', '', '1', '0', '1467293742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3159', 'ltc_cny', '', '1', '0', '1467293802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3160', 'ltc_cny', '', '1', '0', '1467293862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3161', 'ltc_cny', '', '1', '0', '1467293922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3162', 'ltc_cny', '', '1', '0', '1467293982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3163', 'ltc_cny', '', '1', '0', '1467294042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3164', 'ltc_cny', '', '1', '0', '1467294102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3165', 'ltc_cny', '', '1', '0', '1467294162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3166', 'ltc_cny', '', '1', '0', '1467294222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3167', 'ltc_cny', '', '1', '0', '1467294282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3168', 'ltc_cny', '', '1', '0', '1467294342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3169', 'ltc_cny', '', '1', '0', '1467294402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3170', 'ltc_cny', '', '1', '0', '1467294462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3171', 'ltc_cny', '', '1', '0', '1467294522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3172', 'ltc_cny', '', '1', '0', '1467294582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3173', 'ltc_cny', '', '1', '0', '1467294642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3174', 'ltc_cny', '', '1', '0', '1467294702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3175', 'ltc_cny', '', '1', '0', '1467294762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3176', 'ltc_cny', '', '1', '0', '1467294822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3177', 'ltc_cny', '', '1', '0', '1467294882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3178', 'ltc_cny', '', '1', '0', '1467294942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3308', 'ltc_cny', '[1467604800,\"45.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\"]', '120', '0', '1467604800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3309', 'btc_cny', '', '1', '0', '1467365492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3310', 'btc_cny', '', '1', '0', '1467365552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3311', 'btc_cny', '', '1', '0', '1467365612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3312', 'btc_cny', '', '1', '0', '1467365672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3313', 'btc_cny', '', '1', '0', '1467365732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3314', 'btc_cny', '', '1', '0', '1467365792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3315', 'btc_cny', '', '1', '0', '1467365852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3316', 'btc_cny', '', '1', '0', '1467365912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3317', 'btc_cny', '', '1', '0', '1467365972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3318', 'btc_cny', '', '1', '0', '1467366032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3319', 'btc_cny', '', '1', '0', '1467366092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3320', 'btc_cny', '', '1', '0', '1467366152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3321', 'btc_cny', '', '1', '0', '1467366212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3322', 'btc_cny', '', '1', '0', '1467366272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3323', 'btc_cny', '', '1', '0', '1467366332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3324', 'btc_cny', '', '1', '0', '1467366392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3325', 'btc_cny', '', '1', '0', '1467366452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3326', 'btc_cny', '', '1', '0', '1467366512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3327', 'btc_cny', '', '1', '0', '1467366572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3328', 'btc_cny', '', '1', '0', '1467366632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3329', 'btc_cny', '', '1', '0', '1467366692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3443', 'btc_cny', '[1467608400,\"22.10000000\",\"4400.00000000\",\"4599.00000000\",\"4400.00000000\",\"4599.00000000\"]', '60', '0', '1467608400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3444', 'ltc_cny', '', '1', '0', '1467294942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3445', 'ltc_cny', '', '1', '0', '1467295002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3446', 'ltc_cny', '', '1', '0', '1467295062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3447', 'ltc_cny', '', '1', '0', '1467295122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3448', 'ltc_cny', '', '1', '0', '1467295182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3449', 'ltc_cny', '', '1', '0', '1467295242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3450', 'ltc_cny', '', '1', '0', '1467295302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3451', 'ltc_cny', '', '1', '0', '1467295362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3452', 'ltc_cny', '', '1', '0', '1467295422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3453', 'ltc_cny', '', '1', '0', '1467295482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3454', 'ltc_cny', '', '1', '0', '1467295542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3455', 'ltc_cny', '', '1', '0', '1467295602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3456', 'ltc_cny', '', '1', '0', '1467295662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3457', 'ltc_cny', '', '1', '0', '1467295722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3458', 'ltc_cny', '', '1', '0', '1467295782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3459', 'ltc_cny', '', '1', '0', '1467295842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3460', 'ltc_cny', '', '1', '0', '1467295902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3461', 'ltc_cny', '', '1', '0', '1467295962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3462', 'ltc_cny', '', '1', '0', '1467296022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3463', 'ltc_cny', '', '1', '0', '1467296082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3464', 'ltc_cny', '', '1', '0', '1467296142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3591', 'btc_cny', '', '1', '0', '1467366692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3592', 'btc_cny', '', '1', '0', '1467366752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3593', 'btc_cny', '', '1', '0', '1467366812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3594', 'btc_cny', '', '1', '0', '1467366872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3595', 'btc_cny', '', '1', '0', '1467366932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3596', 'btc_cny', '', '1', '0', '1467366992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3597', 'btc_cny', '', '1', '0', '1467367052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3598', 'btc_cny', '', '1', '0', '1467367112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3599', 'btc_cny', '', '1', '0', '1467367172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3600', 'btc_cny', '', '1', '0', '1467367232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3601', 'btc_cny', '', '1', '0', '1467367292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3602', 'btc_cny', '', '1', '0', '1467367352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3603', 'btc_cny', '', '1', '0', '1467367412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3604', 'btc_cny', '', '1', '0', '1467367472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3605', 'btc_cny', '', '1', '0', '1467367532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3606', 'btc_cny', '', '1', '0', '1467367592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3607', 'btc_cny', '', '1', '0', '1467367652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3608', 'btc_cny', '', '1', '0', '1467367712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3609', 'btc_cny', '', '1', '0', '1467367772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3610', 'btc_cny', '', '1', '0', '1467367832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3611', 'btc_cny', '', '1', '0', '1467367892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3717', 'ltc_cny', '', '1', '0', '1467296142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3718', 'ltc_cny', '', '1', '0', '1467296202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3719', 'ltc_cny', '', '1', '0', '1467296262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3720', 'ltc_cny', '', '1', '0', '1467296322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3721', 'ltc_cny', '', '1', '0', '1467296382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3722', 'ltc_cny', '', '1', '0', '1467296442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3723', 'ltc_cny', '', '1', '0', '1467296502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3724', 'ltc_cny', '', '1', '0', '1467296562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3725', 'ltc_cny', '', '1', '0', '1467296622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3726', 'ltc_cny', '', '1', '0', '1467296682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3727', 'ltc_cny', '', '1', '0', '1467296742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3728', 'ltc_cny', '', '1', '0', '1467296802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3729', 'ltc_cny', '', '1', '0', '1467296862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3730', 'ltc_cny', '', '1', '0', '1467296922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3731', 'ltc_cny', '', '1', '0', '1467296982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3732', 'ltc_cny', '', '1', '0', '1467297042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3733', 'ltc_cny', '', '1', '0', '1467297102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3734', 'ltc_cny', '', '1', '0', '1467297162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3735', 'ltc_cny', '', '1', '0', '1467297222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3736', 'ltc_cny', '', '1', '0', '1467297282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3737', 'ltc_cny', '', '1', '0', '1467297342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3851', 'ltc_cny', '[1467608400,\"45.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\"]', '60', '0', '1467608400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3852', 'btc_cny', '', '1', '0', '1467367892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3853', 'btc_cny', '', '1', '0', '1467367952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3854', 'btc_cny', '', '1', '0', '1467368012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3855', 'btc_cny', '', '1', '0', '1467368072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3856', 'btc_cny', '', '1', '0', '1467368132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3857', 'btc_cny', '', '1', '0', '1467368192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3858', 'btc_cny', '', '1', '0', '1467368252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3859', 'btc_cny', '', '1', '0', '1467368312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3860', 'btc_cny', '', '1', '0', '1467368372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3861', 'btc_cny', '', '1', '0', '1467368432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3862', 'btc_cny', '', '1', '0', '1467368492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3863', 'btc_cny', '', '1', '0', '1467368552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3864', 'btc_cny', '', '1', '0', '1467368612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3865', 'btc_cny', '', '1', '0', '1467368672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3866', 'btc_cny', '', '1', '0', '1467368732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3867', 'btc_cny', '', '1', '0', '1467368792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3868', 'btc_cny', '', '1', '0', '1467368852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3869', 'btc_cny', '', '1', '0', '1467368912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3870', 'btc_cny', '', '1', '0', '1467368972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3871', 'btc_cny', '', '1', '0', '1467369032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3872', 'btc_cny', '', '1', '0', '1467369092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3978', 'ltc_cny', '', '1', '0', '1467297342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3979', 'ltc_cny', '', '1', '0', '1467297402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3980', 'ltc_cny', '', '1', '0', '1467297462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3981', 'ltc_cny', '', '1', '0', '1467297522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3982', 'ltc_cny', '', '1', '0', '1467297582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3983', 'ltc_cny', '', '1', '0', '1467297642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3984', 'ltc_cny', '', '1', '0', '1467297702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3985', 'ltc_cny', '', '1', '0', '1467297762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3986', 'ltc_cny', '', '1', '0', '1467297822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3987', 'ltc_cny', '', '1', '0', '1467297882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3988', 'ltc_cny', '', '1', '0', '1467297942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3989', 'ltc_cny', '', '1', '0', '1467298002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3990', 'ltc_cny', '', '1', '0', '1467298062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3991', 'ltc_cny', '', '1', '0', '1467298122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3992', 'ltc_cny', '', '1', '0', '1467298182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3993', 'ltc_cny', '', '1', '0', '1467298242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3994', 'ltc_cny', '', '1', '0', '1467298302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3995', 'ltc_cny', '', '1', '0', '1467298362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3996', 'ltc_cny', '', '1', '0', '1467298422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3997', 'ltc_cny', '', '1', '0', '1467298482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('3998', 'ltc_cny', '', '1', '0', '1467298542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4104', 'btc_cny', '', '1', '0', '1467369092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4105', 'btc_cny', '', '1', '0', '1467369152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4106', 'btc_cny', '', '1', '0', '1467369212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4107', 'btc_cny', '', '1', '0', '1467369272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4108', 'btc_cny', '', '1', '0', '1467369332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4109', 'btc_cny', '', '1', '0', '1467369392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4110', 'btc_cny', '', '1', '0', '1467369452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4111', 'btc_cny', '', '1', '0', '1467369512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4112', 'btc_cny', '', '1', '0', '1467369572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4113', 'btc_cny', '', '1', '0', '1467369632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4114', 'btc_cny', '', '1', '0', '1467369692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4115', 'btc_cny', '', '1', '0', '1467369752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4116', 'btc_cny', '', '1', '0', '1467369812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4117', 'btc_cny', '', '1', '0', '1467369872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4118', 'btc_cny', '', '1', '0', '1467369932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4119', 'btc_cny', '', '1', '0', '1467369992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4120', 'btc_cny', '', '1', '0', '1467370052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4121', 'btc_cny', '', '1', '0', '1467370112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4122', 'btc_cny', '', '1', '0', '1467370172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4123', 'btc_cny', '', '1', '0', '1467370232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4124', 'btc_cny', '', '1', '0', '1467370292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4226', 'btc_cny', '[1467608400,\"22.10000000\",\"4400.00000000\",\"4599.00000000\",\"4400.00000000\",\"4599.00000000\"]', '30', '0', '1467608400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4227', 'ltc_cny', '', '1', '0', '1467298542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4228', 'ltc_cny', '', '1', '0', '1467298602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4229', 'ltc_cny', '', '1', '0', '1467298662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4230', 'ltc_cny', '', '1', '0', '1467298722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4231', 'ltc_cny', '', '1', '0', '1467298782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4232', 'ltc_cny', '', '1', '0', '1467298842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4233', 'ltc_cny', '', '1', '0', '1467298902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4234', 'ltc_cny', '', '1', '0', '1467298962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4235', 'ltc_cny', '', '1', '0', '1467299022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4236', 'ltc_cny', '', '1', '0', '1467299082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4237', 'ltc_cny', '', '1', '0', '1467299142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4238', 'ltc_cny', '', '1', '0', '1467299202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4239', 'ltc_cny', '', '1', '0', '1467299262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4240', 'ltc_cny', '', '1', '0', '1467299322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4241', 'ltc_cny', '', '1', '0', '1467299382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4242', 'ltc_cny', '', '1', '0', '1467299442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4243', 'ltc_cny', '', '1', '0', '1467299502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4244', 'ltc_cny', '', '1', '0', '1467299562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4245', 'ltc_cny', '', '1', '0', '1467299622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4246', 'ltc_cny', '', '1', '0', '1467299682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4247', 'ltc_cny', '', '1', '0', '1467299742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4353', 'btc_cny', '', '1', '0', '1467370292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4354', 'btc_cny', '', '1', '0', '1467370352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4355', 'btc_cny', '', '1', '0', '1467370412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4356', 'btc_cny', '', '1', '0', '1467370472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4357', 'btc_cny', '', '1', '0', '1467370532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4358', 'btc_cny', '', '1', '0', '1467370592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4359', 'btc_cny', '', '1', '0', '1467370652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4360', 'btc_cny', '', '1', '0', '1467370712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4361', 'btc_cny', '', '1', '0', '1467370772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4362', 'btc_cny', '', '1', '0', '1467370832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4363', 'btc_cny', '', '1', '0', '1467370892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4364', 'btc_cny', '', '1', '0', '1467370952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4365', 'btc_cny', '', '1', '0', '1467371012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4366', 'btc_cny', '', '1', '0', '1467371072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4367', 'btc_cny', '', '1', '0', '1467371132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4368', 'btc_cny', '', '1', '0', '1467371192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4369', 'btc_cny', '', '1', '0', '1467371252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4370', 'btc_cny', '', '1', '0', '1467371312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4371', 'btc_cny', '', '1', '0', '1467371372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4372', 'btc_cny', '', '1', '0', '1467371432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4373', 'btc_cny', '', '1', '0', '1467371492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4458', 'ltc_cny', '', '1', '0', '1467299742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4459', 'ltc_cny', '', '1', '0', '1467299802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4460', 'ltc_cny', '', '1', '0', '1467299862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4461', 'ltc_cny', '', '1', '0', '1467299922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4462', 'ltc_cny', '', '1', '0', '1467299982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4463', 'ltc_cny', '', '1', '0', '1467300042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4464', 'ltc_cny', '', '1', '0', '1467300102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4465', 'ltc_cny', '', '1', '0', '1467300162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4466', 'ltc_cny', '', '1', '0', '1467300222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4467', 'ltc_cny', '', '1', '0', '1467300282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4468', 'ltc_cny', '', '1', '0', '1467300342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4469', 'ltc_cny', '', '1', '0', '1467300402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4470', 'ltc_cny', '', '1', '0', '1467300462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4471', 'ltc_cny', '', '1', '0', '1467300522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4472', 'ltc_cny', '', '1', '0', '1467300582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4473', 'ltc_cny', '', '1', '0', '1467300642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4474', 'ltc_cny', '', '1', '0', '1467300702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4475', 'ltc_cny', '', '1', '0', '1467300762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4476', 'ltc_cny', '', '1', '0', '1467300822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4477', 'ltc_cny', '', '1', '0', '1467300882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4478', 'ltc_cny', '', '1', '0', '1467300942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4584', 'btc_cny', '', '1', '0', '1467371492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4585', 'btc_cny', '', '1', '0', '1467371552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4586', 'btc_cny', '', '1', '0', '1467371612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4587', 'btc_cny', '', '1', '0', '1467371672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4588', 'btc_cny', '', '1', '0', '1467371732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4589', 'btc_cny', '', '1', '0', '1467371792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4590', 'btc_cny', '', '1', '0', '1467371852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4591', 'btc_cny', '', '1', '0', '1467371912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4592', 'btc_cny', '', '1', '0', '1467371972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4593', 'btc_cny', '', '1', '0', '1467372032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4594', 'btc_cny', '', '1', '0', '1467372092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4595', 'btc_cny', '', '1', '0', '1467372152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4596', 'btc_cny', '', '1', '0', '1467372212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4597', 'btc_cny', '', '1', '0', '1467372272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4598', 'btc_cny', '', '1', '0', '1467372332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4599', 'btc_cny', '', '1', '0', '1467372392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4600', 'btc_cny', '', '1', '0', '1467372452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4601', 'btc_cny', '', '1', '0', '1467372512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4602', 'btc_cny', '', '1', '0', '1467372572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4603', 'btc_cny', '', '1', '0', '1467372632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4604', 'btc_cny', '', '1', '0', '1467372692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4689', 'ltc_cny', '', '1', '0', '1467300942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4690', 'ltc_cny', '', '1', '0', '1467301002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4691', 'ltc_cny', '', '1', '0', '1467301062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4692', 'ltc_cny', '', '1', '0', '1467301122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4693', 'ltc_cny', '', '1', '0', '1467301182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4694', 'ltc_cny', '', '1', '0', '1467301242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4695', 'ltc_cny', '', '1', '0', '1467301302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4696', 'ltc_cny', '', '1', '0', '1467301362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4697', 'ltc_cny', '', '1', '0', '1467301422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4698', 'ltc_cny', '', '1', '0', '1467301482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4699', 'ltc_cny', '', '1', '0', '1467301542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4700', 'ltc_cny', '', '1', '0', '1467301602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4701', 'ltc_cny', '', '1', '0', '1467301662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4702', 'ltc_cny', '', '1', '0', '1467301722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4703', 'ltc_cny', '', '1', '0', '1467301782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4704', 'ltc_cny', '', '1', '0', '1467301842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4705', 'ltc_cny', '', '1', '0', '1467301902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4706', 'ltc_cny', '', '1', '0', '1467301962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4707', 'ltc_cny', '', '1', '0', '1467302022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4708', 'ltc_cny', '', '1', '0', '1467302082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4709', 'ltc_cny', '', '1', '0', '1467302142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4810', 'ltc_cny', '[1467608400,\"45.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\"]', '30', '0', '1467608400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4811', 'btc_cny', '', '1', '0', '1467372692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4812', 'btc_cny', '', '1', '0', '1467372752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4813', 'btc_cny', '', '1', '0', '1467372812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4814', 'btc_cny', '', '1', '0', '1467372872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4815', 'btc_cny', '', '1', '0', '1467372932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4816', 'btc_cny', '', '1', '0', '1467372992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4817', 'btc_cny', '', '1', '0', '1467373052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4818', 'btc_cny', '', '1', '0', '1467373112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4819', 'btc_cny', '', '1', '0', '1467373172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4820', 'btc_cny', '', '1', '0', '1467373232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4821', 'btc_cny', '', '1', '0', '1467373292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4822', 'btc_cny', '', '1', '0', '1467373352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4823', 'btc_cny', '', '1', '0', '1467373412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4824', 'btc_cny', '', '1', '0', '1467373472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4825', 'btc_cny', '', '1', '0', '1467373532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4826', 'btc_cny', '', '1', '0', '1467373592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4827', 'btc_cny', '', '1', '0', '1467373652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4828', 'btc_cny', '', '1', '0', '1467373712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4829', 'btc_cny', '', '1', '0', '1467373772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4830', 'btc_cny', '', '1', '0', '1467373832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4831', 'btc_cny', '', '1', '0', '1467373892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4916', 'ltc_cny', '', '1', '0', '1467302142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4917', 'ltc_cny', '', '1', '0', '1467302202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4918', 'ltc_cny', '', '1', '0', '1467302262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4919', 'ltc_cny', '', '1', '0', '1467302322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4920', 'ltc_cny', '', '1', '0', '1467302382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4921', 'ltc_cny', '', '1', '0', '1467302442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4922', 'ltc_cny', '', '1', '0', '1467302502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4923', 'ltc_cny', '', '1', '0', '1467302562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4924', 'ltc_cny', '', '1', '0', '1467302622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4925', 'ltc_cny', '', '1', '0', '1467302682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4926', 'ltc_cny', '', '1', '0', '1467302742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4927', 'ltc_cny', '', '1', '0', '1467302802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4928', 'ltc_cny', '', '1', '0', '1467302862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4929', 'ltc_cny', '', '1', '0', '1467302922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4930', 'ltc_cny', '', '1', '0', '1467302982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4931', 'ltc_cny', '', '1', '0', '1467303042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4932', 'ltc_cny', '', '1', '0', '1467303102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4933', 'ltc_cny', '', '1', '0', '1467303162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4934', 'ltc_cny', '', '1', '0', '1467303222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4935', 'ltc_cny', '', '1', '0', '1467303282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('4936', 'ltc_cny', '', '1', '0', '1467303342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5021', 'btc_cny', '', '1', '0', '1467373892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5022', 'btc_cny', '', '1', '0', '1467373952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5023', 'btc_cny', '', '1', '0', '1467374012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5024', 'btc_cny', '', '1', '0', '1467374072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5025', 'btc_cny', '', '1', '0', '1467374132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5026', 'btc_cny', '', '1', '0', '1467374192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5027', 'btc_cny', '', '1', '0', '1467374252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5028', 'btc_cny', '', '1', '0', '1467374312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5029', 'btc_cny', '', '1', '0', '1467374372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5030', 'btc_cny', '', '1', '0', '1467374432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5031', 'btc_cny', '', '1', '0', '1467374492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5032', 'btc_cny', '', '1', '0', '1467374552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5033', 'btc_cny', '', '1', '0', '1467374612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5034', 'btc_cny', '', '1', '0', '1467374672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5035', 'btc_cny', '', '1', '0', '1467374732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5036', 'btc_cny', '', '1', '0', '1467374792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5037', 'btc_cny', '', '1', '0', '1467374852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5038', 'btc_cny', '', '1', '0', '1467374912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5039', 'btc_cny', '', '1', '0', '1467374972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5040', 'btc_cny', '', '1', '0', '1467375032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5041', 'btc_cny', '', '1', '0', '1467375092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5126', 'ltc_cny', '', '1', '0', '1467303342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5127', 'ltc_cny', '', '1', '0', '1467303402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5128', 'ltc_cny', '', '1', '0', '1467303462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5129', 'ltc_cny', '', '1', '0', '1467303522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5130', 'ltc_cny', '', '1', '0', '1467303582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5131', 'ltc_cny', '', '1', '0', '1467303642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5132', 'ltc_cny', '', '1', '0', '1467303702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5133', 'ltc_cny', '', '1', '0', '1467303762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5134', 'ltc_cny', '', '1', '0', '1467303822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5135', 'ltc_cny', '', '1', '0', '1467303882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5136', 'ltc_cny', '', '1', '0', '1467303942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5137', 'ltc_cny', '', '1', '0', '1467304002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5138', 'ltc_cny', '', '1', '0', '1467304062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5139', 'ltc_cny', '', '1', '0', '1467304122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5140', 'ltc_cny', '', '1', '0', '1467304182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5141', 'ltc_cny', '', '1', '0', '1467304242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5142', 'ltc_cny', '', '1', '0', '1467304302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5143', 'ltc_cny', '', '1', '0', '1467304362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5144', 'ltc_cny', '', '1', '0', '1467304422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5145', 'ltc_cny', '', '1', '0', '1467304482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5146', 'ltc_cny', '', '1', '0', '1467304542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5231', 'btc_cny', '', '1', '0', '1467375092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5232', 'btc_cny', '', '1', '0', '1467375152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5233', 'btc_cny', '', '1', '0', '1467375212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5234', 'btc_cny', '', '1', '0', '1467375272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5235', 'btc_cny', '', '1', '0', '1467375332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5236', 'btc_cny', '', '1', '0', '1467375392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5237', 'btc_cny', '', '1', '0', '1467375452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5238', 'btc_cny', '', '1', '0', '1467375512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5239', 'btc_cny', '', '1', '0', '1467375572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5240', 'btc_cny', '', '1', '0', '1467375632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5241', 'btc_cny', '', '1', '0', '1467375692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5242', 'btc_cny', '', '1', '0', '1467375752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5243', 'btc_cny', '', '1', '0', '1467375812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5244', 'btc_cny', '', '1', '0', '1467375872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5245', 'btc_cny', '', '1', '0', '1467375932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5246', 'btc_cny', '', '1', '0', '1467375992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5247', 'btc_cny', '', '1', '0', '1467376052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5248', 'btc_cny', '', '1', '0', '1467376112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5249', 'btc_cny', '', '1', '0', '1467376172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5250', 'btc_cny', '', '1', '0', '1467376232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5251', 'btc_cny', '', '1', '0', '1467376292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5336', 'ltc_cny', '', '1', '0', '1467304542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5337', 'ltc_cny', '', '1', '0', '1467304602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5338', 'ltc_cny', '', '1', '0', '1467304662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5339', 'ltc_cny', '', '1', '0', '1467304722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5340', 'ltc_cny', '', '1', '0', '1467304782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5341', 'ltc_cny', '', '1', '0', '1467304842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5342', 'ltc_cny', '', '1', '0', '1467304902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5343', 'ltc_cny', '', '1', '0', '1467304962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5344', 'ltc_cny', '', '1', '0', '1467305022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5345', 'ltc_cny', '', '1', '0', '1467305082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5346', 'ltc_cny', '', '1', '0', '1467305142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5347', 'ltc_cny', '', '1', '0', '1467305202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5348', 'ltc_cny', '', '1', '0', '1467305262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5349', 'ltc_cny', '', '1', '0', '1467305322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5350', 'ltc_cny', '', '1', '0', '1467305382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5351', 'ltc_cny', '', '1', '0', '1467305442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5352', 'ltc_cny', '', '1', '0', '1467305502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5353', 'ltc_cny', '', '1', '0', '1467305562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5354', 'ltc_cny', '', '1', '0', '1467305622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5355', 'ltc_cny', '', '1', '0', '1467305682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5356', 'ltc_cny', '', '1', '0', '1467305742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5441', 'btc_cny', '', '1', '0', '1467376292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5442', 'btc_cny', '', '1', '0', '1467376352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5443', 'btc_cny', '', '1', '0', '1467376412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5444', 'btc_cny', '', '1', '0', '1467376472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5445', 'btc_cny', '', '1', '0', '1467376532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5446', 'btc_cny', '', '1', '0', '1467376592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5447', 'btc_cny', '', '1', '0', '1467376652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5448', 'btc_cny', '', '1', '0', '1467376712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5449', 'btc_cny', '', '1', '0', '1467376772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5450', 'btc_cny', '', '1', '0', '1467376832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5451', 'btc_cny', '', '1', '0', '1467376892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5452', 'btc_cny', '', '1', '0', '1467376952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5453', 'btc_cny', '', '1', '0', '1467377012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5454', 'btc_cny', '', '1', '0', '1467377072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5455', 'btc_cny', '', '1', '0', '1467377132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5456', 'btc_cny', '', '1', '0', '1467377192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5457', 'btc_cny', '', '1', '0', '1467377252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5458', 'btc_cny', '', '1', '0', '1467377312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5459', 'btc_cny', '', '1', '0', '1467377372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5460', 'btc_cny', '', '1', '0', '1467377432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5461', 'btc_cny', '', '1', '0', '1467377492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5546', 'ltc_cny', '', '1', '0', '1467305742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5547', 'ltc_cny', '', '1', '0', '1467305802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5548', 'ltc_cny', '', '1', '0', '1467305862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5549', 'ltc_cny', '', '1', '0', '1467305922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5550', 'ltc_cny', '', '1', '0', '1467305982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5551', 'ltc_cny', '', '1', '0', '1467306042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5552', 'ltc_cny', '', '1', '0', '1467306102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5553', 'ltc_cny', '', '1', '0', '1467306162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5554', 'ltc_cny', '', '1', '0', '1467306222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5555', 'ltc_cny', '', '1', '0', '1467306282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5556', 'ltc_cny', '', '1', '0', '1467306342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5557', 'ltc_cny', '', '1', '0', '1467306402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5558', 'ltc_cny', '', '1', '0', '1467306462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5559', 'ltc_cny', '', '1', '0', '1467306522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5560', 'ltc_cny', '', '1', '0', '1467306582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5561', 'ltc_cny', '', '1', '0', '1467306642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5562', 'ltc_cny', '', '1', '0', '1467306702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5563', 'ltc_cny', '', '1', '0', '1467306762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5564', 'ltc_cny', '', '1', '0', '1467306822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5565', 'ltc_cny', '', '1', '0', '1467306882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5566', 'ltc_cny', '', '1', '0', '1467306942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5651', 'btc_cny', '', '1', '0', '1467377492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5652', 'btc_cny', '', '1', '0', '1467377552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5653', 'btc_cny', '', '1', '0', '1467377612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5654', 'btc_cny', '', '1', '0', '1467377672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5655', 'btc_cny', '', '1', '0', '1467377732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5656', 'btc_cny', '', '1', '0', '1467377792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5657', 'btc_cny', '', '1', '0', '1467377852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5658', 'btc_cny', '', '1', '0', '1467377912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5659', 'btc_cny', '', '1', '0', '1467377972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5660', 'btc_cny', '', '1', '0', '1467378032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5661', 'btc_cny', '', '1', '0', '1467378092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5662', 'btc_cny', '', '1', '0', '1467378152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5663', 'btc_cny', '', '1', '0', '1467378212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5664', 'btc_cny', '', '1', '0', '1467378272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5665', 'btc_cny', '', '1', '0', '1467378332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5666', 'btc_cny', '', '1', '0', '1467378392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5667', 'btc_cny', '', '1', '0', '1467378452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5668', 'btc_cny', '', '1', '0', '1467378512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5669', 'btc_cny', '', '1', '0', '1467378572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5670', 'btc_cny', '', '1', '0', '1467378632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5671', 'btc_cny', '', '1', '0', '1467378692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5750', 'btc_cny', '[1467608400,\"22.10000000\",\"4400.00000000\",\"4599.00000000\",\"4400.00000000\",\"4599.00000000\"]', '15', '0', '1467608400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5751', 'btc_cny', '', '15', '0', '1467609300', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5752', 'ltc_cny', '', '1', '0', '1467306942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5753', 'ltc_cny', '', '1', '0', '1467307002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5754', 'ltc_cny', '', '1', '0', '1467307062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5755', 'ltc_cny', '', '1', '0', '1467307122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5756', 'ltc_cny', '', '1', '0', '1467307182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5757', 'ltc_cny', '', '1', '0', '1467307242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5758', 'ltc_cny', '', '1', '0', '1467307302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5759', 'ltc_cny', '', '1', '0', '1467307362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5760', 'ltc_cny', '', '1', '0', '1467307422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5761', 'ltc_cny', '', '1', '0', '1467307482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5762', 'ltc_cny', '', '1', '0', '1467307542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5763', 'ltc_cny', '', '1', '0', '1467307602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5764', 'ltc_cny', '', '1', '0', '1467307662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5765', 'ltc_cny', '', '1', '0', '1467307722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5766', 'ltc_cny', '', '1', '0', '1467307782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5767', 'ltc_cny', '', '1', '0', '1467307842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5768', 'ltc_cny', '', '1', '0', '1467307902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5769', 'ltc_cny', '', '1', '0', '1467307962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5770', 'ltc_cny', '', '1', '0', '1467308022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5771', 'ltc_cny', '', '1', '0', '1467308082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5772', 'ltc_cny', '', '1', '0', '1467308142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5857', 'btc_cny', '', '1', '0', '1467378692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5858', 'btc_cny', '', '1', '0', '1467378752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5859', 'btc_cny', '', '1', '0', '1467378812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5860', 'btc_cny', '', '1', '0', '1467378872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5861', 'btc_cny', '', '1', '0', '1467378932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5862', 'btc_cny', '', '1', '0', '1467378992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5863', 'btc_cny', '', '1', '0', '1467379052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5864', 'btc_cny', '', '1', '0', '1467379112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5865', 'btc_cny', '', '1', '0', '1467379172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5866', 'btc_cny', '', '1', '0', '1467379232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5867', 'btc_cny', '', '1', '0', '1467379292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5868', 'btc_cny', '', '1', '0', '1467379352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5869', 'btc_cny', '', '1', '0', '1467379412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5870', 'btc_cny', '', '1', '0', '1467379472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5871', 'btc_cny', '', '1', '0', '1467379532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5872', 'btc_cny', '', '1', '0', '1467379592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5873', 'btc_cny', '', '1', '0', '1467379652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5874', 'btc_cny', '', '1', '0', '1467379712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5875', 'btc_cny', '', '1', '0', '1467379772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5876', 'btc_cny', '', '1', '0', '1467379832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5877', 'btc_cny', '', '1', '0', '1467379892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5941', 'ltc_cny', '', '1', '0', '1467308142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5942', 'ltc_cny', '', '1', '0', '1467308202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5943', 'ltc_cny', '', '1', '0', '1467308262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5944', 'ltc_cny', '', '1', '0', '1467308322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5945', 'ltc_cny', '', '1', '0', '1467308382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5946', 'ltc_cny', '', '1', '0', '1467308442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5947', 'ltc_cny', '', '1', '0', '1467308502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5948', 'ltc_cny', '', '1', '0', '1467308562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5949', 'ltc_cny', '', '1', '0', '1467308622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5950', 'ltc_cny', '', '1', '0', '1467308682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5951', 'ltc_cny', '', '1', '0', '1467308742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5952', 'ltc_cny', '', '1', '0', '1467308802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5953', 'ltc_cny', '', '1', '0', '1467308862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5954', 'ltc_cny', '', '1', '0', '1467308922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5955', 'ltc_cny', '', '1', '0', '1467308982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5956', 'ltc_cny', '', '1', '0', '1467309042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5957', 'ltc_cny', '', '1', '0', '1467309102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5958', 'ltc_cny', '', '1', '0', '1467309162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5959', 'ltc_cny', '', '1', '0', '1467309222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5960', 'ltc_cny', '', '1', '0', '1467309282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('5961', 'ltc_cny', '', '1', '0', '1467309342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6046', 'btc_cny', '', '1', '0', '1467379892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6047', 'btc_cny', '', '1', '0', '1467379952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6048', 'btc_cny', '', '1', '0', '1467380012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6049', 'btc_cny', '', '1', '0', '1467380072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6050', 'btc_cny', '', '1', '0', '1467380132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6051', 'btc_cny', '', '1', '0', '1467380192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6052', 'btc_cny', '', '1', '0', '1467380252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6053', 'btc_cny', '', '1', '0', '1467380312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6054', 'btc_cny', '', '1', '0', '1467380372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6055', 'btc_cny', '', '1', '0', '1467380432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6056', 'btc_cny', '', '1', '0', '1467380492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6057', 'btc_cny', '', '1', '0', '1467380552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6058', 'btc_cny', '', '1', '0', '1467380612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6059', 'btc_cny', '', '1', '0', '1467380672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6060', 'btc_cny', '', '1', '0', '1467380732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6061', 'btc_cny', '', '1', '0', '1467380792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6062', 'btc_cny', '', '1', '0', '1467380852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6063', 'btc_cny', '', '1', '0', '1467380912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6064', 'btc_cny', '', '1', '0', '1467380972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6065', 'btc_cny', '', '1', '0', '1467381032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6066', 'btc_cny', '', '1', '0', '1467381092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6130', 'ltc_cny', '', '1', '0', '1467309342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6131', 'ltc_cny', '', '1', '0', '1467309402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6132', 'ltc_cny', '', '1', '0', '1467309462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6133', 'ltc_cny', '', '1', '0', '1467309522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6134', 'ltc_cny', '', '1', '0', '1467309582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6135', 'ltc_cny', '', '1', '0', '1467309642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6136', 'ltc_cny', '', '1', '0', '1467309702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6137', 'ltc_cny', '', '1', '0', '1467309762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6138', 'ltc_cny', '', '1', '0', '1467309822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6139', 'ltc_cny', '', '1', '0', '1467309882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6140', 'ltc_cny', '', '1', '0', '1467309942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6141', 'ltc_cny', '', '1', '0', '1467310002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6142', 'ltc_cny', '', '1', '0', '1467310062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6143', 'ltc_cny', '', '1', '0', '1467310122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6144', 'ltc_cny', '', '1', '0', '1467310182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6145', 'ltc_cny', '', '1', '0', '1467310242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6146', 'ltc_cny', '', '1', '0', '1467310302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6147', 'ltc_cny', '', '1', '0', '1467310362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6148', 'ltc_cny', '', '1', '0', '1467310422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6149', 'ltc_cny', '', '1', '0', '1467310482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6150', 'ltc_cny', '', '1', '0', '1467310542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6235', 'btc_cny', '', '1', '0', '1467381092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6236', 'btc_cny', '', '1', '0', '1467381152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6237', 'btc_cny', '', '1', '0', '1467381212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6238', 'btc_cny', '', '1', '0', '1467381272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6239', 'btc_cny', '', '1', '0', '1467381332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6240', 'btc_cny', '', '1', '0', '1467381392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6241', 'btc_cny', '', '1', '0', '1467381452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6242', 'btc_cny', '', '1', '0', '1467381512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6243', 'btc_cny', '', '1', '0', '1467381572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6244', 'btc_cny', '', '1', '0', '1467381632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6245', 'btc_cny', '', '1', '0', '1467381692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6246', 'btc_cny', '', '1', '0', '1467381752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6247', 'btc_cny', '', '1', '0', '1467381812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6248', 'btc_cny', '', '1', '0', '1467381872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6249', 'btc_cny', '', '1', '0', '1467381932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6250', 'btc_cny', '', '1', '0', '1467381992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6251', 'btc_cny', '', '1', '0', '1467382052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6252', 'btc_cny', '', '1', '0', '1467382112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6253', 'btc_cny', '', '1', '0', '1467382172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6254', 'btc_cny', '', '1', '0', '1467382232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6255', 'btc_cny', '', '1', '0', '1467382292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6319', 'ltc_cny', '', '1', '0', '1467310542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6320', 'ltc_cny', '', '1', '0', '1467310602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6321', 'ltc_cny', '', '1', '0', '1467310662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6322', 'ltc_cny', '', '1', '0', '1467310722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6323', 'ltc_cny', '', '1', '0', '1467310782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6324', 'ltc_cny', '', '1', '0', '1467310842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6325', 'ltc_cny', '', '1', '0', '1467310902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6326', 'ltc_cny', '', '1', '0', '1467310962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6327', 'ltc_cny', '', '1', '0', '1467311022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6328', 'ltc_cny', '', '1', '0', '1467311082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6329', 'ltc_cny', '', '1', '0', '1467311142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6330', 'ltc_cny', '', '1', '0', '1467311202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6331', 'ltc_cny', '', '1', '0', '1467311262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6332', 'ltc_cny', '', '1', '0', '1467311322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6333', 'ltc_cny', '', '1', '0', '1467311382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6334', 'ltc_cny', '', '1', '0', '1467311442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6335', 'ltc_cny', '', '1', '0', '1467311502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6336', 'ltc_cny', '', '1', '0', '1467311562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6337', 'ltc_cny', '', '1', '0', '1467311622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6338', 'ltc_cny', '', '1', '0', '1467311682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6339', 'ltc_cny', '', '1', '0', '1467311742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6424', 'btc_cny', '', '1', '0', '1467382292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6425', 'btc_cny', '', '1', '0', '1467382352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6426', 'btc_cny', '', '1', '0', '1467382412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6427', 'btc_cny', '', '1', '0', '1467382472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6428', 'btc_cny', '', '1', '0', '1467382532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6429', 'btc_cny', '', '1', '0', '1467382592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6430', 'btc_cny', '', '1', '0', '1467382652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6431', 'btc_cny', '', '1', '0', '1467382712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6432', 'btc_cny', '', '1', '0', '1467382772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6433', 'btc_cny', '', '1', '0', '1467382832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6434', 'btc_cny', '', '1', '0', '1467382892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6435', 'btc_cny', '', '1', '0', '1467382952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6436', 'btc_cny', '', '1', '0', '1467383012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6437', 'btc_cny', '', '1', '0', '1467383072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6438', 'btc_cny', '', '1', '0', '1467383132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6439', 'btc_cny', '', '1', '0', '1467383192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6440', 'btc_cny', '', '1', '0', '1467383252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6441', 'btc_cny', '', '1', '0', '1467383312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6442', 'btc_cny', '', '1', '0', '1467383372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6443', 'btc_cny', '', '1', '0', '1467383432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6444', 'btc_cny', '', '1', '0', '1467383492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6508', 'ltc_cny', '', '1', '0', '1467311742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6509', 'ltc_cny', '', '1', '0', '1467311802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6510', 'ltc_cny', '', '1', '0', '1467311862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6511', 'ltc_cny', '', '1', '0', '1467311922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6512', 'ltc_cny', '', '1', '0', '1467311982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6513', 'ltc_cny', '', '1', '0', '1467312042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6514', 'ltc_cny', '', '1', '0', '1467312102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6515', 'ltc_cny', '', '1', '0', '1467312162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6516', 'ltc_cny', '', '1', '0', '1467312222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6517', 'ltc_cny', '', '1', '0', '1467312282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6518', 'ltc_cny', '', '1', '0', '1467312342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6519', 'ltc_cny', '', '1', '0', '1467312402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6520', 'ltc_cny', '', '1', '0', '1467312462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6521', 'ltc_cny', '', '1', '0', '1467312522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6522', 'ltc_cny', '', '1', '0', '1467312582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6523', 'ltc_cny', '', '1', '0', '1467312642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6524', 'ltc_cny', '', '1', '0', '1467312702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6525', 'ltc_cny', '', '1', '0', '1467312762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6526', 'ltc_cny', '', '1', '0', '1467312822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6527', 'ltc_cny', '', '1', '0', '1467312882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6528', 'ltc_cny', '', '1', '0', '1467312942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6604', 'ltc_cny', '[1467608400,\"45.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\"]', '15', '0', '1467608400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6605', 'ltc_cny', '', '15', '0', '1467609300', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6606', 'btc_cny', '', '1', '0', '1467383492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6607', 'btc_cny', '', '1', '0', '1467383552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6608', 'btc_cny', '', '1', '0', '1467383612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6609', 'btc_cny', '', '1', '0', '1467383672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6610', 'btc_cny', '', '1', '0', '1467383732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6611', 'btc_cny', '', '1', '0', '1467383792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6612', 'btc_cny', '', '1', '0', '1467383852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6613', 'btc_cny', '', '1', '0', '1467383912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6614', 'btc_cny', '', '1', '0', '1467383972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6615', 'btc_cny', '', '1', '0', '1467384032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6616', 'btc_cny', '', '1', '0', '1467384092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6617', 'btc_cny', '', '1', '0', '1467384152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6618', 'btc_cny', '', '1', '0', '1467384212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6619', 'btc_cny', '', '1', '0', '1467384272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6620', 'btc_cny', '', '1', '0', '1467384332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6621', 'btc_cny', '', '1', '0', '1467384392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6622', 'btc_cny', '', '1', '0', '1467384452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6623', 'btc_cny', '', '1', '0', '1467384512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6624', 'btc_cny', '', '1', '0', '1467384572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6625', 'btc_cny', '', '1', '0', '1467384632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6626', 'btc_cny', '', '1', '0', '1467384692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6690', 'ltc_cny', '', '1', '0', '1467312942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6691', 'ltc_cny', '', '1', '0', '1467313002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6692', 'ltc_cny', '', '1', '0', '1467313062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6693', 'ltc_cny', '', '1', '0', '1467313122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6694', 'ltc_cny', '', '1', '0', '1467313182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6695', 'ltc_cny', '', '1', '0', '1467313242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6696', 'ltc_cny', '', '1', '0', '1467313302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6697', 'ltc_cny', '', '1', '0', '1467313362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6698', 'ltc_cny', '', '1', '0', '1467313422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6699', 'ltc_cny', '', '1', '0', '1467313482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6700', 'ltc_cny', '', '1', '0', '1467313542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6701', 'ltc_cny', '', '1', '0', '1467313602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6702', 'ltc_cny', '', '1', '0', '1467313662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6703', 'ltc_cny', '', '1', '0', '1467313722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6704', 'ltc_cny', '', '1', '0', '1467313782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6705', 'ltc_cny', '', '1', '0', '1467313842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6706', 'ltc_cny', '', '1', '0', '1467313902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6707', 'ltc_cny', '', '1', '0', '1467313962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6708', 'ltc_cny', '', '1', '0', '1467314022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6709', 'ltc_cny', '', '1', '0', '1467314082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6710', 'ltc_cny', '', '1', '0', '1467314142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6774', 'btc_cny', '', '1', '0', '1467384692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6775', 'btc_cny', '', '1', '0', '1467384752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6776', 'btc_cny', '', '1', '0', '1467384812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6777', 'btc_cny', '', '1', '0', '1467384872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6778', 'btc_cny', '', '1', '0', '1467384932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6779', 'btc_cny', '', '1', '0', '1467384992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6780', 'btc_cny', '', '1', '0', '1467385052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6781', 'btc_cny', '', '1', '0', '1467385112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6782', 'btc_cny', '', '1', '0', '1467385172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6783', 'btc_cny', '', '1', '0', '1467385232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6784', 'btc_cny', '', '1', '0', '1467385292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6785', 'btc_cny', '', '1', '0', '1467385352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6786', 'btc_cny', '', '1', '0', '1467385412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6787', 'btc_cny', '', '1', '0', '1467385472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6788', 'btc_cny', '', '1', '0', '1467385532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6789', 'btc_cny', '', '1', '0', '1467385592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6790', 'btc_cny', '', '1', '0', '1467385652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6791', 'btc_cny', '', '1', '0', '1467385712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6792', 'btc_cny', '', '1', '0', '1467385772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6793', 'btc_cny', '', '1', '0', '1467385832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6794', 'btc_cny', '', '1', '0', '1467385892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6858', 'ltc_cny', '', '1', '0', '1467314142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6859', 'ltc_cny', '', '1', '0', '1467314202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6860', 'ltc_cny', '', '1', '0', '1467314262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6861', 'ltc_cny', '', '1', '0', '1467314322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6862', 'ltc_cny', '', '1', '0', '1467314382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6863', 'ltc_cny', '', '1', '0', '1467314442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6864', 'ltc_cny', '', '1', '0', '1467314502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6865', 'ltc_cny', '', '1', '0', '1467314562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6866', 'ltc_cny', '', '1', '0', '1467314622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6867', 'ltc_cny', '', '1', '0', '1467314682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6868', 'ltc_cny', '', '1', '0', '1467314742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6869', 'ltc_cny', '', '1', '0', '1467314802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6870', 'ltc_cny', '', '1', '0', '1467314862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6871', 'ltc_cny', '', '1', '0', '1467314922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6872', 'ltc_cny', '', '1', '0', '1467314982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6873', 'ltc_cny', '', '1', '0', '1467315042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6874', 'ltc_cny', '', '1', '0', '1467315102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6875', 'ltc_cny', '', '1', '0', '1467315162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6876', 'ltc_cny', '', '1', '0', '1467315222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6877', 'ltc_cny', '', '1', '0', '1467315282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6878', 'ltc_cny', '', '1', '0', '1467315342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6942', 'btc_cny', '', '1', '0', '1467385892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6943', 'btc_cny', '', '1', '0', '1467385952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6944', 'btc_cny', '', '1', '0', '1467386012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6945', 'btc_cny', '', '1', '0', '1467386072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6946', 'btc_cny', '', '1', '0', '1467386132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6947', 'btc_cny', '', '1', '0', '1467386192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6948', 'btc_cny', '', '1', '0', '1467386252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6949', 'btc_cny', '', '1', '0', '1467386312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6950', 'btc_cny', '', '1', '0', '1467386372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6951', 'btc_cny', '', '1', '0', '1467386432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6952', 'btc_cny', '', '1', '0', '1467386492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6953', 'btc_cny', '', '1', '0', '1467386552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6954', 'btc_cny', '', '1', '0', '1467386612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6955', 'btc_cny', '', '1', '0', '1467386672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6956', 'btc_cny', '', '1', '0', '1467386732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6957', 'btc_cny', '', '1', '0', '1467386792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6958', 'btc_cny', '', '1', '0', '1467386852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6959', 'btc_cny', '', '1', '0', '1467386912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6960', 'btc_cny', '', '1', '0', '1467386972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6961', 'btc_cny', '', '1', '0', '1467387032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('6962', 'btc_cny', '', '1', '0', '1467387092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7017', 'btc_cny', '[1467608400,\"22.10000000\",\"4400.00000000\",\"4599.00000000\",\"4400.00000000\",\"4599.00000000\"]', '10', '0', '1467608400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7018', 'btc_cny', '', '10', '0', '1467609000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7019', 'btc_cny', '', '10', '0', '1467609600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7020', 'ltc_cny', '', '1', '0', '1467315342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7021', 'ltc_cny', '', '1', '0', '1467315402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7022', 'ltc_cny', '', '1', '0', '1467315462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7023', 'ltc_cny', '', '1', '0', '1467315522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7024', 'ltc_cny', '', '1', '0', '1467315582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7025', 'ltc_cny', '', '1', '0', '1467315642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7026', 'ltc_cny', '', '1', '0', '1467315702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7027', 'ltc_cny', '', '1', '0', '1467315762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7028', 'ltc_cny', '', '1', '0', '1467315822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7029', 'ltc_cny', '', '1', '0', '1467315882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7030', 'ltc_cny', '', '1', '0', '1467315942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7031', 'ltc_cny', '', '1', '0', '1467316002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7032', 'ltc_cny', '', '1', '0', '1467316062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7033', 'ltc_cny', '', '1', '0', '1467316122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7034', 'ltc_cny', '', '1', '0', '1467316182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7035', 'ltc_cny', '', '1', '0', '1467316242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7036', 'ltc_cny', '', '1', '0', '1467316302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7037', 'ltc_cny', '', '1', '0', '1467316362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7038', 'ltc_cny', '', '1', '0', '1467316422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7039', 'ltc_cny', '', '1', '0', '1467316482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7040', 'ltc_cny', '', '1', '0', '1467316542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7104', 'btc_cny', '', '1', '0', '1467387092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7105', 'btc_cny', '', '1', '0', '1467387152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7106', 'btc_cny', '', '1', '0', '1467387212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7107', 'btc_cny', '', '1', '0', '1467387272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7108', 'btc_cny', '', '1', '0', '1467387332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7109', 'btc_cny', '', '1', '0', '1467387392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7110', 'btc_cny', '', '1', '0', '1467387452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7111', 'btc_cny', '', '1', '0', '1467387512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7112', 'btc_cny', '', '1', '0', '1467387572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7113', 'btc_cny', '', '1', '0', '1467387632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7114', 'btc_cny', '', '1', '0', '1467387692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7115', 'btc_cny', '', '1', '0', '1467387752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7116', 'btc_cny', '', '1', '0', '1467387812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7117', 'btc_cny', '', '1', '0', '1467387872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7118', 'btc_cny', '', '1', '0', '1467387932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7119', 'btc_cny', '', '1', '0', '1467387992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7120', 'btc_cny', '', '1', '0', '1467388052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7121', 'btc_cny', '', '1', '0', '1467388112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7122', 'btc_cny', '', '1', '0', '1467388172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7123', 'btc_cny', '', '1', '0', '1467388232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7124', 'btc_cny', '', '1', '0', '1467388292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7167', 'btc_cny', '', '30', '0', '1467610200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7168', 'ltc_cny', '', '1', '0', '1467316542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7169', 'ltc_cny', '', '1', '0', '1467316602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7170', 'ltc_cny', '', '1', '0', '1467316662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7171', 'ltc_cny', '', '1', '0', '1467316722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7172', 'ltc_cny', '', '1', '0', '1467316782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7173', 'ltc_cny', '', '1', '0', '1467316842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7174', 'ltc_cny', '', '1', '0', '1467316902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7175', 'ltc_cny', '', '1', '0', '1467316962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7176', 'ltc_cny', '', '1', '0', '1467317022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7177', 'ltc_cny', '', '1', '0', '1467317082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7178', 'ltc_cny', '', '1', '0', '1467317142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7179', 'ltc_cny', '', '1', '0', '1467317202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7180', 'ltc_cny', '', '1', '0', '1467317262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7181', 'ltc_cny', '', '1', '0', '1467317322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7182', 'ltc_cny', '', '1', '0', '1467317382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7183', 'ltc_cny', '', '1', '0', '1467317442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7184', 'ltc_cny', '', '1', '0', '1467317502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7185', 'ltc_cny', '', '1', '0', '1467317562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7186', 'ltc_cny', '', '1', '0', '1467317622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7187', 'ltc_cny', '', '1', '0', '1467317682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7188', 'ltc_cny', '', '1', '0', '1467317742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7252', 'ltc_cny', '', '30', '0', '1467610200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7253', 'btc_cny', '', '1', '0', '1467388292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7254', 'btc_cny', '', '1', '0', '1467388352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7255', 'btc_cny', '', '1', '0', '1467388412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7256', 'btc_cny', '', '1', '0', '1467388472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7257', 'btc_cny', '', '1', '0', '1467388532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7258', 'btc_cny', '', '1', '0', '1467388592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7259', 'btc_cny', '', '1', '0', '1467388652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7260', 'btc_cny', '', '1', '0', '1467388712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7261', 'btc_cny', '', '1', '0', '1467388772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7262', 'btc_cny', '', '1', '0', '1467388832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7263', 'btc_cny', '', '1', '0', '1467388892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7264', 'btc_cny', '', '1', '0', '1467388952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7265', 'btc_cny', '', '1', '0', '1467389012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7266', 'btc_cny', '', '1', '0', '1467389072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7267', 'btc_cny', '', '1', '0', '1467389132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7268', 'btc_cny', '', '1', '0', '1467389192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7269', 'btc_cny', '', '1', '0', '1467389252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7270', 'btc_cny', '', '1', '0', '1467389312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7271', 'btc_cny', '', '1', '0', '1467389372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7272', 'btc_cny', '', '1', '0', '1467389432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7273', 'btc_cny', '', '1', '0', '1467389492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7316', 'ltc_cny', '', '1', '0', '1467317742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7317', 'ltc_cny', '', '1', '0', '1467317802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7318', 'ltc_cny', '', '1', '0', '1467317862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7319', 'ltc_cny', '', '1', '0', '1467317922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7320', 'ltc_cny', '', '1', '0', '1467317982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7321', 'ltc_cny', '', '1', '0', '1467318042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7322', 'ltc_cny', '', '1', '0', '1467318102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7323', 'ltc_cny', '', '1', '0', '1467318162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7324', 'ltc_cny', '', '1', '0', '1467318222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7325', 'ltc_cny', '', '1', '0', '1467318282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7326', 'ltc_cny', '', '1', '0', '1467318342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7327', 'ltc_cny', '', '1', '0', '1467318402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7328', 'ltc_cny', '', '1', '0', '1467318462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7329', 'ltc_cny', '', '1', '0', '1467318522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7330', 'ltc_cny', '', '1', '0', '1467318582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7331', 'ltc_cny', '', '1', '0', '1467318642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7332', 'ltc_cny', '', '1', '0', '1467318702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7333', 'ltc_cny', '', '1', '0', '1467318762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7334', 'ltc_cny', '', '1', '0', '1467318822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7335', 'ltc_cny', '', '1', '0', '1467318882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7336', 'ltc_cny', '', '1', '0', '1467318942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7400', 'btc_cny', '', '1', '0', '1467389492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7401', 'btc_cny', '', '1', '0', '1467389552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7402', 'btc_cny', '', '1', '0', '1467389612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7403', 'btc_cny', '', '1', '0', '1467389672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7404', 'btc_cny', '', '1', '0', '1467389732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7405', 'btc_cny', '', '1', '0', '1467389792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7406', 'btc_cny', '', '1', '0', '1467389852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7407', 'btc_cny', '', '1', '0', '1467389912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7408', 'btc_cny', '', '1', '0', '1467389972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7409', 'btc_cny', '', '1', '0', '1467390032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7410', 'btc_cny', '', '1', '0', '1467390092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7411', 'btc_cny', '', '1', '0', '1467390152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7412', 'btc_cny', '', '1', '0', '1467390212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7413', 'btc_cny', '', '1', '0', '1467390272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7414', 'btc_cny', '', '1', '0', '1467390332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7415', 'btc_cny', '', '1', '0', '1467390392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7416', 'btc_cny', '', '1', '0', '1467390452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7417', 'btc_cny', '', '1', '0', '1467390512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7418', 'btc_cny', '', '1', '0', '1467390572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7419', 'btc_cny', '', '1', '0', '1467390632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7420', 'btc_cny', '', '1', '0', '1467390692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7463', 'ltc_cny', '', '1', '0', '1467318942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7464', 'ltc_cny', '', '1', '0', '1467319002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7465', 'ltc_cny', '', '1', '0', '1467319062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7466', 'ltc_cny', '', '1', '0', '1467319122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7467', 'ltc_cny', '', '1', '0', '1467319182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7468', 'ltc_cny', '', '1', '0', '1467319242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7469', 'ltc_cny', '', '1', '0', '1467319302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7470', 'ltc_cny', '', '1', '0', '1467319362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7471', 'ltc_cny', '', '1', '0', '1467319422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7472', 'ltc_cny', '', '1', '0', '1467319482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7473', 'ltc_cny', '', '1', '0', '1467319542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7474', 'ltc_cny', '', '1', '0', '1467319602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7475', 'ltc_cny', '', '1', '0', '1467319662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7476', 'ltc_cny', '', '1', '0', '1467319722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7477', 'ltc_cny', '', '1', '0', '1467319782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7478', 'ltc_cny', '', '1', '0', '1467319842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7479', 'ltc_cny', '', '1', '0', '1467319902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7480', 'ltc_cny', '', '1', '0', '1467319962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7481', 'ltc_cny', '', '1', '0', '1467320022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7482', 'ltc_cny', '', '1', '0', '1467320082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7483', 'ltc_cny', '', '1', '0', '1467320142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7547', 'btc_cny', '', '1', '0', '1467390692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7548', 'btc_cny', '', '1', '0', '1467390752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7549', 'btc_cny', '', '1', '0', '1467390812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7550', 'btc_cny', '', '1', '0', '1467390872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7551', 'btc_cny', '', '1', '0', '1467390932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7552', 'btc_cny', '', '1', '0', '1467390992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7553', 'btc_cny', '', '1', '0', '1467391052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7554', 'btc_cny', '', '1', '0', '1467391112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7555', 'btc_cny', '', '1', '0', '1467391172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7556', 'btc_cny', '', '1', '0', '1467391232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7557', 'btc_cny', '', '1', '0', '1467391292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7558', 'btc_cny', '', '1', '0', '1467391352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7559', 'btc_cny', '', '1', '0', '1467391412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7560', 'btc_cny', '', '1', '0', '1467391472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7561', 'btc_cny', '', '1', '0', '1467391532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7562', 'btc_cny', '', '1', '0', '1467391592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7563', 'btc_cny', '', '1', '0', '1467391652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7564', 'btc_cny', '', '1', '0', '1467391712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7565', 'btc_cny', '', '1', '0', '1467391772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7566', 'btc_cny', '', '1', '0', '1467391832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7567', 'btc_cny', '', '1', '0', '1467391892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7610', 'ltc_cny', '', '1', '0', '1467320142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7611', 'ltc_cny', '', '1', '0', '1467320202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7612', 'ltc_cny', '', '1', '0', '1467320262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7613', 'ltc_cny', '', '1', '0', '1467320322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7614', 'ltc_cny', '', '1', '0', '1467320382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7615', 'ltc_cny', '', '1', '0', '1467320442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7616', 'ltc_cny', '', '1', '0', '1467320502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7617', 'ltc_cny', '', '1', '0', '1467320562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7618', 'ltc_cny', '', '1', '0', '1467320622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7619', 'ltc_cny', '', '1', '0', '1467320682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7620', 'ltc_cny', '', '1', '0', '1467320742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7621', 'ltc_cny', '', '1', '0', '1467320802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7622', 'ltc_cny', '', '1', '0', '1467320862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7623', 'ltc_cny', '', '1', '0', '1467320922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7624', 'ltc_cny', '', '1', '0', '1467320982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7625', 'ltc_cny', '', '1', '0', '1467321042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7626', 'ltc_cny', '', '1', '0', '1467321102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7627', 'ltc_cny', '', '1', '0', '1467321162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7628', 'ltc_cny', '', '1', '0', '1467321222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7629', 'ltc_cny', '', '1', '0', '1467321282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7630', 'ltc_cny', '', '1', '0', '1467321342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7694', 'btc_cny', '', '1', '0', '1467391892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7695', 'btc_cny', '', '1', '0', '1467391952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7696', 'btc_cny', '', '1', '0', '1467392012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7697', 'btc_cny', '', '1', '0', '1467392072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7698', 'btc_cny', '', '1', '0', '1467392132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7699', 'btc_cny', '', '1', '0', '1467392192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7700', 'btc_cny', '', '1', '0', '1467392252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7701', 'btc_cny', '', '1', '0', '1467392312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7702', 'btc_cny', '', '1', '0', '1467392372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7703', 'btc_cny', '', '1', '0', '1467392432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7704', 'btc_cny', '', '1', '0', '1467392492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7705', 'btc_cny', '', '1', '0', '1467392552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7706', 'btc_cny', '', '1', '0', '1467392612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7707', 'btc_cny', '', '1', '0', '1467392672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7708', 'btc_cny', '', '1', '0', '1467392732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7709', 'btc_cny', '', '1', '0', '1467392792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7710', 'btc_cny', '', '1', '0', '1467392852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7711', 'btc_cny', '', '1', '0', '1467392912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7712', 'btc_cny', '', '1', '0', '1467392972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7713', 'btc_cny', '', '1', '0', '1467393032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7714', 'btc_cny', '', '1', '0', '1467393092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7757', 'ltc_cny', '', '1', '0', '1467321342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7758', 'ltc_cny', '', '1', '0', '1467321402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7759', 'ltc_cny', '', '1', '0', '1467321462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7760', 'ltc_cny', '', '1', '0', '1467321522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7761', 'ltc_cny', '', '1', '0', '1467321582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7762', 'ltc_cny', '', '1', '0', '1467321642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7763', 'ltc_cny', '', '1', '0', '1467321702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7764', 'ltc_cny', '', '1', '0', '1467321762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7765', 'ltc_cny', '', '1', '0', '1467321822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7766', 'ltc_cny', '', '1', '0', '1467321882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7767', 'ltc_cny', '', '1', '0', '1467321942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7768', 'ltc_cny', '', '1', '0', '1467322002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7769', 'ltc_cny', '', '1', '0', '1467322062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7770', 'ltc_cny', '', '1', '0', '1467322122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7771', 'ltc_cny', '', '1', '0', '1467322182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7772', 'ltc_cny', '', '1', '0', '1467322242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7773', 'ltc_cny', '', '1', '0', '1467322302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7774', 'ltc_cny', '', '1', '0', '1467322362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7775', 'ltc_cny', '', '1', '0', '1467322422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7776', 'ltc_cny', '', '1', '0', '1467322482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7777', 'ltc_cny', '', '1', '0', '1467322542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7841', 'btc_cny', '', '1', '0', '1467393092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7842', 'btc_cny', '', '1', '0', '1467393152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7843', 'btc_cny', '', '1', '0', '1467393212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7844', 'btc_cny', '', '1', '0', '1467393272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7845', 'btc_cny', '', '1', '0', '1467393332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7846', 'btc_cny', '', '1', '0', '1467393392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7847', 'btc_cny', '', '1', '0', '1467393452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7848', 'btc_cny', '', '1', '0', '1467393512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7849', 'btc_cny', '', '1', '0', '1467393572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7850', 'btc_cny', '', '1', '0', '1467393632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7851', 'btc_cny', '', '1', '0', '1467393692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7852', 'btc_cny', '', '1', '0', '1467393752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7853', 'btc_cny', '', '1', '0', '1467393812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7854', 'btc_cny', '', '1', '0', '1467393872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7855', 'btc_cny', '', '1', '0', '1467393932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7856', 'btc_cny', '', '1', '0', '1467393992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7857', 'btc_cny', '', '1', '0', '1467394052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7858', 'btc_cny', '', '1', '0', '1467394112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7859', 'btc_cny', '', '1', '0', '1467394172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7860', 'btc_cny', '', '1', '0', '1467394232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7861', 'btc_cny', '', '1', '0', '1467394292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7904', 'ltc_cny', '', '1', '0', '1467322542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7905', 'ltc_cny', '', '1', '0', '1467322602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7906', 'ltc_cny', '', '1', '0', '1467322662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7907', 'ltc_cny', '', '1', '0', '1467322722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7908', 'ltc_cny', '', '1', '0', '1467322782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7909', 'ltc_cny', '', '1', '0', '1467322842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7910', 'ltc_cny', '', '1', '0', '1467322902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7911', 'ltc_cny', '', '1', '0', '1467322962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7912', 'ltc_cny', '', '1', '0', '1467323022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7913', 'ltc_cny', '', '1', '0', '1467323082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7914', 'ltc_cny', '', '1', '0', '1467323142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7915', 'ltc_cny', '', '1', '0', '1467323202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7916', 'ltc_cny', '', '1', '0', '1467323262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7917', 'ltc_cny', '', '1', '0', '1467323322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7918', 'ltc_cny', '', '1', '0', '1467323382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7919', 'ltc_cny', '', '1', '0', '1467323442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7920', 'ltc_cny', '', '1', '0', '1467323502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7921', 'ltc_cny', '', '1', '0', '1467323562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7922', 'ltc_cny', '', '1', '0', '1467323622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7923', 'ltc_cny', '', '1', '0', '1467323682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7924', 'ltc_cny', '', '1', '0', '1467323742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7975', 'ltc_cny', '[1467608400,\"45.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\"]', '10', '0', '1467608400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7976', 'ltc_cny', '', '10', '0', '1467609000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7977', 'ltc_cny', '', '10', '0', '1467609600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7978', 'ltc_cny', '', '10', '0', '1467610200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7979', 'btc_cny', '', '1', '0', '1467394292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7980', 'btc_cny', '', '1', '0', '1467394352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7981', 'btc_cny', '', '1', '0', '1467394412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7982', 'btc_cny', '', '1', '0', '1467394472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7983', 'btc_cny', '', '1', '0', '1467394532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7984', 'btc_cny', '', '1', '0', '1467394592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7985', 'btc_cny', '', '1', '0', '1467394652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7986', 'btc_cny', '', '1', '0', '1467394712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7987', 'btc_cny', '', '1', '0', '1467394772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7988', 'btc_cny', '', '1', '0', '1467394832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7989', 'btc_cny', '', '1', '0', '1467394892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7990', 'btc_cny', '', '1', '0', '1467394952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7991', 'btc_cny', '', '1', '0', '1467395012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7992', 'btc_cny', '', '1', '0', '1467395072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7993', 'btc_cny', '', '1', '0', '1467395132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7994', 'btc_cny', '', '1', '0', '1467395192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7995', 'btc_cny', '', '1', '0', '1467395252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7996', 'btc_cny', '', '1', '0', '1467395312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7997', 'btc_cny', '', '1', '0', '1467395372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7998', 'btc_cny', '', '1', '0', '1467395432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('7999', 'btc_cny', '', '1', '0', '1467395492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8042', 'ltc_cny', '', '1', '0', '1467323742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8043', 'ltc_cny', '', '1', '0', '1467323802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8044', 'ltc_cny', '', '1', '0', '1467323862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8045', 'ltc_cny', '', '1', '0', '1467323922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8046', 'ltc_cny', '', '1', '0', '1467323982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8047', 'ltc_cny', '', '1', '0', '1467324042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8048', 'ltc_cny', '', '1', '0', '1467324102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8049', 'ltc_cny', '', '1', '0', '1467324162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8050', 'ltc_cny', '', '1', '0', '1467324222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8051', 'ltc_cny', '', '1', '0', '1467324282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8052', 'ltc_cny', '', '1', '0', '1467324342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8053', 'ltc_cny', '', '1', '0', '1467324402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8054', 'ltc_cny', '', '1', '0', '1467324462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8055', 'ltc_cny', '', '1', '0', '1467324522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8056', 'ltc_cny', '', '1', '0', '1467324582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8057', 'ltc_cny', '', '1', '0', '1467324642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8058', 'ltc_cny', '', '1', '0', '1467324702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8059', 'ltc_cny', '', '1', '0', '1467324762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8060', 'ltc_cny', '', '1', '0', '1467324822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8061', 'ltc_cny', '', '1', '0', '1467324882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8062', 'ltc_cny', '', '1', '0', '1467324942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8105', 'btc_cny', '', '1', '0', '1467395492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8106', 'btc_cny', '', '1', '0', '1467395552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8107', 'btc_cny', '', '1', '0', '1467395612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8108', 'btc_cny', '', '1', '0', '1467395672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8109', 'btc_cny', '', '1', '0', '1467395732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8110', 'btc_cny', '', '1', '0', '1467395792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8111', 'btc_cny', '', '1', '0', '1467395852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8112', 'btc_cny', '', '1', '0', '1467395912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8113', 'btc_cny', '', '1', '0', '1467395972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8114', 'btc_cny', '', '1', '0', '1467396032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8115', 'btc_cny', '', '1', '0', '1467396092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8116', 'btc_cny', '', '1', '0', '1467396152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8117', 'btc_cny', '', '1', '0', '1467396212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8118', 'btc_cny', '', '1', '0', '1467396272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8119', 'btc_cny', '', '1', '0', '1467396332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8120', 'btc_cny', '', '1', '0', '1467396392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8121', 'btc_cny', '', '1', '0', '1467396452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8122', 'btc_cny', '', '1', '0', '1467396512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8123', 'btc_cny', '', '1', '0', '1467396572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8124', 'btc_cny', '', '1', '0', '1467396632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8125', 'btc_cny', '', '1', '0', '1467396692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8168', 'ltc_cny', '', '1', '0', '1467324942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8169', 'ltc_cny', '', '1', '0', '1467325002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8170', 'ltc_cny', '', '1', '0', '1467325062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8171', 'ltc_cny', '', '1', '0', '1467325122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8172', 'ltc_cny', '', '1', '0', '1467325182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8173', 'ltc_cny', '', '1', '0', '1467325242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8174', 'ltc_cny', '', '1', '0', '1467325302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8175', 'ltc_cny', '', '1', '0', '1467325362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8176', 'ltc_cny', '', '1', '0', '1467325422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8177', 'ltc_cny', '', '1', '0', '1467325482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8178', 'ltc_cny', '', '1', '0', '1467325542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8179', 'ltc_cny', '', '1', '0', '1467325602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8180', 'ltc_cny', '', '1', '0', '1467325662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8181', 'ltc_cny', '', '1', '0', '1467325722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8182', 'ltc_cny', '', '1', '0', '1467325782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8183', 'ltc_cny', '', '1', '0', '1467325842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8184', 'ltc_cny', '', '1', '0', '1467325902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8185', 'ltc_cny', '', '1', '0', '1467325962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8186', 'ltc_cny', '', '1', '0', '1467326022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8187', 'ltc_cny', '', '1', '0', '1467326082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8188', 'ltc_cny', '', '1', '0', '1467326142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8231', 'btc_cny', '', '1', '0', '1467396692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8232', 'btc_cny', '', '1', '0', '1467396752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8233', 'btc_cny', '', '1', '0', '1467396812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8234', 'btc_cny', '', '1', '0', '1467396872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8235', 'btc_cny', '', '1', '0', '1467396932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8236', 'btc_cny', '', '1', '0', '1467396992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8237', 'btc_cny', '', '1', '0', '1467397052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8238', 'btc_cny', '', '1', '0', '1467397112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8239', 'btc_cny', '', '1', '0', '1467397172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8240', 'btc_cny', '', '1', '0', '1467397232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8241', 'btc_cny', '', '1', '0', '1467397292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8242', 'btc_cny', '', '1', '0', '1467397352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8243', 'btc_cny', '', '1', '0', '1467397412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8244', 'btc_cny', '', '1', '0', '1467397472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8245', 'btc_cny', '', '1', '0', '1467397532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8246', 'btc_cny', '', '1', '0', '1467397592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8247', 'btc_cny', '', '1', '0', '1467397652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8248', 'btc_cny', '', '1', '0', '1467397712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8249', 'btc_cny', '', '1', '0', '1467397772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8250', 'btc_cny', '', '1', '0', '1467397832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8251', 'btc_cny', '', '1', '0', '1467397892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8294', 'ltc_cny', '', '1', '0', '1467326142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8295', 'ltc_cny', '', '1', '0', '1467326202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8296', 'ltc_cny', '', '1', '0', '1467326262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8297', 'ltc_cny', '', '1', '0', '1467326322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8298', 'ltc_cny', '', '1', '0', '1467326382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8299', 'ltc_cny', '', '1', '0', '1467326442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8300', 'ltc_cny', '', '1', '0', '1467326502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8301', 'ltc_cny', '', '1', '0', '1467326562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8302', 'ltc_cny', '', '1', '0', '1467326622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8303', 'ltc_cny', '', '1', '0', '1467326682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8304', 'ltc_cny', '', '1', '0', '1467326742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8305', 'ltc_cny', '', '1', '0', '1467326802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8306', 'ltc_cny', '', '1', '0', '1467326862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8307', 'ltc_cny', '', '1', '0', '1467326922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8308', 'ltc_cny', '', '1', '0', '1467326982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8309', 'ltc_cny', '', '1', '0', '1467327042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8310', 'ltc_cny', '', '1', '0', '1467327102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8311', 'ltc_cny', '', '1', '0', '1467327162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8312', 'ltc_cny', '', '1', '0', '1467327222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8313', 'ltc_cny', '', '1', '0', '1467327282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8314', 'ltc_cny', '', '1', '0', '1467327342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8357', 'btc_cny', '', '1', '0', '1467397892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8358', 'btc_cny', '', '1', '0', '1467397952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8359', 'btc_cny', '', '1', '0', '1467398012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8360', 'btc_cny', '', '1', '0', '1467398072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8361', 'btc_cny', '', '1', '0', '1467398132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8362', 'btc_cny', '', '1', '0', '1467398192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8363', 'btc_cny', '', '1', '0', '1467398252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8364', 'btc_cny', '', '1', '0', '1467398312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8365', 'btc_cny', '', '1', '0', '1467398372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8366', 'btc_cny', '', '1', '0', '1467398432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8367', 'btc_cny', '', '1', '0', '1467398492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8368', 'btc_cny', '', '1', '0', '1467398552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8369', 'btc_cny', '', '1', '0', '1467398612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8370', 'btc_cny', '', '1', '0', '1467398672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8371', 'btc_cny', '', '1', '0', '1467398732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8372', 'btc_cny', '', '1', '0', '1467398792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8373', 'btc_cny', '', '1', '0', '1467398852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8374', 'btc_cny', '', '1', '0', '1467398912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8375', 'btc_cny', '', '1', '0', '1467398972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8376', 'btc_cny', '', '1', '0', '1467399032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8377', 'btc_cny', '', '1', '0', '1467399092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8420', 'ltc_cny', '', '1', '0', '1467327342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8421', 'ltc_cny', '', '1', '0', '1467327402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8422', 'ltc_cny', '', '1', '0', '1467327462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8423', 'ltc_cny', '', '1', '0', '1467327522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8424', 'ltc_cny', '', '1', '0', '1467327582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8425', 'ltc_cny', '', '1', '0', '1467327642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8426', 'ltc_cny', '', '1', '0', '1467327702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8427', 'ltc_cny', '', '1', '0', '1467327762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8428', 'ltc_cny', '', '1', '0', '1467327822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8429', 'ltc_cny', '', '1', '0', '1467327882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8430', 'ltc_cny', '', '1', '0', '1467327942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8431', 'ltc_cny', '', '1', '0', '1467328002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8432', 'ltc_cny', '', '1', '0', '1467328062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8433', 'ltc_cny', '', '1', '0', '1467328122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8434', 'ltc_cny', '', '1', '0', '1467328182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8435', 'ltc_cny', '', '1', '0', '1467328242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8436', 'ltc_cny', '', '1', '0', '1467328302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8437', 'ltc_cny', '', '1', '0', '1467328362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8438', 'ltc_cny', '', '1', '0', '1467328422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8439', 'ltc_cny', '', '1', '0', '1467328482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8440', 'ltc_cny', '', '1', '0', '1467328542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8483', 'btc_cny', '', '1', '0', '1467399092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8484', 'btc_cny', '', '1', '0', '1467399152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8485', 'btc_cny', '', '1', '0', '1467399212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8486', 'btc_cny', '', '1', '0', '1467399272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8487', 'btc_cny', '', '1', '0', '1467399332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8488', 'btc_cny', '', '1', '0', '1467399392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8489', 'btc_cny', '', '1', '0', '1467399452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8490', 'btc_cny', '', '1', '0', '1467399512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8491', 'btc_cny', '', '1', '0', '1467399572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8492', 'btc_cny', '', '1', '0', '1467399632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8493', 'btc_cny', '', '1', '0', '1467399692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8494', 'btc_cny', '', '1', '0', '1467399752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8495', 'btc_cny', '', '1', '0', '1467399812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8496', 'btc_cny', '', '1', '0', '1467399872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8497', 'btc_cny', '', '1', '0', '1467399932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8498', 'btc_cny', '', '1', '0', '1467399992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8499', 'btc_cny', '', '1', '0', '1467400052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8500', 'btc_cny', '', '1', '0', '1467400112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8501', 'btc_cny', '', '1', '0', '1467400172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8502', 'btc_cny', '', '1', '0', '1467400232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8503', 'btc_cny', '', '1', '0', '1467400292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8546', 'ltc_cny', '', '1', '0', '1467328542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8547', 'ltc_cny', '', '1', '0', '1467328602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8548', 'ltc_cny', '', '1', '0', '1467328662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8549', 'ltc_cny', '', '1', '0', '1467328722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8550', 'ltc_cny', '', '1', '0', '1467328782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8551', 'ltc_cny', '', '1', '0', '1467328842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8552', 'ltc_cny', '', '1', '0', '1467328902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8553', 'ltc_cny', '', '1', '0', '1467328962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8554', 'ltc_cny', '', '1', '0', '1467329022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8555', 'ltc_cny', '', '1', '0', '1467329082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8556', 'ltc_cny', '', '1', '0', '1467329142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8557', 'ltc_cny', '', '1', '0', '1467329202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8558', 'ltc_cny', '', '1', '0', '1467329262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8559', 'ltc_cny', '', '1', '0', '1467329322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8560', 'ltc_cny', '', '1', '0', '1467329382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8561', 'ltc_cny', '', '1', '0', '1467329442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8562', 'ltc_cny', '', '1', '0', '1467329502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8563', 'ltc_cny', '', '1', '0', '1467329562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8564', 'ltc_cny', '', '1', '0', '1467329622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8565', 'ltc_cny', '', '1', '0', '1467329682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8566', 'ltc_cny', '', '1', '0', '1467329742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8609', 'btc_cny', '', '1', '0', '1467400292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8610', 'btc_cny', '', '1', '0', '1467400352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8611', 'btc_cny', '', '1', '0', '1467400412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8612', 'btc_cny', '', '1', '0', '1467400472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8613', 'btc_cny', '', '1', '0', '1467400532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8614', 'btc_cny', '', '1', '0', '1467400592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8615', 'btc_cny', '', '1', '0', '1467400652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8616', 'btc_cny', '', '1', '0', '1467400712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8617', 'btc_cny', '', '1', '0', '1467400772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8618', 'btc_cny', '', '1', '0', '1467400832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8619', 'btc_cny', '', '1', '0', '1467400892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8620', 'btc_cny', '', '1', '0', '1467400952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8621', 'btc_cny', '', '1', '0', '1467401012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8622', 'btc_cny', '', '1', '0', '1467401072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8623', 'btc_cny', '', '1', '0', '1467401132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8624', 'btc_cny', '', '1', '0', '1467401192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8625', 'btc_cny', '', '1', '0', '1467401252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8626', 'btc_cny', '', '1', '0', '1467401312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8627', 'btc_cny', '', '1', '0', '1467401372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8628', 'btc_cny', '', '1', '0', '1467401432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8629', 'btc_cny', '', '1', '0', '1467401492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8672', 'ltc_cny', '', '1', '0', '1467329742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8673', 'ltc_cny', '', '1', '0', '1467329802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8674', 'ltc_cny', '', '1', '0', '1467329862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8675', 'ltc_cny', '', '1', '0', '1467329922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8676', 'ltc_cny', '', '1', '0', '1467329982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8677', 'ltc_cny', '', '1', '0', '1467330042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8678', 'ltc_cny', '', '1', '0', '1467330102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8679', 'ltc_cny', '', '1', '0', '1467330162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8680', 'ltc_cny', '', '1', '0', '1467330222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8681', 'ltc_cny', '', '1', '0', '1467330282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8682', 'ltc_cny', '', '1', '0', '1467330342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8683', 'ltc_cny', '', '1', '0', '1467330402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8684', 'ltc_cny', '', '1', '0', '1467330462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8685', 'ltc_cny', '', '1', '0', '1467330522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8686', 'ltc_cny', '', '1', '0', '1467330582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8687', 'ltc_cny', '', '1', '0', '1467330642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8688', 'ltc_cny', '', '1', '0', '1467330702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8689', 'ltc_cny', '', '1', '0', '1467330762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8690', 'ltc_cny', '', '1', '0', '1467330822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8691', 'ltc_cny', '', '1', '0', '1467330882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8692', 'ltc_cny', '', '1', '0', '1467330942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8735', 'btc_cny', '', '1', '0', '1467401492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8736', 'btc_cny', '', '1', '0', '1467401552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8737', 'btc_cny', '', '1', '0', '1467401612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8738', 'btc_cny', '', '1', '0', '1467401672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8739', 'btc_cny', '', '1', '0', '1467401732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8740', 'btc_cny', '', '1', '0', '1467401792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8741', 'btc_cny', '', '1', '0', '1467401852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8742', 'btc_cny', '', '1', '0', '1467401912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8743', 'btc_cny', '', '1', '0', '1467401972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8744', 'btc_cny', '', '1', '0', '1467402032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8745', 'btc_cny', '', '1', '0', '1467402092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8746', 'btc_cny', '', '1', '0', '1467402152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8747', 'btc_cny', '', '1', '0', '1467402212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8748', 'btc_cny', '', '1', '0', '1467402272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8749', 'btc_cny', '', '1', '0', '1467402332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8750', 'btc_cny', '', '1', '0', '1467402392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8751', 'btc_cny', '', '1', '0', '1467402452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8752', 'btc_cny', '', '1', '0', '1467402512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8753', 'btc_cny', '', '1', '0', '1467402572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8754', 'btc_cny', '', '1', '0', '1467402632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8755', 'btc_cny', '', '1', '0', '1467402692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8798', 'ltc_cny', '', '1', '0', '1467330942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8799', 'ltc_cny', '', '1', '0', '1467331002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8800', 'ltc_cny', '', '1', '0', '1467331062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8801', 'ltc_cny', '', '1', '0', '1467331122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8802', 'ltc_cny', '', '1', '0', '1467331182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8803', 'ltc_cny', '', '1', '0', '1467331242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8804', 'ltc_cny', '', '1', '0', '1467331302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8805', 'ltc_cny', '', '1', '0', '1467331362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8806', 'ltc_cny', '', '1', '0', '1467331422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8807', 'ltc_cny', '', '1', '0', '1467331482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8808', 'ltc_cny', '', '1', '0', '1467331542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8809', 'ltc_cny', '', '1', '0', '1467331602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8810', 'ltc_cny', '', '1', '0', '1467331662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8811', 'ltc_cny', '', '1', '0', '1467331722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8812', 'ltc_cny', '', '1', '0', '1467331782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8813', 'ltc_cny', '', '1', '0', '1467331842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8814', 'ltc_cny', '', '1', '0', '1467331902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8815', 'ltc_cny', '', '1', '0', '1467331962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8816', 'ltc_cny', '', '1', '0', '1467332022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8817', 'ltc_cny', '', '1', '0', '1467332082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8818', 'ltc_cny', '', '1', '0', '1467332142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8861', 'btc_cny', '', '1', '0', '1467402692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8862', 'btc_cny', '', '1', '0', '1467402752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8863', 'btc_cny', '', '1', '0', '1467402812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8864', 'btc_cny', '', '1', '0', '1467402872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8865', 'btc_cny', '', '1', '0', '1467402932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8866', 'btc_cny', '', '1', '0', '1467402992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8867', 'btc_cny', '', '1', '0', '1467403052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8868', 'btc_cny', '', '1', '0', '1467403112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8869', 'btc_cny', '', '1', '0', '1467403172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8870', 'btc_cny', '', '1', '0', '1467403232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8871', 'btc_cny', '', '1', '0', '1467403292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8872', 'btc_cny', '', '1', '0', '1467403352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8873', 'btc_cny', '', '1', '0', '1467403412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8874', 'btc_cny', '', '1', '0', '1467403472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8875', 'btc_cny', '', '1', '0', '1467403532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8876', 'btc_cny', '', '1', '0', '1467403592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8877', 'btc_cny', '', '1', '0', '1467403652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8878', 'btc_cny', '', '1', '0', '1467403712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8879', 'btc_cny', '', '1', '0', '1467403772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8880', 'btc_cny', '', '1', '0', '1467403832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8881', 'btc_cny', '', '1', '0', '1467403892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8924', 'ltc_cny', '', '1', '0', '1467332142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8925', 'ltc_cny', '', '1', '0', '1467332202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8926', 'ltc_cny', '', '1', '0', '1467332262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8927', 'ltc_cny', '', '1', '0', '1467332322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8928', 'ltc_cny', '', '1', '0', '1467332382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8929', 'ltc_cny', '', '1', '0', '1467332442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8930', 'ltc_cny', '', '1', '0', '1467332502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8931', 'ltc_cny', '', '1', '0', '1467332562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8932', 'ltc_cny', '', '1', '0', '1467332622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8933', 'ltc_cny', '', '1', '0', '1467332682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8934', 'ltc_cny', '', '1', '0', '1467332742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8935', 'ltc_cny', '', '1', '0', '1467332802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8936', 'ltc_cny', '', '1', '0', '1467332862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8937', 'ltc_cny', '', '1', '0', '1467332922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8938', 'ltc_cny', '', '1', '0', '1467332982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8939', 'ltc_cny', '', '1', '0', '1467333042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8940', 'ltc_cny', '', '1', '0', '1467333102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8941', 'ltc_cny', '', '1', '0', '1467333162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8942', 'ltc_cny', '', '1', '0', '1467333222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8943', 'ltc_cny', '', '1', '0', '1467333282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8944', 'ltc_cny', '', '1', '0', '1467333342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8987', 'btc_cny', '', '1', '0', '1467403892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8988', 'btc_cny', '', '1', '0', '1467403952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8989', 'btc_cny', '', '1', '0', '1467404012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8990', 'btc_cny', '', '1', '0', '1467404072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8991', 'btc_cny', '', '1', '0', '1467404132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8992', 'btc_cny', '', '1', '0', '1467404192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8993', 'btc_cny', '', '1', '0', '1467404252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8994', 'btc_cny', '', '1', '0', '1467404312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8995', 'btc_cny', '', '1', '0', '1467404372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8996', 'btc_cny', '', '1', '0', '1467404432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8997', 'btc_cny', '', '1', '0', '1467404492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8998', 'btc_cny', '', '1', '0', '1467404552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('8999', 'btc_cny', '', '1', '0', '1467404612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9000', 'btc_cny', '', '1', '0', '1467404672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9001', 'btc_cny', '', '1', '0', '1467404732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9002', 'btc_cny', '', '1', '0', '1467404792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9003', 'btc_cny', '', '1', '0', '1467404852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9004', 'btc_cny', '', '1', '0', '1467404912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9005', 'btc_cny', '', '1', '0', '1467404972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9006', 'btc_cny', '', '1', '0', '1467405032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9007', 'btc_cny', '', '1', '0', '1467405092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9050', 'ltc_cny', '', '1', '0', '1467333342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9051', 'ltc_cny', '', '1', '0', '1467333402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9052', 'ltc_cny', '', '1', '0', '1467333462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9053', 'ltc_cny', '', '1', '0', '1467333522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9054', 'ltc_cny', '', '1', '0', '1467333582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9055', 'ltc_cny', '', '1', '0', '1467333642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9056', 'ltc_cny', '', '1', '0', '1467333702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9057', 'ltc_cny', '', '1', '0', '1467333762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9058', 'ltc_cny', '', '1', '0', '1467333822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9059', 'ltc_cny', '', '1', '0', '1467333882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9060', 'ltc_cny', '', '1', '0', '1467333942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9061', 'ltc_cny', '', '1', '0', '1467334002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9062', 'ltc_cny', '', '1', '0', '1467334062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9063', 'ltc_cny', '', '1', '0', '1467334122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9064', 'ltc_cny', '', '1', '0', '1467334182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9065', 'ltc_cny', '', '1', '0', '1467334242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9066', 'ltc_cny', '', '1', '0', '1467334302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9067', 'ltc_cny', '', '1', '0', '1467334362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9068', 'ltc_cny', '', '1', '0', '1467334422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9069', 'ltc_cny', '', '1', '0', '1467334482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9070', 'ltc_cny', '', '1', '0', '1467334542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9113', 'btc_cny', '', '1', '0', '1467405092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9114', 'btc_cny', '', '1', '0', '1467405152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9115', 'btc_cny', '', '1', '0', '1467405212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9116', 'btc_cny', '', '1', '0', '1467405272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9117', 'btc_cny', '', '1', '0', '1467405332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9118', 'btc_cny', '', '1', '0', '1467405392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9119', 'btc_cny', '', '1', '0', '1467405452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9120', 'btc_cny', '', '1', '0', '1467405512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9121', 'btc_cny', '', '1', '0', '1467405572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9122', 'btc_cny', '', '1', '0', '1467405632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9123', 'btc_cny', '', '1', '0', '1467405692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9124', 'btc_cny', '', '1', '0', '1467405752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9125', 'btc_cny', '', '1', '0', '1467405812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9126', 'btc_cny', '', '1', '0', '1467405872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9127', 'btc_cny', '', '1', '0', '1467405932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9128', 'btc_cny', '', '1', '0', '1467405992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9129', 'btc_cny', '', '1', '0', '1467406052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9130', 'btc_cny', '', '1', '0', '1467406112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9131', 'btc_cny', '', '1', '0', '1467406172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9132', 'btc_cny', '', '1', '0', '1467406232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9133', 'btc_cny', '', '1', '0', '1467406292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9176', 'ltc_cny', '', '1', '0', '1467334542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9177', 'ltc_cny', '', '1', '0', '1467334602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9178', 'ltc_cny', '', '1', '0', '1467334662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9179', 'ltc_cny', '', '1', '0', '1467334722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9180', 'ltc_cny', '', '1', '0', '1467334782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9181', 'ltc_cny', '', '1', '0', '1467334842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9182', 'ltc_cny', '', '1', '0', '1467334902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9183', 'ltc_cny', '', '1', '0', '1467334962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9184', 'ltc_cny', '', '1', '0', '1467335022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9185', 'ltc_cny', '', '1', '0', '1467335082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9186', 'ltc_cny', '', '1', '0', '1467335142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9187', 'ltc_cny', '', '1', '0', '1467335202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9188', 'ltc_cny', '', '1', '0', '1467335262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9189', 'ltc_cny', '', '1', '0', '1467335322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9190', 'ltc_cny', '', '1', '0', '1467335382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9191', 'ltc_cny', '', '1', '0', '1467335442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9192', 'ltc_cny', '', '1', '0', '1467335502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9193', 'ltc_cny', '', '1', '0', '1467335562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9194', 'ltc_cny', '', '1', '0', '1467335622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9195', 'ltc_cny', '', '1', '0', '1467335682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9196', 'ltc_cny', '', '1', '0', '1467335742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9239', 'btc_cny', '', '1', '0', '1467406292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9240', 'btc_cny', '', '1', '0', '1467406352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9241', 'btc_cny', '', '1', '0', '1467406412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9242', 'btc_cny', '', '1', '0', '1467406472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9243', 'btc_cny', '', '1', '0', '1467406532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9244', 'btc_cny', '', '1', '0', '1467406592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9245', 'btc_cny', '', '1', '0', '1467406652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9246', 'btc_cny', '', '1', '0', '1467406712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9247', 'btc_cny', '', '1', '0', '1467406772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9248', 'btc_cny', '', '1', '0', '1467406832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9249', 'btc_cny', '', '1', '0', '1467406892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9250', 'btc_cny', '', '1', '0', '1467406952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9251', 'btc_cny', '', '1', '0', '1467407012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9252', 'btc_cny', '', '1', '0', '1467407072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9253', 'btc_cny', '', '1', '0', '1467407132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9254', 'btc_cny', '', '1', '0', '1467407192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9255', 'btc_cny', '', '1', '0', '1467407252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9256', 'btc_cny', '', '1', '0', '1467407312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9257', 'btc_cny', '', '1', '0', '1467407372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9258', 'btc_cny', '', '1', '0', '1467407432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9259', 'btc_cny', '', '1', '0', '1467407492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9302', 'ltc_cny', '', '1', '0', '1467335742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9303', 'ltc_cny', '', '1', '0', '1467335802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9304', 'ltc_cny', '', '1', '0', '1467335862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9305', 'ltc_cny', '', '1', '0', '1467335922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9306', 'ltc_cny', '', '1', '0', '1467335982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9307', 'ltc_cny', '', '1', '0', '1467336042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9308', 'ltc_cny', '', '1', '0', '1467336102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9309', 'ltc_cny', '', '1', '0', '1467336162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9310', 'ltc_cny', '', '1', '0', '1467336222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9311', 'ltc_cny', '', '1', '0', '1467336282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9312', 'ltc_cny', '', '1', '0', '1467336342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9313', 'ltc_cny', '', '1', '0', '1467336402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9314', 'ltc_cny', '', '1', '0', '1467336462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9315', 'ltc_cny', '', '1', '0', '1467336522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9316', 'ltc_cny', '', '1', '0', '1467336582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9317', 'ltc_cny', '', '1', '0', '1467336642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9318', 'ltc_cny', '', '1', '0', '1467336702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9319', 'ltc_cny', '', '1', '0', '1467336762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9320', 'ltc_cny', '', '1', '0', '1467336822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9321', 'ltc_cny', '', '1', '0', '1467336882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9322', 'ltc_cny', '', '1', '0', '1467336942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9365', 'btc_cny', '', '1', '0', '1467407492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9366', 'btc_cny', '', '1', '0', '1467407552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9367', 'btc_cny', '', '1', '0', '1467407612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9368', 'btc_cny', '', '1', '0', '1467407672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9369', 'btc_cny', '', '1', '0', '1467407732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9370', 'btc_cny', '', '1', '0', '1467407792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9371', 'btc_cny', '', '1', '0', '1467407852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9372', 'btc_cny', '', '1', '0', '1467407912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9373', 'btc_cny', '', '1', '0', '1467407972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9374', 'btc_cny', '', '1', '0', '1467408032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9375', 'btc_cny', '', '1', '0', '1467408092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9376', 'btc_cny', '', '1', '0', '1467408152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9377', 'btc_cny', '', '1', '0', '1467408212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9378', 'btc_cny', '', '1', '0', '1467408272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9379', 'btc_cny', '', '1', '0', '1467408332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9380', 'btc_cny', '', '1', '0', '1467408392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9381', 'btc_cny', '', '1', '0', '1467408452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9382', 'btc_cny', '', '1', '0', '1467408512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9383', 'btc_cny', '', '1', '0', '1467408572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9384', 'btc_cny', '', '1', '0', '1467408632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9385', 'btc_cny', '', '1', '0', '1467408692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9428', 'ltc_cny', '', '1', '0', '1467336942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9429', 'ltc_cny', '', '1', '0', '1467337002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9430', 'ltc_cny', '', '1', '0', '1467337062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9431', 'ltc_cny', '', '1', '0', '1467337122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9432', 'ltc_cny', '', '1', '0', '1467337182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9433', 'ltc_cny', '', '1', '0', '1467337242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9434', 'ltc_cny', '', '1', '0', '1467337302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9435', 'ltc_cny', '', '1', '0', '1467337362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9436', 'ltc_cny', '', '1', '0', '1467337422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9437', 'ltc_cny', '', '1', '0', '1467337482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9438', 'ltc_cny', '', '1', '0', '1467337542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9439', 'ltc_cny', '', '1', '0', '1467337602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9440', 'ltc_cny', '', '1', '0', '1467337662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9441', 'ltc_cny', '', '1', '0', '1467337722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9442', 'ltc_cny', '', '1', '0', '1467337782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9443', 'ltc_cny', '', '1', '0', '1467337842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9444', 'ltc_cny', '', '1', '0', '1467337902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9445', 'ltc_cny', '', '1', '0', '1467337962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9446', 'ltc_cny', '', '1', '0', '1467338022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9447', 'ltc_cny', '', '1', '0', '1467338082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9448', 'ltc_cny', '', '1', '0', '1467338142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9491', 'btc_cny', '', '1', '0', '1467408692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9492', 'btc_cny', '', '1', '0', '1467408752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9493', 'btc_cny', '', '1', '0', '1467408812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9494', 'btc_cny', '', '1', '0', '1467408872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9495', 'btc_cny', '', '1', '0', '1467408932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9496', 'btc_cny', '', '1', '0', '1467408992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9497', 'btc_cny', '', '1', '0', '1467409052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9498', 'btc_cny', '', '1', '0', '1467409112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9499', 'btc_cny', '', '1', '0', '1467409172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9500', 'btc_cny', '', '1', '0', '1467409232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9501', 'btc_cny', '', '1', '0', '1467409292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9502', 'btc_cny', '', '1', '0', '1467409352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9503', 'btc_cny', '', '1', '0', '1467409412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9504', 'btc_cny', '', '1', '0', '1467409472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9505', 'btc_cny', '', '1', '0', '1467409532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9506', 'btc_cny', '', '1', '0', '1467409592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9507', 'btc_cny', '', '1', '0', '1467409652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9508', 'btc_cny', '', '1', '0', '1467409712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9509', 'btc_cny', '', '1', '0', '1467409772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9510', 'btc_cny', '', '1', '0', '1467409832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9511', 'btc_cny', '', '1', '0', '1467409892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9554', 'ltc_cny', '', '1', '0', '1467338142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9555', 'ltc_cny', '', '1', '0', '1467338202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9556', 'ltc_cny', '', '1', '0', '1467338262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9557', 'ltc_cny', '', '1', '0', '1467338322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9558', 'ltc_cny', '', '1', '0', '1467338382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9559', 'ltc_cny', '', '1', '0', '1467338442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9560', 'ltc_cny', '', '1', '0', '1467338502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9561', 'ltc_cny', '', '1', '0', '1467338562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9562', 'ltc_cny', '', '1', '0', '1467338622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9563', 'ltc_cny', '', '1', '0', '1467338682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9564', 'ltc_cny', '', '1', '0', '1467338742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9565', 'ltc_cny', '', '1', '0', '1467338802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9566', 'ltc_cny', '', '1', '0', '1467338862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9567', 'ltc_cny', '', '1', '0', '1467338922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9568', 'ltc_cny', '', '1', '0', '1467338982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9569', 'ltc_cny', '', '1', '0', '1467339042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9570', 'ltc_cny', '', '1', '0', '1467339102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9571', 'ltc_cny', '', '1', '0', '1467339162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9572', 'ltc_cny', '', '1', '0', '1467339222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9573', 'ltc_cny', '', '1', '0', '1467339282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9574', 'ltc_cny', '', '1', '0', '1467339342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9617', 'btc_cny', '', '1', '0', '1467409892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9618', 'btc_cny', '', '1', '0', '1467409952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9619', 'btc_cny', '', '1', '0', '1467410012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9620', 'btc_cny', '', '1', '0', '1467410072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9621', 'btc_cny', '', '1', '0', '1467410132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9622', 'btc_cny', '', '1', '0', '1467410192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9623', 'btc_cny', '', '1', '0', '1467410252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9624', 'btc_cny', '', '1', '0', '1467410312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9625', 'btc_cny', '', '1', '0', '1467410372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9626', 'btc_cny', '', '1', '0', '1467410432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9627', 'btc_cny', '', '1', '0', '1467410492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9628', 'btc_cny', '', '1', '0', '1467410552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9629', 'btc_cny', '', '1', '0', '1467410612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9630', 'btc_cny', '', '1', '0', '1467410672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9631', 'btc_cny', '', '1', '0', '1467410732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9632', 'btc_cny', '', '1', '0', '1467410792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9633', 'btc_cny', '', '1', '0', '1467410852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9634', 'btc_cny', '', '1', '0', '1467410912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9635', 'btc_cny', '', '1', '0', '1467410972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9636', 'btc_cny', '', '1', '0', '1467411032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9637', 'btc_cny', '', '1', '0', '1467411092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9680', 'ltc_cny', '', '1', '0', '1467339342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9681', 'ltc_cny', '', '1', '0', '1467339402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9682', 'ltc_cny', '', '1', '0', '1467339462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9683', 'ltc_cny', '', '1', '0', '1467339522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9684', 'ltc_cny', '', '1', '0', '1467339582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9685', 'ltc_cny', '', '1', '0', '1467339642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9686', 'ltc_cny', '', '1', '0', '1467339702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9687', 'ltc_cny', '', '1', '0', '1467339762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9688', 'ltc_cny', '', '1', '0', '1467339822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9689', 'ltc_cny', '', '1', '0', '1467339882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9690', 'ltc_cny', '', '1', '0', '1467339942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9691', 'ltc_cny', '', '1', '0', '1467340002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9692', 'ltc_cny', '', '1', '0', '1467340062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9693', 'ltc_cny', '', '1', '0', '1467340122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9694', 'ltc_cny', '', '1', '0', '1467340182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9695', 'ltc_cny', '', '1', '0', '1467340242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9696', 'ltc_cny', '', '1', '0', '1467340302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9697', 'ltc_cny', '', '1', '0', '1467340362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9698', 'ltc_cny', '', '1', '0', '1467340422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9699', 'ltc_cny', '', '1', '0', '1467340482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9700', 'ltc_cny', '', '1', '0', '1467340542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9743', 'btc_cny', '', '1', '0', '1467411092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9744', 'btc_cny', '', '1', '0', '1467411152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9745', 'btc_cny', '', '1', '0', '1467411212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9746', 'btc_cny', '', '1', '0', '1467411272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9747', 'btc_cny', '', '1', '0', '1467411332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9748', 'btc_cny', '', '1', '0', '1467411392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9749', 'btc_cny', '', '1', '0', '1467411452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9750', 'btc_cny', '', '1', '0', '1467411512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9751', 'btc_cny', '', '1', '0', '1467411572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9752', 'btc_cny', '', '1', '0', '1467411632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9753', 'btc_cny', '', '1', '0', '1467411692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9754', 'btc_cny', '', '1', '0', '1467411752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9755', 'btc_cny', '', '1', '0', '1467411812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9756', 'btc_cny', '', '1', '0', '1467411872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9757', 'btc_cny', '', '1', '0', '1467411932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9758', 'btc_cny', '', '1', '0', '1467411992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9759', 'btc_cny', '', '1', '0', '1467412052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9760', 'btc_cny', '', '1', '0', '1467412112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9761', 'btc_cny', '', '1', '0', '1467412172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9762', 'btc_cny', '', '1', '0', '1467412232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9763', 'btc_cny', '', '1', '0', '1467412292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9790', 'btc_cny', '[1467608700,\"22.10000000\",\"4400.00000000\",\"4599.00000000\",\"4400.00000000\",\"4599.00000000\"]', '5', '0', '1467608700', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9791', 'btc_cny', '', '5', '0', '1467609000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9792', 'btc_cny', '', '5', '0', '1467609300', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9793', 'btc_cny', '', '5', '0', '1467609600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9794', 'btc_cny', '', '5', '0', '1467609900', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9795', 'btc_cny', '', '5', '0', '1467610200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9796', 'btc_cny', '', '5', '0', '1467610500', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9797', 'btc_cny', '', '5', '0', '1467610800', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9798', 'btc_cny', '', '5', '0', '1467611100', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9799', 'btc_cny', '', '5', '0', '1467611400', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9800', 'ltc_cny', '', '1', '0', '1467340542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9801', 'ltc_cny', '', '1', '0', '1467340602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9802', 'ltc_cny', '', '1', '0', '1467340662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9803', 'ltc_cny', '', '1', '0', '1467340722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9804', 'ltc_cny', '', '1', '0', '1467340782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9805', 'ltc_cny', '', '1', '0', '1467340842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9806', 'ltc_cny', '', '1', '0', '1467340902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9807', 'ltc_cny', '', '1', '0', '1467340962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9808', 'ltc_cny', '', '1', '0', '1467341022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9809', 'ltc_cny', '', '1', '0', '1467341082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9810', 'ltc_cny', '', '1', '0', '1467341142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9811', 'ltc_cny', '', '1', '0', '1467341202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9812', 'ltc_cny', '', '1', '0', '1467341262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9813', 'ltc_cny', '', '1', '0', '1467341322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9814', 'ltc_cny', '', '1', '0', '1467341382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9815', 'ltc_cny', '', '1', '0', '1467341442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9816', 'ltc_cny', '', '1', '0', '1467341502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9817', 'ltc_cny', '', '1', '0', '1467341562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9818', 'ltc_cny', '', '1', '0', '1467341622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9819', 'ltc_cny', '', '1', '0', '1467341682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9820', 'ltc_cny', '', '1', '0', '1467341742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9863', 'btc_cny', '', '1', '0', '1467412292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9864', 'btc_cny', '', '1', '0', '1467412352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9865', 'btc_cny', '', '1', '0', '1467412412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9866', 'btc_cny', '', '1', '0', '1467412472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9867', 'btc_cny', '', '1', '0', '1467412532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9868', 'btc_cny', '', '1', '0', '1467412592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9869', 'btc_cny', '', '1', '0', '1467412652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9870', 'btc_cny', '', '1', '0', '1467412712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9871', 'btc_cny', '', '1', '0', '1467412772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9872', 'btc_cny', '', '1', '0', '1467412832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9873', 'btc_cny', '', '1', '0', '1467412892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9874', 'btc_cny', '', '1', '0', '1467412952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9875', 'btc_cny', '', '1', '0', '1467413012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9876', 'btc_cny', '', '1', '0', '1467413072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9877', 'btc_cny', '', '1', '0', '1467413132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9878', 'btc_cny', '', '1', '0', '1467413192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9879', 'btc_cny', '', '1', '0', '1467413252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9880', 'btc_cny', '', '1', '0', '1467413312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9881', 'btc_cny', '', '1', '0', '1467413372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9882', 'btc_cny', '', '1', '0', '1467413432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9883', 'btc_cny', '', '1', '0', '1467413492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9905', 'ltc_cny', '', '1', '0', '1467341742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9906', 'ltc_cny', '', '1', '0', '1467341802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9907', 'ltc_cny', '', '1', '0', '1467341862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9908', 'ltc_cny', '', '1', '0', '1467341922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9909', 'ltc_cny', '', '1', '0', '1467341982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9910', 'ltc_cny', '', '1', '0', '1467342042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9911', 'ltc_cny', '', '1', '0', '1467342102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9912', 'ltc_cny', '', '1', '0', '1467342162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9913', 'ltc_cny', '', '1', '0', '1467342222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9914', 'ltc_cny', '', '1', '0', '1467342282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9915', 'ltc_cny', '', '1', '0', '1467342342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9916', 'ltc_cny', '', '1', '0', '1467342402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9917', 'ltc_cny', '', '1', '0', '1467342462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9918', 'ltc_cny', '', '1', '0', '1467342522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9919', 'ltc_cny', '', '1', '0', '1467342582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9920', 'ltc_cny', '', '1', '0', '1467342642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9921', 'ltc_cny', '', '1', '0', '1467342702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9922', 'ltc_cny', '', '1', '0', '1467342762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9923', 'ltc_cny', '', '1', '0', '1467342822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9924', 'ltc_cny', '', '1', '0', '1467342882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9925', 'ltc_cny', '', '1', '0', '1467342942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9968', 'btc_cny', '', '1', '0', '1467413492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9969', 'btc_cny', '', '1', '0', '1467413552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9970', 'btc_cny', '', '1', '0', '1467413612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9971', 'btc_cny', '', '1', '0', '1467413672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9972', 'btc_cny', '', '1', '0', '1467413732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9973', 'btc_cny', '', '1', '0', '1467413792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9974', 'btc_cny', '', '1', '0', '1467413852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9975', 'btc_cny', '', '1', '0', '1467413912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9976', 'btc_cny', '', '1', '0', '1467413972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9977', 'btc_cny', '', '1', '0', '1467414032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9978', 'btc_cny', '', '1', '0', '1467414092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9979', 'btc_cny', '', '1', '0', '1467414152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9980', 'btc_cny', '', '1', '0', '1467414212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9981', 'btc_cny', '', '1', '0', '1467414272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9982', 'btc_cny', '', '1', '0', '1467414332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9983', 'btc_cny', '', '1', '0', '1467414392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9984', 'btc_cny', '', '1', '0', '1467414452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9985', 'btc_cny', '', '1', '0', '1467414512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9986', 'btc_cny', '', '1', '0', '1467414572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9987', 'btc_cny', '', '1', '0', '1467414632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('9988', 'btc_cny', '', '1', '0', '1467414692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10010', 'ltc_cny', '', '1', '0', '1467342942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10011', 'ltc_cny', '', '1', '0', '1467343002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10012', 'ltc_cny', '', '1', '0', '1467343062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10013', 'ltc_cny', '', '1', '0', '1467343122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10014', 'ltc_cny', '', '1', '0', '1467343182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10015', 'ltc_cny', '', '1', '0', '1467343242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10016', 'ltc_cny', '', '1', '0', '1467343302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10017', 'ltc_cny', '', '1', '0', '1467343362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10018', 'ltc_cny', '', '1', '0', '1467343422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10019', 'ltc_cny', '', '1', '0', '1467343482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10020', 'ltc_cny', '', '1', '0', '1467343542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10021', 'ltc_cny', '', '1', '0', '1467343602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10022', 'ltc_cny', '', '1', '0', '1467343662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10023', 'ltc_cny', '', '1', '0', '1467343722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10024', 'ltc_cny', '', '1', '0', '1467343782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10025', 'ltc_cny', '', '1', '0', '1467343842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10026', 'ltc_cny', '', '1', '0', '1467343902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10027', 'ltc_cny', '', '1', '0', '1467343962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10028', 'ltc_cny', '', '1', '0', '1467344022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10029', 'ltc_cny', '', '1', '0', '1467344082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10030', 'ltc_cny', '', '1', '0', '1467344142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10073', 'btc_cny', '', '1', '0', '1467414692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10074', 'btc_cny', '', '1', '0', '1467414752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10075', 'btc_cny', '', '1', '0', '1467414812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10076', 'btc_cny', '', '1', '0', '1467414872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10077', 'btc_cny', '', '1', '0', '1467414932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10078', 'btc_cny', '', '1', '0', '1467414992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10079', 'btc_cny', '', '1', '0', '1467415052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10080', 'btc_cny', '', '1', '0', '1467415112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10081', 'btc_cny', '', '1', '0', '1467415172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10082', 'btc_cny', '', '1', '0', '1467415232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10083', 'btc_cny', '', '1', '0', '1467415292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10084', 'btc_cny', '', '1', '0', '1467415352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10085', 'btc_cny', '', '1', '0', '1467415412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10086', 'btc_cny', '', '1', '0', '1467415472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10087', 'btc_cny', '', '1', '0', '1467415532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10088', 'btc_cny', '', '1', '0', '1467415592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10089', 'btc_cny', '', '1', '0', '1467415652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10090', 'btc_cny', '', '1', '0', '1467415712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10091', 'btc_cny', '', '1', '0', '1467415772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10092', 'btc_cny', '', '1', '0', '1467415832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10093', 'btc_cny', '', '1', '0', '1467415892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10115', 'ltc_cny', '', '1', '0', '1467344142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10116', 'ltc_cny', '', '1', '0', '1467344202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10117', 'ltc_cny', '', '1', '0', '1467344262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10118', 'ltc_cny', '', '1', '0', '1467344322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10119', 'ltc_cny', '', '1', '0', '1467344382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10120', 'ltc_cny', '', '1', '0', '1467344442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10121', 'ltc_cny', '', '1', '0', '1467344502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10122', 'ltc_cny', '', '1', '0', '1467344562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10123', 'ltc_cny', '', '1', '0', '1467344622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10124', 'ltc_cny', '', '1', '0', '1467344682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10125', 'ltc_cny', '', '1', '0', '1467344742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10126', 'ltc_cny', '', '1', '0', '1467344802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10127', 'ltc_cny', '', '1', '0', '1467344862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10128', 'ltc_cny', '', '1', '0', '1467344922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10129', 'ltc_cny', '', '1', '0', '1467344982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10130', 'ltc_cny', '', '1', '0', '1467345042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10131', 'ltc_cny', '', '1', '0', '1467345102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10132', 'ltc_cny', '', '1', '0', '1467345162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10133', 'ltc_cny', '', '1', '0', '1467345222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10134', 'ltc_cny', '', '1', '0', '1467345282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10135', 'ltc_cny', '', '1', '0', '1467345342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10178', 'btc_cny', '', '1', '0', '1467415892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10179', 'btc_cny', '', '1', '0', '1467415952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10180', 'btc_cny', '', '1', '0', '1467416012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10181', 'btc_cny', '', '1', '0', '1467416072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10182', 'btc_cny', '', '1', '0', '1467416132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10183', 'btc_cny', '', '1', '0', '1467416192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10184', 'btc_cny', '', '1', '0', '1467416252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10185', 'btc_cny', '', '1', '0', '1467416312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10186', 'btc_cny', '', '1', '0', '1467416372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10187', 'btc_cny', '', '1', '0', '1467416432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10188', 'btc_cny', '', '1', '0', '1467416492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10189', 'btc_cny', '', '1', '0', '1467416552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10190', 'btc_cny', '', '1', '0', '1467416612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10191', 'btc_cny', '', '1', '0', '1467416672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10192', 'btc_cny', '', '1', '0', '1467416732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10193', 'btc_cny', '', '1', '0', '1467416792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10194', 'btc_cny', '', '1', '0', '1467416852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10195', 'btc_cny', '', '1', '0', '1467416912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10196', 'btc_cny', '', '1', '0', '1467416972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10197', 'btc_cny', '', '1', '0', '1467417032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10198', 'btc_cny', '', '1', '0', '1467417092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10220', 'ltc_cny', '', '1', '0', '1467345342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10221', 'ltc_cny', '', '1', '0', '1467345402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10222', 'ltc_cny', '', '1', '0', '1467345462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10223', 'ltc_cny', '', '1', '0', '1467345522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10224', 'ltc_cny', '', '1', '0', '1467345582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10225', 'ltc_cny', '', '1', '0', '1467345642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10226', 'ltc_cny', '', '1', '0', '1467345702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10227', 'ltc_cny', '', '1', '0', '1467345762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10228', 'ltc_cny', '', '1', '0', '1467345822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10229', 'ltc_cny', '', '1', '0', '1467345882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10230', 'ltc_cny', '', '1', '0', '1467345942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10231', 'ltc_cny', '', '1', '0', '1467346002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10232', 'ltc_cny', '', '1', '0', '1467346062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10233', 'ltc_cny', '', '1', '0', '1467346122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10234', 'ltc_cny', '', '1', '0', '1467346182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10235', 'ltc_cny', '', '1', '0', '1467346242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10236', 'ltc_cny', '', '1', '0', '1467346302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10237', 'ltc_cny', '', '1', '0', '1467346362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10238', 'ltc_cny', '', '1', '0', '1467346422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10239', 'ltc_cny', '', '1', '0', '1467346482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10240', 'ltc_cny', '', '1', '0', '1467346542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10283', 'btc_cny', '', '1', '0', '1467417092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10284', 'btc_cny', '', '1', '0', '1467417152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10285', 'btc_cny', '', '1', '0', '1467417212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10286', 'btc_cny', '', '1', '0', '1467417272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10287', 'btc_cny', '', '1', '0', '1467417332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10288', 'btc_cny', '', '1', '0', '1467417392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10289', 'btc_cny', '', '1', '0', '1467417452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10290', 'btc_cny', '', '1', '0', '1467417512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10291', 'btc_cny', '', '1', '0', '1467417572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10292', 'btc_cny', '', '1', '0', '1467417632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10293', 'btc_cny', '', '1', '0', '1467417692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10294', 'btc_cny', '', '1', '0', '1467417752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10295', 'btc_cny', '', '1', '0', '1467417812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10296', 'btc_cny', '', '1', '0', '1467417872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10297', 'btc_cny', '', '1', '0', '1467417932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10298', 'btc_cny', '', '1', '0', '1467417992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10299', 'btc_cny', '', '1', '0', '1467418052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10300', 'btc_cny', '', '1', '0', '1467418112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10301', 'btc_cny', '', '1', '0', '1467418172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10302', 'btc_cny', '', '1', '0', '1467418232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10303', 'btc_cny', '', '1', '0', '1467418292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10325', 'ltc_cny', '', '1', '0', '1467346542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10326', 'ltc_cny', '', '1', '0', '1467346602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10327', 'ltc_cny', '', '1', '0', '1467346662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10328', 'ltc_cny', '', '1', '0', '1467346722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10329', 'ltc_cny', '', '1', '0', '1467346782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10330', 'ltc_cny', '', '1', '0', '1467346842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10331', 'ltc_cny', '', '1', '0', '1467346902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10332', 'ltc_cny', '', '1', '0', '1467346962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10333', 'ltc_cny', '', '1', '0', '1467347022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10334', 'ltc_cny', '', '1', '0', '1467347082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10335', 'ltc_cny', '', '1', '0', '1467347142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10336', 'ltc_cny', '', '1', '0', '1467347202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10337', 'ltc_cny', '', '1', '0', '1467347262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10338', 'ltc_cny', '', '1', '0', '1467347322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10339', 'ltc_cny', '', '1', '0', '1467347382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10340', 'ltc_cny', '', '1', '0', '1467347442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10341', 'ltc_cny', '', '1', '0', '1467347502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10342', 'ltc_cny', '', '1', '0', '1467347562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10343', 'ltc_cny', '', '1', '0', '1467347622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10344', 'ltc_cny', '', '1', '0', '1467347682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10345', 'ltc_cny', '', '1', '0', '1467347742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10388', 'btc_cny', '', '1', '0', '1467418292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10389', 'btc_cny', '', '1', '0', '1467418352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10390', 'btc_cny', '', '1', '0', '1467418412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10391', 'btc_cny', '', '1', '0', '1467418472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10392', 'btc_cny', '', '1', '0', '1467418532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10393', 'btc_cny', '', '1', '0', '1467418592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10394', 'btc_cny', '', '1', '0', '1467418652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10395', 'btc_cny', '', '1', '0', '1467418712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10396', 'btc_cny', '', '1', '0', '1467418772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10397', 'btc_cny', '', '1', '0', '1467418832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10398', 'btc_cny', '', '1', '0', '1467418892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10399', 'btc_cny', '', '1', '0', '1467418952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10400', 'btc_cny', '', '1', '0', '1467419012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10401', 'btc_cny', '', '1', '0', '1467419072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10402', 'btc_cny', '', '1', '0', '1467419132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10403', 'btc_cny', '', '1', '0', '1467419192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10404', 'btc_cny', '', '1', '0', '1467419252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10405', 'btc_cny', '', '1', '0', '1467419312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10406', 'btc_cny', '', '1', '0', '1467419372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10407', 'btc_cny', '', '1', '0', '1467419432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10408', 'btc_cny', '', '1', '0', '1467419492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10430', 'ltc_cny', '', '1', '0', '1467347742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10431', 'ltc_cny', '', '1', '0', '1467347802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10432', 'ltc_cny', '', '1', '0', '1467347862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10433', 'ltc_cny', '', '1', '0', '1467347922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10434', 'ltc_cny', '', '1', '0', '1467347982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10435', 'ltc_cny', '', '1', '0', '1467348042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10436', 'ltc_cny', '', '1', '0', '1467348102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10437', 'ltc_cny', '', '1', '0', '1467348162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10438', 'ltc_cny', '', '1', '0', '1467348222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10439', 'ltc_cny', '', '1', '0', '1467348282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10440', 'ltc_cny', '', '1', '0', '1467348342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10441', 'ltc_cny', '', '1', '0', '1467348402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10442', 'ltc_cny', '', '1', '0', '1467348462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10443', 'ltc_cny', '', '1', '0', '1467348522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10444', 'ltc_cny', '', '1', '0', '1467348582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10445', 'ltc_cny', '', '1', '0', '1467348642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10446', 'ltc_cny', '', '1', '0', '1467348702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10447', 'ltc_cny', '', '1', '0', '1467348762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10448', 'ltc_cny', '', '1', '0', '1467348822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10449', 'ltc_cny', '', '1', '0', '1467348882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10450', 'ltc_cny', '', '1', '0', '1467348942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10493', 'btc_cny', '', '1', '0', '1467419492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10494', 'btc_cny', '', '1', '0', '1467419552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10495', 'btc_cny', '', '1', '0', '1467419612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10496', 'btc_cny', '', '1', '0', '1467419672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10497', 'btc_cny', '', '1', '0', '1467419732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10498', 'btc_cny', '', '1', '0', '1467419792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10499', 'btc_cny', '', '1', '0', '1467419852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10500', 'btc_cny', '', '1', '0', '1467419912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10501', 'btc_cny', '', '1', '0', '1467419972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10502', 'btc_cny', '', '1', '0', '1467420032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10503', 'btc_cny', '', '1', '0', '1467420092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10504', 'btc_cny', '', '1', '0', '1467420152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10505', 'btc_cny', '', '1', '0', '1467420212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10506', 'btc_cny', '', '1', '0', '1467420272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10507', 'btc_cny', '', '1', '0', '1467420332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10508', 'btc_cny', '', '1', '0', '1467420392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10509', 'btc_cny', '', '1', '0', '1467420452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10510', 'btc_cny', '', '1', '0', '1467420512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10511', 'btc_cny', '', '1', '0', '1467420572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10512', 'btc_cny', '', '1', '0', '1467420632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10513', 'btc_cny', '', '1', '0', '1467420692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10535', 'ltc_cny', '', '1', '0', '1467348942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10536', 'ltc_cny', '', '1', '0', '1467349002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10537', 'ltc_cny', '', '1', '0', '1467349062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10538', 'ltc_cny', '', '1', '0', '1467349122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10539', 'ltc_cny', '', '1', '0', '1467349182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10540', 'ltc_cny', '', '1', '0', '1467349242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10541', 'ltc_cny', '', '1', '0', '1467349302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10542', 'ltc_cny', '', '1', '0', '1467349362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10543', 'ltc_cny', '', '1', '0', '1467349422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10544', 'ltc_cny', '', '1', '0', '1467349482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10545', 'ltc_cny', '', '1', '0', '1467349542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10546', 'ltc_cny', '', '1', '0', '1467349602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10547', 'ltc_cny', '', '1', '0', '1467349662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10548', 'ltc_cny', '', '1', '0', '1467349722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10549', 'ltc_cny', '', '1', '0', '1467349782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10550', 'ltc_cny', '', '1', '0', '1467349842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10551', 'ltc_cny', '', '1', '0', '1467349902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10552', 'ltc_cny', '', '1', '0', '1467349962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10553', 'ltc_cny', '', '1', '0', '1467350022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10554', 'ltc_cny', '', '1', '0', '1467350082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10555', 'ltc_cny', '', '1', '0', '1467350142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10598', 'btc_cny', '', '1', '0', '1467420692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10599', 'btc_cny', '', '1', '0', '1467420752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10600', 'btc_cny', '', '1', '0', '1467420812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10601', 'btc_cny', '', '1', '0', '1467420872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10602', 'btc_cny', '', '1', '0', '1467420932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10603', 'btc_cny', '', '1', '0', '1467420992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10604', 'btc_cny', '', '1', '0', '1467421052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10605', 'btc_cny', '', '1', '0', '1467421112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10606', 'btc_cny', '', '1', '0', '1467421172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10607', 'btc_cny', '', '1', '0', '1467421232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10608', 'btc_cny', '', '1', '0', '1467421292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10609', 'btc_cny', '', '1', '0', '1467421352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10610', 'btc_cny', '', '1', '0', '1467421412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10611', 'btc_cny', '', '1', '0', '1467421472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10612', 'btc_cny', '', '1', '0', '1467421532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10613', 'btc_cny', '', '1', '0', '1467421592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10614', 'btc_cny', '', '1', '0', '1467421652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10615', 'btc_cny', '', '1', '0', '1467421712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10616', 'btc_cny', '', '1', '0', '1467421772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10617', 'btc_cny', '', '1', '0', '1467421832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10618', 'btc_cny', '', '1', '0', '1467421892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10640', 'ltc_cny', '', '1', '0', '1467350142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10641', 'ltc_cny', '', '1', '0', '1467350202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10642', 'ltc_cny', '', '1', '0', '1467350262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10643', 'ltc_cny', '', '1', '0', '1467350322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10644', 'ltc_cny', '', '1', '0', '1467350382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10645', 'ltc_cny', '', '1', '0', '1467350442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10646', 'ltc_cny', '', '1', '0', '1467350502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10647', 'ltc_cny', '', '1', '0', '1467350562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10648', 'ltc_cny', '', '1', '0', '1467350622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10649', 'ltc_cny', '', '1', '0', '1467350682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10650', 'ltc_cny', '', '1', '0', '1467350742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10651', 'ltc_cny', '', '1', '0', '1467350802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10652', 'ltc_cny', '', '1', '0', '1467350862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10653', 'ltc_cny', '', '1', '0', '1467350922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10654', 'ltc_cny', '', '1', '0', '1467350982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10655', 'ltc_cny', '', '1', '0', '1467351042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10656', 'ltc_cny', '', '1', '0', '1467351102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10657', 'ltc_cny', '', '1', '0', '1467351162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10658', 'ltc_cny', '', '1', '0', '1467351222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10659', 'ltc_cny', '', '1', '0', '1467351282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10660', 'ltc_cny', '', '1', '0', '1467351342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10703', 'btc_cny', '', '1', '0', '1467421892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10704', 'btc_cny', '', '1', '0', '1467421952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10705', 'btc_cny', '', '1', '0', '1467422012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10706', 'btc_cny', '', '1', '0', '1467422072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10707', 'btc_cny', '', '1', '0', '1467422132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10708', 'btc_cny', '', '1', '0', '1467422192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10709', 'btc_cny', '', '1', '0', '1467422252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10710', 'btc_cny', '', '1', '0', '1467422312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10711', 'btc_cny', '', '1', '0', '1467422372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10712', 'btc_cny', '', '1', '0', '1467422432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10713', 'btc_cny', '', '1', '0', '1467422492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10714', 'btc_cny', '', '1', '0', '1467422552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10715', 'btc_cny', '', '1', '0', '1467422612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10716', 'btc_cny', '', '1', '0', '1467422672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10717', 'btc_cny', '', '1', '0', '1467422732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10718', 'btc_cny', '', '1', '0', '1467422792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10719', 'btc_cny', '', '1', '0', '1467422852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10720', 'btc_cny', '', '1', '0', '1467422912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10721', 'btc_cny', '', '1', '0', '1467422972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10722', 'btc_cny', '', '1', '0', '1467423032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10723', 'btc_cny', '', '1', '0', '1467423092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10745', 'ltc_cny', '', '1', '0', '1467351342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10746', 'ltc_cny', '', '1', '0', '1467351402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10747', 'ltc_cny', '', '1', '0', '1467351462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10748', 'ltc_cny', '', '1', '0', '1467351522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10749', 'ltc_cny', '', '1', '0', '1467351582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10750', 'ltc_cny', '', '1', '0', '1467351642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10751', 'ltc_cny', '', '1', '0', '1467351702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10752', 'ltc_cny', '', '1', '0', '1467351762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10753', 'ltc_cny', '', '1', '0', '1467351822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10754', 'ltc_cny', '', '1', '0', '1467351882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10755', 'ltc_cny', '', '1', '0', '1467351942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10756', 'ltc_cny', '', '1', '0', '1467352002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10757', 'ltc_cny', '', '1', '0', '1467352062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10758', 'ltc_cny', '', '1', '0', '1467352122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10759', 'ltc_cny', '', '1', '0', '1467352182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10760', 'ltc_cny', '', '1', '0', '1467352242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10761', 'ltc_cny', '', '1', '0', '1467352302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10762', 'ltc_cny', '', '1', '0', '1467352362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10763', 'ltc_cny', '', '1', '0', '1467352422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10764', 'ltc_cny', '', '1', '0', '1467352482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10765', 'ltc_cny', '', '1', '0', '1467352542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10808', 'btc_cny', '', '1', '0', '1467423092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10809', 'btc_cny', '', '1', '0', '1467423152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10810', 'btc_cny', '', '1', '0', '1467423212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10811', 'btc_cny', '', '1', '0', '1467423272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10812', 'btc_cny', '', '1', '0', '1467423332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10813', 'btc_cny', '', '1', '0', '1467423392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10814', 'btc_cny', '', '1', '0', '1467423452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10815', 'btc_cny', '', '1', '0', '1467423512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10816', 'btc_cny', '', '1', '0', '1467423572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10817', 'btc_cny', '', '1', '0', '1467423632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10818', 'btc_cny', '', '1', '0', '1467423692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10819', 'btc_cny', '', '1', '0', '1467423752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10820', 'btc_cny', '', '1', '0', '1467423812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10821', 'btc_cny', '', '1', '0', '1467423872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10822', 'btc_cny', '', '1', '0', '1467423932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10823', 'btc_cny', '', '1', '0', '1467423992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10824', 'btc_cny', '', '1', '0', '1467424052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10825', 'btc_cny', '', '1', '0', '1467424112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10826', 'btc_cny', '', '1', '0', '1467424172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10827', 'btc_cny', '', '1', '0', '1467424232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10828', 'btc_cny', '', '1', '0', '1467424292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10850', 'btc_cny', '', '60', '0', '1467612000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10851', 'btc_cny', '', '120', '0', '1467612000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10852', 'btc_cny', '', '360', '0', '1467612000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10853', 'ltc_cny', '', '1', '0', '1467352542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10854', 'ltc_cny', '', '1', '0', '1467352602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10855', 'ltc_cny', '', '1', '0', '1467352662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10856', 'ltc_cny', '', '1', '0', '1467352722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10857', 'ltc_cny', '', '1', '0', '1467352782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10858', 'ltc_cny', '', '1', '0', '1467352842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10859', 'ltc_cny', '', '1', '0', '1467352902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10860', 'ltc_cny', '', '1', '0', '1467352962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10861', 'ltc_cny', '', '1', '0', '1467353022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10862', 'ltc_cny', '', '1', '0', '1467353082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10863', 'ltc_cny', '', '1', '0', '1467353142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10864', 'ltc_cny', '', '1', '0', '1467353202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10865', 'ltc_cny', '', '1', '0', '1467353262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10866', 'ltc_cny', '', '1', '0', '1467353322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10867', 'ltc_cny', '', '1', '0', '1467353382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10868', 'ltc_cny', '', '1', '0', '1467353442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10869', 'ltc_cny', '', '1', '0', '1467353502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10870', 'ltc_cny', '', '1', '0', '1467353562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10871', 'ltc_cny', '', '1', '0', '1467353622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10872', 'ltc_cny', '', '1', '0', '1467353682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10873', 'ltc_cny', '', '1', '0', '1467353742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10916', 'ltc_cny', '', '60', '0', '1467612000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10917', 'ltc_cny', '', '120', '0', '1467612000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10918', 'ltc_cny', '', '360', '0', '1467612000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10919', 'btc_cny', '', '1', '0', '1467424292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10920', 'btc_cny', '', '1', '0', '1467424352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10921', 'btc_cny', '', '1', '0', '1467424412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10922', 'btc_cny', '', '1', '0', '1467424472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10923', 'btc_cny', '', '1', '0', '1467424532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10924', 'btc_cny', '', '1', '0', '1467424592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10925', 'btc_cny', '', '1', '0', '1467424652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10926', 'btc_cny', '', '1', '0', '1467424712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10927', 'btc_cny', '', '1', '0', '1467424772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10928', 'btc_cny', '', '1', '0', '1467424832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10929', 'btc_cny', '', '1', '0', '1467424892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10930', 'btc_cny', '', '1', '0', '1467424952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10931', 'btc_cny', '', '1', '0', '1467425012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10932', 'btc_cny', '', '1', '0', '1467425072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10933', 'btc_cny', '', '1', '0', '1467425132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10934', 'btc_cny', '', '1', '0', '1467425192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10935', 'btc_cny', '', '1', '0', '1467425252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10936', 'btc_cny', '', '1', '0', '1467425312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10937', 'btc_cny', '', '1', '0', '1467425372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10938', 'btc_cny', '', '1', '0', '1467425432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10939', 'btc_cny', '', '1', '0', '1467425492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10961', 'ltc_cny', '', '1', '0', '1467353742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10962', 'ltc_cny', '', '1', '0', '1467353802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10963', 'ltc_cny', '', '1', '0', '1467353862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10964', 'ltc_cny', '', '1', '0', '1467353922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10965', 'ltc_cny', '', '1', '0', '1467353982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10966', 'ltc_cny', '', '1', '0', '1467354042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10967', 'ltc_cny', '', '1', '0', '1467354102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10968', 'ltc_cny', '', '1', '0', '1467354162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10969', 'ltc_cny', '', '1', '0', '1467354222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10970', 'ltc_cny', '', '1', '0', '1467354282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10971', 'ltc_cny', '', '1', '0', '1467354342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10972', 'ltc_cny', '', '1', '0', '1467354402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10973', 'ltc_cny', '', '1', '0', '1467354462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10974', 'ltc_cny', '', '1', '0', '1467354522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10975', 'ltc_cny', '', '1', '0', '1467354582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10976', 'ltc_cny', '', '1', '0', '1467354642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10977', 'ltc_cny', '', '1', '0', '1467354702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10978', 'ltc_cny', '', '1', '0', '1467354762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10979', 'ltc_cny', '', '1', '0', '1467354822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10980', 'ltc_cny', '', '1', '0', '1467354882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('10981', 'ltc_cny', '', '1', '0', '1467354942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11020', 'ltc_cny', '[1467608700,\"45.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\"]', '5', '0', '1467608700', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11021', 'ltc_cny', '', '5', '0', '1467609000', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11022', 'ltc_cny', '', '5', '0', '1467609300', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11023', 'ltc_cny', '', '5', '0', '1467609600', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11024', 'btc_cny', '', '1', '0', '1467425492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11025', 'btc_cny', '', '1', '0', '1467425552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11026', 'btc_cny', '', '1', '0', '1467425612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11027', 'btc_cny', '', '1', '0', '1467425672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11028', 'btc_cny', '', '1', '0', '1467425732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11029', 'btc_cny', '', '1', '0', '1467425792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11030', 'btc_cny', '', '1', '0', '1467425852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11031', 'btc_cny', '', '1', '0', '1467425912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11032', 'btc_cny', '', '1', '0', '1467425972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11033', 'btc_cny', '', '1', '0', '1467426032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11034', 'btc_cny', '', '1', '0', '1467426092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11035', 'btc_cny', '', '1', '0', '1467426152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11036', 'btc_cny', '', '1', '0', '1467426212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11037', 'btc_cny', '', '1', '0', '1467426272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11038', 'btc_cny', '', '1', '0', '1467426332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11039', 'btc_cny', '', '1', '0', '1467426392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11040', 'btc_cny', '', '1', '0', '1467426452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11041', 'btc_cny', '', '1', '0', '1467426512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11042', 'btc_cny', '', '1', '0', '1467426572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11043', 'btc_cny', '', '1', '0', '1467426632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11044', 'btc_cny', '', '1', '0', '1467426692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11066', 'ltc_cny', '', '1', '0', '1467354942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11067', 'ltc_cny', '', '1', '0', '1467355002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11068', 'ltc_cny', '', '1', '0', '1467355062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11069', 'ltc_cny', '', '1', '0', '1467355122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11070', 'ltc_cny', '', '1', '0', '1467355182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11071', 'ltc_cny', '', '1', '0', '1467355242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11072', 'ltc_cny', '', '1', '0', '1467355302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11073', 'ltc_cny', '', '1', '0', '1467355362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11074', 'ltc_cny', '', '1', '0', '1467355422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11075', 'ltc_cny', '', '1', '0', '1467355482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11076', 'ltc_cny', '', '1', '0', '1467355542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11077', 'ltc_cny', '', '1', '0', '1467355602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11078', 'ltc_cny', '', '1', '0', '1467355662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11079', 'ltc_cny', '', '1', '0', '1467355722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11080', 'ltc_cny', '', '1', '0', '1467355782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11081', 'ltc_cny', '', '1', '0', '1467355842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11082', 'ltc_cny', '', '1', '0', '1467355902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11083', 'ltc_cny', '', '1', '0', '1467355962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11084', 'ltc_cny', '', '1', '0', '1467356022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11085', 'ltc_cny', '', '1', '0', '1467356082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11086', 'ltc_cny', '', '1', '0', '1467356142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11108', 'btc_cny', '', '1', '0', '1467426692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11109', 'btc_cny', '', '1', '0', '1467426752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11110', 'btc_cny', '', '1', '0', '1467426812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11111', 'btc_cny', '', '1', '0', '1467426872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11112', 'btc_cny', '', '1', '0', '1467426932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11113', 'btc_cny', '', '1', '0', '1467426992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11114', 'btc_cny', '', '1', '0', '1467427052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11115', 'btc_cny', '', '1', '0', '1467427112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11116', 'btc_cny', '', '1', '0', '1467427172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11117', 'btc_cny', '', '1', '0', '1467427232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11118', 'btc_cny', '', '1', '0', '1467427292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11119', 'btc_cny', '', '1', '0', '1467427352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11120', 'btc_cny', '', '1', '0', '1467427412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11121', 'btc_cny', '', '1', '0', '1467427472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11122', 'btc_cny', '', '1', '0', '1467427532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11123', 'btc_cny', '', '1', '0', '1467427592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11124', 'btc_cny', '', '1', '0', '1467427652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11125', 'btc_cny', '', '1', '0', '1467427712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11126', 'btc_cny', '', '1', '0', '1467427772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11127', 'btc_cny', '', '1', '0', '1467427832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11128', 'btc_cny', '', '1', '0', '1467427892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11150', 'ltc_cny', '', '1', '0', '1467356142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11151', 'ltc_cny', '', '1', '0', '1467356202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11152', 'ltc_cny', '', '1', '0', '1467356262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11153', 'ltc_cny', '', '1', '0', '1467356322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11154', 'ltc_cny', '', '1', '0', '1467356382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11155', 'ltc_cny', '', '1', '0', '1467356442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11156', 'ltc_cny', '', '1', '0', '1467356502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11157', 'ltc_cny', '', '1', '0', '1467356562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11158', 'ltc_cny', '', '1', '0', '1467356622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11159', 'ltc_cny', '', '1', '0', '1467356682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11160', 'ltc_cny', '', '1', '0', '1467356742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11161', 'ltc_cny', '', '1', '0', '1467356802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11162', 'ltc_cny', '', '1', '0', '1467356862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11163', 'ltc_cny', '', '1', '0', '1467356922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11164', 'ltc_cny', '', '1', '0', '1467356982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11165', 'ltc_cny', '', '1', '0', '1467357042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11166', 'ltc_cny', '', '1', '0', '1467357102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11167', 'ltc_cny', '', '1', '0', '1467357162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11168', 'ltc_cny', '', '1', '0', '1467357222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11169', 'ltc_cny', '', '1', '0', '1467357282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11170', 'ltc_cny', '', '1', '0', '1467357342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11192', 'btc_cny', '', '1', '0', '1467427892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11193', 'btc_cny', '', '1', '0', '1467427952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11194', 'btc_cny', '', '1', '0', '1467428012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11195', 'btc_cny', '', '1', '0', '1467428072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11196', 'btc_cny', '', '1', '0', '1467428132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11197', 'btc_cny', '', '1', '0', '1467428192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11198', 'btc_cny', '', '1', '0', '1467428252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11199', 'btc_cny', '', '1', '0', '1467428312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11200', 'btc_cny', '', '1', '0', '1467428372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11201', 'btc_cny', '', '1', '0', '1467428432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11202', 'btc_cny', '', '1', '0', '1467428492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11203', 'btc_cny', '', '1', '0', '1467428552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11204', 'btc_cny', '', '1', '0', '1467428612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11205', 'btc_cny', '', '1', '0', '1467428672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11206', 'btc_cny', '', '1', '0', '1467428732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11207', 'btc_cny', '', '1', '0', '1467428792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11208', 'btc_cny', '', '1', '0', '1467428852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11209', 'btc_cny', '', '1', '0', '1467428912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11210', 'btc_cny', '', '1', '0', '1467428972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11211', 'btc_cny', '', '1', '0', '1467429032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11212', 'btc_cny', '', '1', '0', '1467429092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11234', 'ltc_cny', '', '1', '0', '1467357342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11235', 'ltc_cny', '', '1', '0', '1467357402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11236', 'ltc_cny', '', '1', '0', '1467357462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11237', 'ltc_cny', '', '1', '0', '1467357522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11238', 'ltc_cny', '', '1', '0', '1467357582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11239', 'ltc_cny', '', '1', '0', '1467357642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11240', 'ltc_cny', '', '1', '0', '1467357702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11241', 'ltc_cny', '', '1', '0', '1467357762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11242', 'ltc_cny', '', '1', '0', '1467357822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11243', 'ltc_cny', '', '1', '0', '1467357882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11244', 'ltc_cny', '', '1', '0', '1467357942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11245', 'ltc_cny', '', '1', '0', '1467358002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11246', 'ltc_cny', '', '1', '0', '1467358062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11247', 'ltc_cny', '', '1', '0', '1467358122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11248', 'ltc_cny', '', '1', '0', '1467358182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11249', 'ltc_cny', '', '1', '0', '1467358242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11250', 'ltc_cny', '', '1', '0', '1467358302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11251', 'ltc_cny', '', '1', '0', '1467358362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11252', 'ltc_cny', '', '1', '0', '1467358422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11253', 'ltc_cny', '', '1', '0', '1467358482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11254', 'ltc_cny', '', '1', '0', '1467358542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11276', 'btc_cny', '', '1', '0', '1467429092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11277', 'btc_cny', '', '1', '0', '1467429152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11278', 'btc_cny', '', '1', '0', '1467429212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11279', 'btc_cny', '', '1', '0', '1467429272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11280', 'btc_cny', '', '1', '0', '1467429332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11281', 'btc_cny', '', '1', '0', '1467429392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11282', 'btc_cny', '', '1', '0', '1467429452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11283', 'btc_cny', '', '1', '0', '1467429512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11284', 'btc_cny', '', '1', '0', '1467429572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11285', 'btc_cny', '', '1', '0', '1467429632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11286', 'btc_cny', '', '1', '0', '1467429692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11287', 'btc_cny', '', '1', '0', '1467429752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11288', 'btc_cny', '', '1', '0', '1467429812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11289', 'btc_cny', '', '1', '0', '1467429872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11290', 'btc_cny', '', '1', '0', '1467429932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11291', 'btc_cny', '', '1', '0', '1467429992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11292', 'btc_cny', '', '1', '0', '1467430052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11293', 'btc_cny', '', '1', '0', '1467430112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11294', 'btc_cny', '', '1', '0', '1467430172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11295', 'btc_cny', '', '1', '0', '1467430232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11296', 'btc_cny', '', '1', '0', '1467430292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11318', 'ltc_cny', '', '1', '0', '1467358542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11319', 'ltc_cny', '', '1', '0', '1467358602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11320', 'ltc_cny', '', '1', '0', '1467358662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11321', 'ltc_cny', '', '1', '0', '1467358722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11322', 'ltc_cny', '', '1', '0', '1467358782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11323', 'ltc_cny', '', '1', '0', '1467358842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11324', 'ltc_cny', '', '1', '0', '1467358902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11325', 'ltc_cny', '', '1', '0', '1467358962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11326', 'ltc_cny', '', '1', '0', '1467359022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11327', 'ltc_cny', '', '1', '0', '1467359082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11328', 'ltc_cny', '', '1', '0', '1467359142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11329', 'ltc_cny', '', '1', '0', '1467359202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11330', 'ltc_cny', '', '1', '0', '1467359262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11331', 'ltc_cny', '', '1', '0', '1467359322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11332', 'ltc_cny', '', '1', '0', '1467359382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11333', 'ltc_cny', '', '1', '0', '1467359442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11334', 'ltc_cny', '', '1', '0', '1467359502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11335', 'ltc_cny', '', '1', '0', '1467359562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11336', 'ltc_cny', '', '1', '0', '1467359622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11337', 'ltc_cny', '', '1', '0', '1467359682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11338', 'ltc_cny', '', '1', '0', '1467359742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11360', 'btc_cny', '', '1', '0', '1467430292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11361', 'btc_cny', '', '1', '0', '1467430352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11362', 'btc_cny', '', '1', '0', '1467430412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11363', 'btc_cny', '', '1', '0', '1467430472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11364', 'btc_cny', '', '1', '0', '1467430532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11365', 'btc_cny', '', '1', '0', '1467430592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11366', 'btc_cny', '', '1', '0', '1467430652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11367', 'btc_cny', '', '1', '0', '1467430712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11368', 'btc_cny', '', '1', '0', '1467430772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11369', 'btc_cny', '', '1', '0', '1467430832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11370', 'btc_cny', '', '1', '0', '1467430892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11371', 'btc_cny', '', '1', '0', '1467430952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11372', 'btc_cny', '', '1', '0', '1467431012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11373', 'btc_cny', '', '1', '0', '1467431072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11374', 'btc_cny', '', '1', '0', '1467431132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11375', 'btc_cny', '', '1', '0', '1467431192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11376', 'btc_cny', '', '1', '0', '1467431252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11377', 'btc_cny', '', '1', '0', '1467431312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11378', 'btc_cny', '', '1', '0', '1467431372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11379', 'btc_cny', '', '1', '0', '1467431432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11380', 'btc_cny', '', '1', '0', '1467431492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11402', 'ltc_cny', '', '1', '0', '1467359742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11403', 'ltc_cny', '', '1', '0', '1467359802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11404', 'ltc_cny', '', '1', '0', '1467359862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11405', 'ltc_cny', '', '1', '0', '1467359922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11406', 'ltc_cny', '', '1', '0', '1467359982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11407', 'ltc_cny', '', '1', '0', '1467360042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11408', 'ltc_cny', '', '1', '0', '1467360102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11409', 'ltc_cny', '', '1', '0', '1467360162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11410', 'ltc_cny', '', '1', '0', '1467360222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11411', 'ltc_cny', '', '1', '0', '1467360282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11412', 'ltc_cny', '', '1', '0', '1467360342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11413', 'ltc_cny', '', '1', '0', '1467360402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11414', 'ltc_cny', '', '1', '0', '1467360462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11415', 'ltc_cny', '', '1', '0', '1467360522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11416', 'ltc_cny', '', '1', '0', '1467360582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11417', 'ltc_cny', '', '1', '0', '1467360642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11418', 'ltc_cny', '', '1', '0', '1467360702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11419', 'ltc_cny', '', '1', '0', '1467360762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11420', 'ltc_cny', '', '1', '0', '1467360822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11421', 'ltc_cny', '', '1', '0', '1467360882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11422', 'ltc_cny', '', '1', '0', '1467360942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11444', 'btc_cny', '', '1', '0', '1467431492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11445', 'btc_cny', '', '1', '0', '1467431552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11446', 'btc_cny', '', '1', '0', '1467431612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11447', 'btc_cny', '', '1', '0', '1467431672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11448', 'btc_cny', '', '1', '0', '1467431732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11449', 'btc_cny', '', '1', '0', '1467431792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11450', 'btc_cny', '', '1', '0', '1467431852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11451', 'btc_cny', '', '1', '0', '1467431912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11452', 'btc_cny', '', '1', '0', '1467431972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11453', 'btc_cny', '', '1', '0', '1467432032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11454', 'btc_cny', '', '1', '0', '1467432092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11455', 'btc_cny', '', '1', '0', '1467432152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11456', 'btc_cny', '', '1', '0', '1467432212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11457', 'btc_cny', '', '1', '0', '1467432272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11458', 'btc_cny', '', '1', '0', '1467432332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11459', 'btc_cny', '', '1', '0', '1467432392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11460', 'btc_cny', '', '1', '0', '1467432452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11461', 'btc_cny', '', '1', '0', '1467432512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11462', 'btc_cny', '', '1', '0', '1467432572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11463', 'btc_cny', '', '1', '0', '1467432632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11464', 'btc_cny', '', '1', '0', '1467432692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11486', 'ltc_cny', '', '1', '0', '1467360942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11487', 'ltc_cny', '', '1', '0', '1467361002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11488', 'ltc_cny', '', '1', '0', '1467361062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11489', 'ltc_cny', '', '1', '0', '1467361122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11490', 'ltc_cny', '', '1', '0', '1467361182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11491', 'ltc_cny', '', '1', '0', '1467361242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11492', 'ltc_cny', '', '1', '0', '1467361302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11493', 'ltc_cny', '', '1', '0', '1467361362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11494', 'ltc_cny', '', '1', '0', '1467361422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11495', 'ltc_cny', '', '1', '0', '1467361482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11496', 'ltc_cny', '', '1', '0', '1467361542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11497', 'ltc_cny', '', '1', '0', '1467361602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11498', 'ltc_cny', '', '1', '0', '1467361662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11499', 'ltc_cny', '', '1', '0', '1467361722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11500', 'ltc_cny', '', '1', '0', '1467361782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11501', 'ltc_cny', '', '1', '0', '1467361842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11502', 'ltc_cny', '', '1', '0', '1467361902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11503', 'ltc_cny', '', '1', '0', '1467361962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11504', 'ltc_cny', '', '1', '0', '1467362022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11505', 'ltc_cny', '', '1', '0', '1467362082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11506', 'ltc_cny', '', '1', '0', '1467362142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11528', 'btc_cny', '', '1', '0', '1467432692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11529', 'btc_cny', '', '1', '0', '1467432752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11530', 'btc_cny', '', '1', '0', '1467432812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11531', 'btc_cny', '', '1', '0', '1467432872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11532', 'btc_cny', '', '1', '0', '1467432932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11533', 'btc_cny', '', '1', '0', '1467432992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11534', 'btc_cny', '', '1', '0', '1467433052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11535', 'btc_cny', '', '1', '0', '1467433112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11536', 'btc_cny', '', '1', '0', '1467433172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11537', 'btc_cny', '', '1', '0', '1467433232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11538', 'btc_cny', '', '1', '0', '1467433292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11539', 'btc_cny', '', '1', '0', '1467433352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11540', 'btc_cny', '', '1', '0', '1467433412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11541', 'btc_cny', '', '1', '0', '1467433472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11542', 'btc_cny', '', '1', '0', '1467433532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11543', 'btc_cny', '', '1', '0', '1467433592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11544', 'btc_cny', '', '1', '0', '1467433652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11545', 'btc_cny', '', '1', '0', '1467433712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11546', 'btc_cny', '', '1', '0', '1467433772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11547', 'btc_cny', '', '1', '0', '1467433832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11548', 'btc_cny', '', '1', '0', '1467433892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11570', 'ltc_cny', '', '1', '0', '1467362142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11571', 'ltc_cny', '', '1', '0', '1467362202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11572', 'ltc_cny', '', '1', '0', '1467362262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11573', 'ltc_cny', '', '1', '0', '1467362322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11574', 'ltc_cny', '', '1', '0', '1467362382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11575', 'ltc_cny', '', '1', '0', '1467362442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11576', 'ltc_cny', '', '1', '0', '1467362502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11577', 'ltc_cny', '', '1', '0', '1467362562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11578', 'ltc_cny', '', '1', '0', '1467362622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11579', 'ltc_cny', '', '1', '0', '1467362682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11580', 'ltc_cny', '', '1', '0', '1467362742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11581', 'ltc_cny', '', '1', '0', '1467362802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11582', 'ltc_cny', '', '1', '0', '1467362862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11583', 'ltc_cny', '', '1', '0', '1467362922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11584', 'ltc_cny', '', '1', '0', '1467362982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11585', 'ltc_cny', '', '1', '0', '1467363042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11586', 'ltc_cny', '', '1', '0', '1467363102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11587', 'ltc_cny', '', '1', '0', '1467363162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11588', 'ltc_cny', '', '1', '0', '1467363222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11589', 'ltc_cny', '', '1', '0', '1467363282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11590', 'ltc_cny', '', '1', '0', '1467363342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11612', 'btc_cny', '', '1', '0', '1467433892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11613', 'btc_cny', '', '1', '0', '1467433952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11614', 'btc_cny', '', '1', '0', '1467434012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11615', 'btc_cny', '', '1', '0', '1467434072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11616', 'btc_cny', '', '1', '0', '1467434132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11617', 'btc_cny', '', '1', '0', '1467434192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11618', 'btc_cny', '', '1', '0', '1467434252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11619', 'btc_cny', '', '1', '0', '1467434312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11620', 'btc_cny', '', '1', '0', '1467434372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11621', 'btc_cny', '', '1', '0', '1467434432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11622', 'btc_cny', '', '1', '0', '1467434492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11623', 'btc_cny', '', '1', '0', '1467434552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11624', 'btc_cny', '', '1', '0', '1467434612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11625', 'btc_cny', '', '1', '0', '1467434672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11626', 'btc_cny', '', '1', '0', '1467434732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11627', 'btc_cny', '', '1', '0', '1467434792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11628', 'btc_cny', '', '1', '0', '1467434852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11629', 'btc_cny', '', '1', '0', '1467434912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11630', 'btc_cny', '', '1', '0', '1467434972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11631', 'btc_cny', '', '1', '0', '1467435032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11632', 'btc_cny', '', '1', '0', '1467435092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11654', 'ltc_cny', '', '1', '0', '1467363342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11655', 'ltc_cny', '', '1', '0', '1467363402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11656', 'ltc_cny', '', '1', '0', '1467363462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11657', 'ltc_cny', '', '1', '0', '1467363522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11658', 'ltc_cny', '', '1', '0', '1467363582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11659', 'ltc_cny', '', '1', '0', '1467363642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11660', 'ltc_cny', '', '1', '0', '1467363702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11661', 'ltc_cny', '', '1', '0', '1467363762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11662', 'ltc_cny', '', '1', '0', '1467363822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11663', 'ltc_cny', '', '1', '0', '1467363882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11664', 'ltc_cny', '', '1', '0', '1467363942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11665', 'ltc_cny', '', '1', '0', '1467364002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11666', 'ltc_cny', '', '1', '0', '1467364062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11667', 'ltc_cny', '', '1', '0', '1467364122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11668', 'ltc_cny', '', '1', '0', '1467364182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11669', 'ltc_cny', '', '1', '0', '1467364242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11670', 'ltc_cny', '', '1', '0', '1467364302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11671', 'ltc_cny', '', '1', '0', '1467364362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11672', 'ltc_cny', '', '1', '0', '1467364422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11673', 'ltc_cny', '', '1', '0', '1467364482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11674', 'ltc_cny', '', '1', '0', '1467364542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11696', 'btc_cny', '', '1', '0', '1467435092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11697', 'btc_cny', '', '1', '0', '1467435152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11698', 'btc_cny', '', '1', '0', '1467435212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11699', 'btc_cny', '', '1', '0', '1467435272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11700', 'btc_cny', '', '1', '0', '1467435332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11701', 'btc_cny', '', '1', '0', '1467435392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11702', 'btc_cny', '', '1', '0', '1467435452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11703', 'btc_cny', '', '1', '0', '1467435512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11704', 'btc_cny', '', '1', '0', '1467435572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11705', 'btc_cny', '', '1', '0', '1467435632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11706', 'btc_cny', '', '1', '0', '1467435692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11707', 'btc_cny', '', '1', '0', '1467435752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11708', 'btc_cny', '', '1', '0', '1467435812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11709', 'btc_cny', '', '1', '0', '1467435872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11710', 'btc_cny', '', '1', '0', '1467435932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11711', 'btc_cny', '', '1', '0', '1467435992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11712', 'btc_cny', '', '1', '0', '1467436052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11713', 'btc_cny', '', '1', '0', '1467436112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11714', 'btc_cny', '', '1', '0', '1467436172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11715', 'btc_cny', '', '1', '0', '1467436232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11716', 'btc_cny', '', '1', '0', '1467436292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11738', 'ltc_cny', '', '1', '0', '1467364542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11739', 'ltc_cny', '', '1', '0', '1467364602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11740', 'ltc_cny', '', '1', '0', '1467364662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11741', 'ltc_cny', '', '1', '0', '1467364722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11742', 'ltc_cny', '', '1', '0', '1467364782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11743', 'ltc_cny', '', '1', '0', '1467364842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11744', 'ltc_cny', '', '1', '0', '1467364902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11745', 'ltc_cny', '', '1', '0', '1467364962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11746', 'ltc_cny', '', '1', '0', '1467365022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11747', 'ltc_cny', '', '1', '0', '1467365082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11748', 'ltc_cny', '', '1', '0', '1467365142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11749', 'ltc_cny', '', '1', '0', '1467365202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11750', 'ltc_cny', '', '1', '0', '1467365262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11751', 'ltc_cny', '', '1', '0', '1467365322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11752', 'ltc_cny', '', '1', '0', '1467365382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11753', 'ltc_cny', '', '1', '0', '1467365442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11754', 'ltc_cny', '', '1', '0', '1467365502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11755', 'ltc_cny', '', '1', '0', '1467365562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11756', 'ltc_cny', '', '1', '0', '1467365622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11757', 'ltc_cny', '', '1', '0', '1467365682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11758', 'ltc_cny', '', '1', '0', '1467365742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11780', 'btc_cny', '', '1', '0', '1467436292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11781', 'btc_cny', '', '1', '0', '1467436352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11782', 'btc_cny', '', '1', '0', '1467436412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11783', 'btc_cny', '', '1', '0', '1467436472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11784', 'btc_cny', '', '1', '0', '1467436532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11785', 'btc_cny', '', '1', '0', '1467436592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11786', 'btc_cny', '', '1', '0', '1467436652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11787', 'btc_cny', '', '1', '0', '1467436712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11788', 'btc_cny', '', '1', '0', '1467436772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11789', 'btc_cny', '', '1', '0', '1467436832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11790', 'btc_cny', '', '1', '0', '1467436892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11791', 'btc_cny', '', '1', '0', '1467436952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11792', 'btc_cny', '', '1', '0', '1467437012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11793', 'btc_cny', '', '1', '0', '1467437072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11794', 'btc_cny', '', '1', '0', '1467437132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11795', 'btc_cny', '', '1', '0', '1467437192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11796', 'btc_cny', '', '1', '0', '1467437252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11797', 'btc_cny', '', '1', '0', '1467437312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11798', 'btc_cny', '', '1', '0', '1467437372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11799', 'btc_cny', '', '1', '0', '1467437432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11800', 'btc_cny', '', '1', '0', '1467437492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11822', 'ltc_cny', '', '1', '0', '1467365742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11823', 'ltc_cny', '', '1', '0', '1467365802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11824', 'ltc_cny', '', '1', '0', '1467365862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11825', 'ltc_cny', '', '1', '0', '1467365922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11826', 'ltc_cny', '', '1', '0', '1467365982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11827', 'ltc_cny', '', '1', '0', '1467366042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11828', 'ltc_cny', '', '1', '0', '1467366102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11829', 'ltc_cny', '', '1', '0', '1467366162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11830', 'ltc_cny', '', '1', '0', '1467366222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11831', 'ltc_cny', '', '1', '0', '1467366282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11832', 'ltc_cny', '', '1', '0', '1467366342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11833', 'ltc_cny', '', '1', '0', '1467366402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11834', 'ltc_cny', '', '1', '0', '1467366462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11835', 'ltc_cny', '', '1', '0', '1467366522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11836', 'ltc_cny', '', '1', '0', '1467366582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11837', 'ltc_cny', '', '1', '0', '1467366642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11838', 'ltc_cny', '', '1', '0', '1467366702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11839', 'ltc_cny', '', '1', '0', '1467366762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11840', 'ltc_cny', '', '1', '0', '1467366822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11841', 'ltc_cny', '', '1', '0', '1467366882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11842', 'ltc_cny', '', '1', '0', '1467366942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11864', 'btc_cny', '', '1', '0', '1467437492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11865', 'btc_cny', '', '1', '0', '1467437552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11866', 'btc_cny', '', '1', '0', '1467437612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11867', 'btc_cny', '', '1', '0', '1467437672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11868', 'btc_cny', '', '1', '0', '1467437732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11869', 'btc_cny', '', '1', '0', '1467437792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11870', 'btc_cny', '', '1', '0', '1467437852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11871', 'btc_cny', '', '1', '0', '1467437912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11872', 'btc_cny', '', '1', '0', '1467437972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11873', 'btc_cny', '', '1', '0', '1467438032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11874', 'btc_cny', '', '1', '0', '1467438092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11875', 'btc_cny', '', '1', '0', '1467438152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11876', 'btc_cny', '', '1', '0', '1467438212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11877', 'btc_cny', '', '1', '0', '1467438272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11878', 'btc_cny', '', '1', '0', '1467438332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11879', 'btc_cny', '', '1', '0', '1467438392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11880', 'btc_cny', '', '1', '0', '1467438452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11881', 'btc_cny', '', '1', '0', '1467438512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11882', 'btc_cny', '', '1', '0', '1467438572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11883', 'btc_cny', '', '1', '0', '1467438632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11884', 'btc_cny', '', '1', '0', '1467438692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11906', 'ltc_cny', '', '1', '0', '1467366942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11907', 'ltc_cny', '', '1', '0', '1467367002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11908', 'ltc_cny', '', '1', '0', '1467367062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11909', 'ltc_cny', '', '1', '0', '1467367122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11910', 'ltc_cny', '', '1', '0', '1467367182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11911', 'ltc_cny', '', '1', '0', '1467367242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11912', 'ltc_cny', '', '1', '0', '1467367302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11913', 'ltc_cny', '', '1', '0', '1467367362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11914', 'ltc_cny', '', '1', '0', '1467367422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11915', 'ltc_cny', '', '1', '0', '1467367482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11916', 'ltc_cny', '', '1', '0', '1467367542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11917', 'ltc_cny', '', '1', '0', '1467367602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11918', 'ltc_cny', '', '1', '0', '1467367662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11919', 'ltc_cny', '', '1', '0', '1467367722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11920', 'ltc_cny', '', '1', '0', '1467367782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11921', 'ltc_cny', '', '1', '0', '1467367842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11922', 'ltc_cny', '', '1', '0', '1467367902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11923', 'ltc_cny', '', '1', '0', '1467367962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11924', 'ltc_cny', '', '1', '0', '1467368022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11925', 'ltc_cny', '', '1', '0', '1467368082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11926', 'ltc_cny', '', '1', '0', '1467368142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11948', 'btc_cny', '', '1', '0', '1467438692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11949', 'btc_cny', '', '1', '0', '1467438752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11950', 'btc_cny', '', '1', '0', '1467438812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11951', 'btc_cny', '', '1', '0', '1467438872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11952', 'btc_cny', '', '1', '0', '1467438932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11953', 'btc_cny', '', '1', '0', '1467438992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11954', 'btc_cny', '', '1', '0', '1467439052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11955', 'btc_cny', '', '1', '0', '1467439112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11956', 'btc_cny', '', '1', '0', '1467439172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11957', 'btc_cny', '', '1', '0', '1467439232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11958', 'btc_cny', '', '1', '0', '1467439292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11959', 'btc_cny', '', '1', '0', '1467439352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11960', 'btc_cny', '', '1', '0', '1467439412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11961', 'btc_cny', '', '1', '0', '1467439472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11962', 'btc_cny', '', '1', '0', '1467439532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11963', 'btc_cny', '', '1', '0', '1467439592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11964', 'btc_cny', '', '1', '0', '1467439652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11965', 'btc_cny', '', '1', '0', '1467439712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11966', 'btc_cny', '', '1', '0', '1467439772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11967', 'btc_cny', '', '1', '0', '1467439832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11968', 'btc_cny', '', '1', '0', '1467439892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11990', 'ltc_cny', '', '1', '0', '1467368142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11991', 'ltc_cny', '', '1', '0', '1467368202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11992', 'ltc_cny', '', '1', '0', '1467368262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11993', 'ltc_cny', '', '1', '0', '1467368322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11994', 'ltc_cny', '', '1', '0', '1467368382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11995', 'ltc_cny', '', '1', '0', '1467368442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11996', 'ltc_cny', '', '1', '0', '1467368502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11997', 'ltc_cny', '', '1', '0', '1467368562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11998', 'ltc_cny', '', '1', '0', '1467368622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('11999', 'ltc_cny', '', '1', '0', '1467368682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12000', 'ltc_cny', '', '1', '0', '1467368742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12001', 'ltc_cny', '', '1', '0', '1467368802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12002', 'ltc_cny', '', '1', '0', '1467368862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12003', 'ltc_cny', '', '1', '0', '1467368922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12004', 'ltc_cny', '', '1', '0', '1467368982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12005', 'ltc_cny', '', '1', '0', '1467369042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12006', 'ltc_cny', '', '1', '0', '1467369102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12007', 'ltc_cny', '', '1', '0', '1467369162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12008', 'ltc_cny', '', '1', '0', '1467369222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12009', 'ltc_cny', '', '1', '0', '1467369282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12010', 'ltc_cny', '', '1', '0', '1467369342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12032', 'btc_cny', '', '1', '0', '1467439892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12033', 'btc_cny', '', '1', '0', '1467439952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12034', 'btc_cny', '', '1', '0', '1467440012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12035', 'btc_cny', '', '1', '0', '1467440072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12036', 'btc_cny', '', '1', '0', '1467440132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12037', 'btc_cny', '', '1', '0', '1467440192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12038', 'btc_cny', '', '1', '0', '1467440252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12039', 'btc_cny', '', '1', '0', '1467440312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12040', 'btc_cny', '', '1', '0', '1467440372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12041', 'btc_cny', '', '1', '0', '1467440432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12042', 'btc_cny', '', '1', '0', '1467440492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12043', 'btc_cny', '', '1', '0', '1467440552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12044', 'btc_cny', '', '1', '0', '1467440612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12045', 'btc_cny', '', '1', '0', '1467440672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12046', 'btc_cny', '', '1', '0', '1467440732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12047', 'btc_cny', '', '1', '0', '1467440792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12048', 'btc_cny', '', '1', '0', '1467440852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12049', 'btc_cny', '', '1', '0', '1467440912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12050', 'btc_cny', '', '1', '0', '1467440972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12051', 'btc_cny', '', '1', '0', '1467441032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12052', 'btc_cny', '', '1', '0', '1467441092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12074', 'ltc_cny', '', '1', '0', '1467369342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12075', 'ltc_cny', '', '1', '0', '1467369402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12076', 'ltc_cny', '', '1', '0', '1467369462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12077', 'ltc_cny', '', '1', '0', '1467369522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12078', 'ltc_cny', '', '1', '0', '1467369582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12079', 'ltc_cny', '', '1', '0', '1467369642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12080', 'ltc_cny', '', '1', '0', '1467369702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12081', 'ltc_cny', '', '1', '0', '1467369762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12082', 'ltc_cny', '', '1', '0', '1467369822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12083', 'ltc_cny', '', '1', '0', '1467369882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12084', 'ltc_cny', '', '1', '0', '1467369942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12085', 'ltc_cny', '', '1', '0', '1467370002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12086', 'ltc_cny', '', '1', '0', '1467370062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12087', 'ltc_cny', '', '1', '0', '1467370122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12088', 'ltc_cny', '', '1', '0', '1467370182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12089', 'ltc_cny', '', '1', '0', '1467370242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12090', 'ltc_cny', '', '1', '0', '1467370302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12091', 'ltc_cny', '', '1', '0', '1467370362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12092', 'ltc_cny', '', '1', '0', '1467370422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12093', 'ltc_cny', '', '1', '0', '1467370482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12094', 'ltc_cny', '', '1', '0', '1467370542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12116', 'btc_cny', '', '1', '0', '1467441092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12117', 'btc_cny', '', '1', '0', '1467441152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12118', 'btc_cny', '', '1', '0', '1467441212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12119', 'btc_cny', '', '1', '0', '1467441272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12120', 'btc_cny', '', '1', '0', '1467441332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12121', 'btc_cny', '', '1', '0', '1467441392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12122', 'btc_cny', '', '1', '0', '1467441452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12123', 'btc_cny', '', '1', '0', '1467441512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12124', 'btc_cny', '', '1', '0', '1467441572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12125', 'btc_cny', '', '1', '0', '1467441632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12126', 'btc_cny', '', '1', '0', '1467441692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12127', 'btc_cny', '', '1', '0', '1467441752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12128', 'btc_cny', '', '1', '0', '1467441812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12129', 'btc_cny', '', '1', '0', '1467441872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12130', 'btc_cny', '', '1', '0', '1467441932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12131', 'btc_cny', '', '1', '0', '1467441992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12132', 'btc_cny', '', '1', '0', '1467442052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12133', 'btc_cny', '', '1', '0', '1467442112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12134', 'btc_cny', '', '1', '0', '1467442172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12135', 'btc_cny', '', '1', '0', '1467442232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12136', 'btc_cny', '', '1', '0', '1467442292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12158', 'ltc_cny', '', '1', '0', '1467370542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12159', 'ltc_cny', '', '1', '0', '1467370602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12160', 'ltc_cny', '', '1', '0', '1467370662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12161', 'ltc_cny', '', '1', '0', '1467370722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12162', 'ltc_cny', '', '1', '0', '1467370782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12163', 'ltc_cny', '', '1', '0', '1467370842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12164', 'ltc_cny', '', '1', '0', '1467370902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12165', 'ltc_cny', '', '1', '0', '1467370962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12166', 'ltc_cny', '', '1', '0', '1467371022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12167', 'ltc_cny', '', '1', '0', '1467371082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12168', 'ltc_cny', '', '1', '0', '1467371142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12169', 'ltc_cny', '', '1', '0', '1467371202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12170', 'ltc_cny', '', '1', '0', '1467371262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12171', 'ltc_cny', '', '1', '0', '1467371322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12172', 'ltc_cny', '', '1', '0', '1467371382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12173', 'ltc_cny', '', '1', '0', '1467371442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12174', 'ltc_cny', '', '1', '0', '1467371502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12175', 'ltc_cny', '', '1', '0', '1467371562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12176', 'ltc_cny', '', '1', '0', '1467371622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12177', 'ltc_cny', '', '1', '0', '1467371682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12178', 'ltc_cny', '', '1', '0', '1467371742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12200', 'btc_cny', '', '1', '0', '1467442292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12201', 'btc_cny', '', '1', '0', '1467442352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12202', 'btc_cny', '', '1', '0', '1467442412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12203', 'btc_cny', '', '1', '0', '1467442472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12204', 'btc_cny', '', '1', '0', '1467442532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12205', 'btc_cny', '', '1', '0', '1467442592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12206', 'btc_cny', '', '1', '0', '1467442652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12207', 'btc_cny', '', '1', '0', '1467442712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12208', 'btc_cny', '', '1', '0', '1467442772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12209', 'btc_cny', '', '1', '0', '1467442832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12210', 'btc_cny', '', '1', '0', '1467442892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12211', 'btc_cny', '', '1', '0', '1467442952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12212', 'btc_cny', '', '1', '0', '1467443012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12213', 'btc_cny', '', '1', '0', '1467443072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12214', 'btc_cny', '', '1', '0', '1467443132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12215', 'btc_cny', '', '1', '0', '1467443192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12216', 'btc_cny', '', '1', '0', '1467443252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12217', 'btc_cny', '', '1', '0', '1467443312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12218', 'btc_cny', '', '1', '0', '1467443372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12219', 'btc_cny', '', '1', '0', '1467443432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12220', 'btc_cny', '', '1', '0', '1467443492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12242', 'ltc_cny', '', '1', '0', '1467371742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12243', 'ltc_cny', '', '1', '0', '1467371802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12244', 'ltc_cny', '', '1', '0', '1467371862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12245', 'ltc_cny', '', '1', '0', '1467371922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12246', 'ltc_cny', '', '1', '0', '1467371982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12247', 'ltc_cny', '', '1', '0', '1467372042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12248', 'ltc_cny', '', '1', '0', '1467372102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12249', 'ltc_cny', '', '1', '0', '1467372162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12250', 'ltc_cny', '', '1', '0', '1467372222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12251', 'ltc_cny', '', '1', '0', '1467372282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12252', 'ltc_cny', '', '1', '0', '1467372342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12253', 'ltc_cny', '', '1', '0', '1467372402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12254', 'ltc_cny', '', '1', '0', '1467372462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12255', 'ltc_cny', '', '1', '0', '1467372522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12256', 'ltc_cny', '', '1', '0', '1467372582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12257', 'ltc_cny', '', '1', '0', '1467372642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12258', 'ltc_cny', '', '1', '0', '1467372702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12259', 'ltc_cny', '', '1', '0', '1467372762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12260', 'ltc_cny', '', '1', '0', '1467372822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12261', 'ltc_cny', '', '1', '0', '1467372882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12262', 'ltc_cny', '', '1', '0', '1467372942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12284', 'btc_cny', '', '1', '0', '1467443492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12285', 'btc_cny', '', '1', '0', '1467443552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12286', 'btc_cny', '', '1', '0', '1467443612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12287', 'btc_cny', '', '1', '0', '1467443672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12288', 'btc_cny', '', '1', '0', '1467443732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12289', 'btc_cny', '', '1', '0', '1467443792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12290', 'btc_cny', '', '1', '0', '1467443852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12291', 'btc_cny', '', '1', '0', '1467443912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12292', 'btc_cny', '', '1', '0', '1467443972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12293', 'btc_cny', '', '1', '0', '1467444032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12294', 'btc_cny', '', '1', '0', '1467444092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12295', 'btc_cny', '', '1', '0', '1467444152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12296', 'btc_cny', '', '1', '0', '1467444212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12297', 'btc_cny', '', '1', '0', '1467444272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12298', 'btc_cny', '', '1', '0', '1467444332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12299', 'btc_cny', '', '1', '0', '1467444392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12300', 'btc_cny', '', '1', '0', '1467444452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12301', 'btc_cny', '', '1', '0', '1467444512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12302', 'btc_cny', '', '1', '0', '1467444572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12303', 'btc_cny', '', '1', '0', '1467444632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12304', 'btc_cny', '', '1', '0', '1467444692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12317', 'btc_cny', '[1467608760,\"22.10000000\",\"4400.00000000\",\"4599.00000000\",\"4400.00000000\",\"4599.00000000\"]', '3', '0', '1467608760', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12318', 'btc_cny', '', '3', '0', '1467608940', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12319', 'btc_cny', '', '3', '0', '1467609120', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12320', 'btc_cny', '', '3', '0', '1467609300', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12321', 'btc_cny', '', '3', '0', '1467609480', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12322', 'btc_cny', '', '3', '0', '1467609660', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12323', 'btc_cny', '', '3', '0', '1467609840', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12324', 'btc_cny', '', '3', '0', '1467610020', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12325', 'btc_cny', '', '3', '0', '1467610200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12326', 'ltc_cny', '', '1', '0', '1467372942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12327', 'ltc_cny', '', '1', '0', '1467373002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12328', 'ltc_cny', '', '1', '0', '1467373062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12329', 'ltc_cny', '', '1', '0', '1467373122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12330', 'ltc_cny', '', '1', '0', '1467373182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12331', 'ltc_cny', '', '1', '0', '1467373242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12332', 'ltc_cny', '', '1', '0', '1467373302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12333', 'ltc_cny', '', '1', '0', '1467373362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12334', 'ltc_cny', '', '1', '0', '1467373422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12335', 'ltc_cny', '', '1', '0', '1467373482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12336', 'ltc_cny', '', '1', '0', '1467373542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12337', 'ltc_cny', '', '1', '0', '1467373602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12338', 'ltc_cny', '', '1', '0', '1467373662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12339', 'ltc_cny', '', '1', '0', '1467373722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12340', 'ltc_cny', '', '1', '0', '1467373782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12341', 'ltc_cny', '', '1', '0', '1467373842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12342', 'ltc_cny', '', '1', '0', '1467373902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12343', 'ltc_cny', '', '1', '0', '1467373962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12344', 'ltc_cny', '', '1', '0', '1467374022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12345', 'ltc_cny', '', '1', '0', '1467374082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12346', 'ltc_cny', '', '1', '0', '1467374142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12368', 'btc_cny', '', '1', '0', '1467444692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12369', 'btc_cny', '', '1', '0', '1467444752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12370', 'btc_cny', '', '1', '0', '1467444812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12371', 'btc_cny', '', '1', '0', '1467444872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12372', 'btc_cny', '', '1', '0', '1467444932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12373', 'btc_cny', '', '1', '0', '1467444992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12374', 'btc_cny', '', '1', '0', '1467445052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12375', 'btc_cny', '', '1', '0', '1467445112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12376', 'btc_cny', '', '1', '0', '1467445172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12377', 'btc_cny', '', '1', '0', '1467445232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12378', 'btc_cny', '', '1', '0', '1467445292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12379', 'btc_cny', '', '1', '0', '1467445352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12380', 'btc_cny', '', '1', '0', '1467445412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12381', 'btc_cny', '', '1', '0', '1467445472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12382', 'btc_cny', '', '1', '0', '1467445532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12383', 'btc_cny', '', '1', '0', '1467445592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12384', 'btc_cny', '', '1', '0', '1467445652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12385', 'btc_cny', '', '1', '0', '1467445712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12386', 'btc_cny', '', '1', '0', '1467445772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12387', 'btc_cny', '', '1', '0', '1467445832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12388', 'btc_cny', '', '1', '0', '1467445892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12389', 'ltc_cny', '', '1', '0', '1467374142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12390', 'ltc_cny', '', '1', '0', '1467374202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12391', 'ltc_cny', '', '1', '0', '1467374262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12392', 'ltc_cny', '', '1', '0', '1467374322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12393', 'ltc_cny', '', '1', '0', '1467374382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12394', 'ltc_cny', '', '1', '0', '1467374442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12395', 'ltc_cny', '', '1', '0', '1467374502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12396', 'ltc_cny', '', '1', '0', '1467374562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12397', 'ltc_cny', '', '1', '0', '1467374622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12398', 'ltc_cny', '', '1', '0', '1467374682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12399', 'ltc_cny', '', '1', '0', '1467374742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12400', 'ltc_cny', '', '1', '0', '1467374802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12401', 'ltc_cny', '', '1', '0', '1467374862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12402', 'ltc_cny', '', '1', '0', '1467374922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12403', 'ltc_cny', '', '1', '0', '1467374982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12404', 'ltc_cny', '', '1', '0', '1467375042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12405', 'ltc_cny', '', '1', '0', '1467375102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12406', 'ltc_cny', '', '1', '0', '1467375162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12407', 'ltc_cny', '', '1', '0', '1467375222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12408', 'ltc_cny', '', '1', '0', '1467375282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12409', 'ltc_cny', '', '1', '0', '1467375342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12431', 'btc_cny', '', '1', '0', '1467445892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12432', 'btc_cny', '', '1', '0', '1467445952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12433', 'btc_cny', '', '1', '0', '1467446012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12434', 'btc_cny', '', '1', '0', '1467446072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12435', 'btc_cny', '', '1', '0', '1467446132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12436', 'btc_cny', '', '1', '0', '1467446192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12437', 'btc_cny', '', '1', '0', '1467446252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12438', 'btc_cny', '', '1', '0', '1467446312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12439', 'btc_cny', '', '1', '0', '1467446372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12440', 'btc_cny', '', '1', '0', '1467446432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12441', 'btc_cny', '', '1', '0', '1467446492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12442', 'btc_cny', '', '1', '0', '1467446552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12443', 'btc_cny', '', '1', '0', '1467446612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12444', 'btc_cny', '', '1', '0', '1467446672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12445', 'btc_cny', '', '1', '0', '1467446732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12446', 'btc_cny', '', '1', '0', '1467446792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12447', 'btc_cny', '', '1', '0', '1467446852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12448', 'btc_cny', '', '1', '0', '1467446912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12449', 'btc_cny', '', '1', '0', '1467446972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12450', 'btc_cny', '', '1', '0', '1467447032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12451', 'btc_cny', '', '1', '0', '1467447092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12452', 'ltc_cny', '', '1', '0', '1467375342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12453', 'ltc_cny', '', '1', '0', '1467375402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12454', 'ltc_cny', '', '1', '0', '1467375462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12455', 'ltc_cny', '', '1', '0', '1467375522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12456', 'ltc_cny', '', '1', '0', '1467375582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12457', 'ltc_cny', '', '1', '0', '1467375642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12458', 'ltc_cny', '', '1', '0', '1467375702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12459', 'ltc_cny', '', '1', '0', '1467375762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12460', 'ltc_cny', '', '1', '0', '1467375822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12461', 'ltc_cny', '', '1', '0', '1467375882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12462', 'ltc_cny', '', '1', '0', '1467375942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12463', 'ltc_cny', '', '1', '0', '1467376002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12464', 'ltc_cny', '', '1', '0', '1467376062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12465', 'ltc_cny', '', '1', '0', '1467376122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12466', 'ltc_cny', '', '1', '0', '1467376182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12467', 'ltc_cny', '', '1', '0', '1467376242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12468', 'ltc_cny', '', '1', '0', '1467376302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12469', 'ltc_cny', '', '1', '0', '1467376362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12470', 'ltc_cny', '', '1', '0', '1467376422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12471', 'ltc_cny', '', '1', '0', '1467376482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12472', 'ltc_cny', '', '1', '0', '1467376542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12494', 'btc_cny', '', '1', '0', '1467447092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12495', 'btc_cny', '', '1', '0', '1467447152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12496', 'btc_cny', '', '1', '0', '1467447212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12497', 'btc_cny', '', '1', '0', '1467447272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12498', 'btc_cny', '', '1', '0', '1467447332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12499', 'btc_cny', '', '1', '0', '1467447392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12500', 'btc_cny', '', '1', '0', '1467447452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12501', 'btc_cny', '', '1', '0', '1467447512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12502', 'btc_cny', '', '1', '0', '1467447572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12503', 'btc_cny', '', '1', '0', '1467447632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12504', 'btc_cny', '', '1', '0', '1467447692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12505', 'btc_cny', '', '1', '0', '1467447752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12506', 'btc_cny', '', '1', '0', '1467447812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12507', 'btc_cny', '', '1', '0', '1467447872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12508', 'btc_cny', '', '1', '0', '1467447932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12509', 'btc_cny', '', '1', '0', '1467447992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12510', 'btc_cny', '', '1', '0', '1467448052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12511', 'btc_cny', '', '1', '0', '1467448112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12512', 'btc_cny', '', '1', '0', '1467448172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12513', 'btc_cny', '', '1', '0', '1467448232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12514', 'btc_cny', '', '1', '0', '1467448292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12515', 'ltc_cny', '', '1', '0', '1467376542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12516', 'ltc_cny', '', '1', '0', '1467376602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12517', 'ltc_cny', '', '1', '0', '1467376662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12518', 'ltc_cny', '', '1', '0', '1467376722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12519', 'ltc_cny', '', '1', '0', '1467376782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12520', 'ltc_cny', '', '1', '0', '1467376842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12521', 'ltc_cny', '', '1', '0', '1467376902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12522', 'ltc_cny', '', '1', '0', '1467376962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12523', 'ltc_cny', '', '1', '0', '1467377022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12524', 'ltc_cny', '', '1', '0', '1467377082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12525', 'ltc_cny', '', '1', '0', '1467377142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12526', 'ltc_cny', '', '1', '0', '1467377202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12527', 'ltc_cny', '', '1', '0', '1467377262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12528', 'ltc_cny', '', '1', '0', '1467377322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12529', 'ltc_cny', '', '1', '0', '1467377382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12530', 'ltc_cny', '', '1', '0', '1467377442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12531', 'ltc_cny', '', '1', '0', '1467377502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12532', 'ltc_cny', '', '1', '0', '1467377562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12533', 'ltc_cny', '', '1', '0', '1467377622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12534', 'ltc_cny', '', '1', '0', '1467377682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12535', 'ltc_cny', '', '1', '0', '1467377742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12557', 'btc_cny', '', '1', '0', '1467448292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12558', 'btc_cny', '', '1', '0', '1467448352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12559', 'btc_cny', '', '1', '0', '1467448412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12560', 'btc_cny', '', '1', '0', '1467448472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12561', 'btc_cny', '', '1', '0', '1467448532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12562', 'btc_cny', '', '1', '0', '1467448592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12563', 'btc_cny', '', '1', '0', '1467448652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12564', 'btc_cny', '', '1', '0', '1467448712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12565', 'btc_cny', '', '1', '0', '1467448772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12566', 'btc_cny', '', '1', '0', '1467448832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12567', 'btc_cny', '', '1', '0', '1467448892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12568', 'btc_cny', '', '1', '0', '1467448952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12569', 'btc_cny', '', '1', '0', '1467449012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12570', 'btc_cny', '', '1', '0', '1467449072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12571', 'btc_cny', '', '1', '0', '1467449132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12572', 'btc_cny', '', '1', '0', '1467449192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12573', 'btc_cny', '', '1', '0', '1467449252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12574', 'btc_cny', '', '1', '0', '1467449312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12575', 'btc_cny', '', '1', '0', '1467449372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12576', 'btc_cny', '', '1', '0', '1467449432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12577', 'btc_cny', '', '1', '0', '1467449492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12578', 'ltc_cny', '', '1', '0', '1467377742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12579', 'ltc_cny', '', '1', '0', '1467377802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12580', 'ltc_cny', '', '1', '0', '1467377862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12581', 'ltc_cny', '', '1', '0', '1467377922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12582', 'ltc_cny', '', '1', '0', '1467377982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12583', 'ltc_cny', '', '1', '0', '1467378042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12584', 'ltc_cny', '', '1', '0', '1467378102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12585', 'ltc_cny', '', '1', '0', '1467378162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12586', 'ltc_cny', '', '1', '0', '1467378222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12587', 'ltc_cny', '', '1', '0', '1467378282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12588', 'ltc_cny', '', '1', '0', '1467378342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12589', 'ltc_cny', '', '1', '0', '1467378402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12590', 'ltc_cny', '', '1', '0', '1467378462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12591', 'ltc_cny', '', '1', '0', '1467378522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12592', 'ltc_cny', '', '1', '0', '1467378582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12593', 'ltc_cny', '', '1', '0', '1467378642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12594', 'ltc_cny', '', '1', '0', '1467378702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12595', 'ltc_cny', '', '1', '0', '1467378762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12596', 'ltc_cny', '', '1', '0', '1467378822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12597', 'ltc_cny', '', '1', '0', '1467378882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12598', 'ltc_cny', '', '1', '0', '1467378942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12620', 'btc_cny', '', '1', '0', '1467449492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12621', 'btc_cny', '', '1', '0', '1467449552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12622', 'btc_cny', '', '1', '0', '1467449612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12623', 'btc_cny', '', '1', '0', '1467449672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12624', 'btc_cny', '', '1', '0', '1467449732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12625', 'btc_cny', '', '1', '0', '1467449792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12626', 'btc_cny', '', '1', '0', '1467449852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12627', 'btc_cny', '', '1', '0', '1467449912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12628', 'btc_cny', '', '1', '0', '1467449972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12629', 'btc_cny', '', '1', '0', '1467450032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12630', 'btc_cny', '', '1', '0', '1467450092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12631', 'btc_cny', '', '1', '0', '1467450152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12632', 'btc_cny', '', '1', '0', '1467450212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12633', 'btc_cny', '', '1', '0', '1467450272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12634', 'btc_cny', '', '1', '0', '1467450332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12635', 'btc_cny', '', '1', '0', '1467450392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12636', 'btc_cny', '', '1', '0', '1467450452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12637', 'btc_cny', '', '1', '0', '1467450512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12638', 'btc_cny', '', '1', '0', '1467450572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12639', 'btc_cny', '', '1', '0', '1467450632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12640', 'btc_cny', '', '1', '0', '1467450692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12641', 'ltc_cny', '', '1', '0', '1467378942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12642', 'ltc_cny', '', '1', '0', '1467379002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12643', 'ltc_cny', '', '1', '0', '1467379062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12644', 'ltc_cny', '', '1', '0', '1467379122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12645', 'ltc_cny', '', '1', '0', '1467379182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12646', 'ltc_cny', '', '1', '0', '1467379242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12647', 'ltc_cny', '', '1', '0', '1467379302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12648', 'ltc_cny', '', '1', '0', '1467379362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12649', 'ltc_cny', '', '1', '0', '1467379422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12650', 'ltc_cny', '', '1', '0', '1467379482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12651', 'ltc_cny', '', '1', '0', '1467379542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12652', 'ltc_cny', '', '1', '0', '1467379602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12653', 'ltc_cny', '', '1', '0', '1467379662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12654', 'ltc_cny', '', '1', '0', '1467379722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12655', 'ltc_cny', '', '1', '0', '1467379782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12656', 'ltc_cny', '', '1', '0', '1467379842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12657', 'ltc_cny', '', '1', '0', '1467379902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12658', 'ltc_cny', '', '1', '0', '1467379962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12659', 'ltc_cny', '', '1', '0', '1467380022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12660', 'ltc_cny', '', '1', '0', '1467380082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12661', 'ltc_cny', '', '1', '0', '1467380142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12683', 'btc_cny', '', '1', '0', '1467450692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12684', 'btc_cny', '', '1', '0', '1467450752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12685', 'btc_cny', '', '1', '0', '1467450812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12686', 'btc_cny', '', '1', '0', '1467450872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12687', 'btc_cny', '', '1', '0', '1467450932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12688', 'btc_cny', '', '1', '0', '1467450992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12689', 'btc_cny', '', '1', '0', '1467451052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12690', 'btc_cny', '', '1', '0', '1467451112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12691', 'btc_cny', '', '1', '0', '1467451172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12692', 'btc_cny', '', '1', '0', '1467451232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12693', 'btc_cny', '', '1', '0', '1467451292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12694', 'btc_cny', '', '1', '0', '1467451352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12695', 'btc_cny', '', '1', '0', '1467451412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12696', 'btc_cny', '', '1', '0', '1467451472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12697', 'btc_cny', '', '1', '0', '1467451532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12698', 'btc_cny', '', '1', '0', '1467451592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12699', 'btc_cny', '', '1', '0', '1467451652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12700', 'btc_cny', '', '1', '0', '1467451712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12701', 'btc_cny', '', '1', '0', '1467451772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12702', 'btc_cny', '', '1', '0', '1467451832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12703', 'btc_cny', '', '1', '0', '1467451892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12704', 'ltc_cny', '', '1', '0', '1467380142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12705', 'ltc_cny', '', '1', '0', '1467380202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12706', 'ltc_cny', '', '1', '0', '1467380262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12707', 'ltc_cny', '', '1', '0', '1467380322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12708', 'ltc_cny', '', '1', '0', '1467380382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12709', 'ltc_cny', '', '1', '0', '1467380442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12710', 'ltc_cny', '', '1', '0', '1467380502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12711', 'ltc_cny', '', '1', '0', '1467380562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12712', 'ltc_cny', '', '1', '0', '1467380622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12713', 'ltc_cny', '', '1', '0', '1467380682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12714', 'ltc_cny', '', '1', '0', '1467380742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12715', 'ltc_cny', '', '1', '0', '1467380802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12716', 'ltc_cny', '', '1', '0', '1467380862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12717', 'ltc_cny', '', '1', '0', '1467380922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12718', 'ltc_cny', '', '1', '0', '1467380982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12719', 'ltc_cny', '', '1', '0', '1467381042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12720', 'ltc_cny', '', '1', '0', '1467381102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12721', 'ltc_cny', '', '1', '0', '1467381162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12722', 'ltc_cny', '', '1', '0', '1467381222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12723', 'ltc_cny', '', '1', '0', '1467381282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12724', 'ltc_cny', '', '1', '0', '1467381342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12746', 'btc_cny', '', '1', '0', '1467451892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12747', 'btc_cny', '', '1', '0', '1467451952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12748', 'btc_cny', '', '1', '0', '1467452012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12749', 'btc_cny', '', '1', '0', '1467452072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12750', 'btc_cny', '', '1', '0', '1467452132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12751', 'btc_cny', '', '1', '0', '1467452192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12752', 'btc_cny', '', '1', '0', '1467452252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12753', 'btc_cny', '', '1', '0', '1467452312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12754', 'btc_cny', '', '1', '0', '1467452372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12755', 'btc_cny', '', '1', '0', '1467452432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12756', 'btc_cny', '', '1', '0', '1467452492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12757', 'btc_cny', '', '1', '0', '1467452552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12758', 'btc_cny', '', '1', '0', '1467452612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12759', 'btc_cny', '', '1', '0', '1467452672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12760', 'btc_cny', '', '1', '0', '1467452732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12761', 'btc_cny', '', '1', '0', '1467452792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12762', 'btc_cny', '', '1', '0', '1467452852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12763', 'btc_cny', '', '1', '0', '1467452912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12764', 'btc_cny', '', '1', '0', '1467452972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12765', 'btc_cny', '', '1', '0', '1467453032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12766', 'btc_cny', '', '1', '0', '1467453092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12767', 'ltc_cny', '', '1', '0', '1467381342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12768', 'ltc_cny', '', '1', '0', '1467381402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12769', 'ltc_cny', '', '1', '0', '1467381462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12770', 'ltc_cny', '', '1', '0', '1467381522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12771', 'ltc_cny', '', '1', '0', '1467381582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12772', 'ltc_cny', '', '1', '0', '1467381642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12773', 'ltc_cny', '', '1', '0', '1467381702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12774', 'ltc_cny', '', '1', '0', '1467381762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12775', 'ltc_cny', '', '1', '0', '1467381822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12776', 'ltc_cny', '', '1', '0', '1467381882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12777', 'ltc_cny', '', '1', '0', '1467381942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12778', 'ltc_cny', '', '1', '0', '1467382002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12779', 'ltc_cny', '', '1', '0', '1467382062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12780', 'ltc_cny', '', '1', '0', '1467382122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12781', 'ltc_cny', '', '1', '0', '1467382182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12782', 'ltc_cny', '', '1', '0', '1467382242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12783', 'ltc_cny', '', '1', '0', '1467382302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12784', 'ltc_cny', '', '1', '0', '1467382362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12785', 'ltc_cny', '', '1', '0', '1467382422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12786', 'ltc_cny', '', '1', '0', '1467382482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12787', 'ltc_cny', '', '1', '0', '1467382542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12809', 'btc_cny', '', '1', '0', '1467453092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12810', 'btc_cny', '', '1', '0', '1467453152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12811', 'btc_cny', '', '1', '0', '1467453212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12812', 'btc_cny', '', '1', '0', '1467453272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12813', 'btc_cny', '', '1', '0', '1467453332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12814', 'btc_cny', '', '1', '0', '1467453392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12815', 'btc_cny', '', '1', '0', '1467453452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12816', 'btc_cny', '', '1', '0', '1467453512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12817', 'btc_cny', '', '1', '0', '1467453572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12818', 'btc_cny', '', '1', '0', '1467453632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12819', 'btc_cny', '', '1', '0', '1467453692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12820', 'btc_cny', '', '1', '0', '1467453752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12821', 'btc_cny', '', '1', '0', '1467453812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12822', 'btc_cny', '', '1', '0', '1467453872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12823', 'btc_cny', '', '1', '0', '1467453932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12824', 'btc_cny', '', '1', '0', '1467453992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12825', 'btc_cny', '', '1', '0', '1467454052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12826', 'btc_cny', '', '1', '0', '1467454112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12827', 'btc_cny', '', '1', '0', '1467454172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12828', 'btc_cny', '', '1', '0', '1467454232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12829', 'btc_cny', '', '1', '0', '1467454292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12830', 'ltc_cny', '', '1', '0', '1467382542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12831', 'ltc_cny', '', '1', '0', '1467382602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12832', 'ltc_cny', '', '1', '0', '1467382662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12833', 'ltc_cny', '', '1', '0', '1467382722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12834', 'ltc_cny', '', '1', '0', '1467382782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12835', 'ltc_cny', '', '1', '0', '1467382842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12836', 'ltc_cny', '', '1', '0', '1467382902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12837', 'ltc_cny', '', '1', '0', '1467382962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12838', 'ltc_cny', '', '1', '0', '1467383022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12839', 'ltc_cny', '', '1', '0', '1467383082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12840', 'ltc_cny', '', '1', '0', '1467383142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12841', 'ltc_cny', '', '1', '0', '1467383202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12842', 'ltc_cny', '', '1', '0', '1467383262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12843', 'ltc_cny', '', '1', '0', '1467383322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12844', 'ltc_cny', '', '1', '0', '1467383382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12845', 'ltc_cny', '', '1', '0', '1467383442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12846', 'ltc_cny', '', '1', '0', '1467383502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12847', 'ltc_cny', '', '1', '0', '1467383562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12848', 'ltc_cny', '', '1', '0', '1467383622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12849', 'ltc_cny', '', '1', '0', '1467383682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12850', 'ltc_cny', '', '1', '0', '1467383742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12872', 'btc_cny', '', '1', '0', '1467454292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12873', 'btc_cny', '', '1', '0', '1467454352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12874', 'btc_cny', '', '1', '0', '1467454412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12875', 'btc_cny', '', '1', '0', '1467454472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12876', 'btc_cny', '', '1', '0', '1467454532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12877', 'btc_cny', '', '1', '0', '1467454592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12878', 'btc_cny', '', '1', '0', '1467454652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12879', 'btc_cny', '', '1', '0', '1467454712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12880', 'btc_cny', '', '1', '0', '1467454772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12881', 'btc_cny', '', '1', '0', '1467454832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12882', 'btc_cny', '', '1', '0', '1467454892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12883', 'btc_cny', '', '1', '0', '1467454952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12884', 'btc_cny', '', '1', '0', '1467455012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12885', 'btc_cny', '', '1', '0', '1467455072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12886', 'btc_cny', '', '1', '0', '1467455132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12887', 'btc_cny', '', '1', '0', '1467455192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12888', 'btc_cny', '', '1', '0', '1467455252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12889', 'btc_cny', '', '1', '0', '1467455312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12890', 'btc_cny', '', '1', '0', '1467455372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12891', 'btc_cny', '', '1', '0', '1467455432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12892', 'btc_cny', '', '1', '0', '1467455492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12893', 'ltc_cny', '', '1', '0', '1467383742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12894', 'ltc_cny', '', '1', '0', '1467383802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12895', 'ltc_cny', '', '1', '0', '1467383862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12896', 'ltc_cny', '', '1', '0', '1467383922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12897', 'ltc_cny', '', '1', '0', '1467383982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12898', 'ltc_cny', '', '1', '0', '1467384042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12899', 'ltc_cny', '', '1', '0', '1467384102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12900', 'ltc_cny', '', '1', '0', '1467384162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12901', 'ltc_cny', '', '1', '0', '1467384222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12902', 'ltc_cny', '', '1', '0', '1467384282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12903', 'ltc_cny', '', '1', '0', '1467384342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12904', 'ltc_cny', '', '1', '0', '1467384402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12905', 'ltc_cny', '', '1', '0', '1467384462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12906', 'ltc_cny', '', '1', '0', '1467384522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12907', 'ltc_cny', '', '1', '0', '1467384582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12908', 'ltc_cny', '', '1', '0', '1467384642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12909', 'ltc_cny', '', '1', '0', '1467384702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12910', 'ltc_cny', '', '1', '0', '1467384762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12911', 'ltc_cny', '', '1', '0', '1467384822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12912', 'ltc_cny', '', '1', '0', '1467384882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12913', 'ltc_cny', '', '1', '0', '1467384942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12935', 'btc_cny', '', '1', '0', '1467455492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12936', 'btc_cny', '', '1', '0', '1467455552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12937', 'btc_cny', '', '1', '0', '1467455612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12938', 'btc_cny', '', '1', '0', '1467455672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12939', 'btc_cny', '', '1', '0', '1467455732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12940', 'btc_cny', '', '1', '0', '1467455792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12941', 'btc_cny', '', '1', '0', '1467455852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12942', 'btc_cny', '', '1', '0', '1467455912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12943', 'btc_cny', '', '1', '0', '1467455972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12944', 'btc_cny', '', '1', '0', '1467456032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12945', 'btc_cny', '', '1', '0', '1467456092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12946', 'btc_cny', '', '1', '0', '1467456152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12947', 'btc_cny', '', '1', '0', '1467456212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12948', 'btc_cny', '', '1', '0', '1467456272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12949', 'btc_cny', '', '1', '0', '1467456332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12950', 'btc_cny', '', '1', '0', '1467456392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12951', 'btc_cny', '', '1', '0', '1467456452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12952', 'btc_cny', '', '1', '0', '1467456512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12953', 'btc_cny', '', '1', '0', '1467456572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12954', 'btc_cny', '', '1', '0', '1467456632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12955', 'btc_cny', '', '1', '0', '1467456692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12956', 'ltc_cny', '', '1', '0', '1467384942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12957', 'ltc_cny', '', '1', '0', '1467385002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12958', 'ltc_cny', '', '1', '0', '1467385062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12959', 'ltc_cny', '', '1', '0', '1467385122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12960', 'ltc_cny', '', '1', '0', '1467385182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12961', 'ltc_cny', '', '1', '0', '1467385242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12962', 'ltc_cny', '', '1', '0', '1467385302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12963', 'ltc_cny', '', '1', '0', '1467385362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12964', 'ltc_cny', '', '1', '0', '1467385422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12965', 'ltc_cny', '', '1', '0', '1467385482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12966', 'ltc_cny', '', '1', '0', '1467385542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12967', 'ltc_cny', '', '1', '0', '1467385602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12968', 'ltc_cny', '', '1', '0', '1467385662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12969', 'ltc_cny', '', '1', '0', '1467385722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12970', 'ltc_cny', '', '1', '0', '1467385782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12971', 'ltc_cny', '', '1', '0', '1467385842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12972', 'ltc_cny', '', '1', '0', '1467385902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12973', 'ltc_cny', '', '1', '0', '1467385962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12974', 'ltc_cny', '', '1', '0', '1467386022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12975', 'ltc_cny', '', '1', '0', '1467386082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12976', 'ltc_cny', '', '1', '0', '1467386142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12998', 'btc_cny', '', '1', '0', '1467456692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('12999', 'btc_cny', '', '1', '0', '1467456752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13000', 'btc_cny', '', '1', '0', '1467456812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13001', 'btc_cny', '', '1', '0', '1467456872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13002', 'btc_cny', '', '1', '0', '1467456932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13003', 'btc_cny', '', '1', '0', '1467456992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13004', 'btc_cny', '', '1', '0', '1467457052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13005', 'btc_cny', '', '1', '0', '1467457112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13006', 'btc_cny', '', '1', '0', '1467457172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13007', 'btc_cny', '', '1', '0', '1467457232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13008', 'btc_cny', '', '1', '0', '1467457292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13009', 'btc_cny', '', '1', '0', '1467457352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13010', 'btc_cny', '', '1', '0', '1467457412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13011', 'btc_cny', '', '1', '0', '1467457472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13012', 'btc_cny', '', '1', '0', '1467457532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13013', 'btc_cny', '', '1', '0', '1467457592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13014', 'btc_cny', '', '1', '0', '1467457652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13015', 'btc_cny', '', '1', '0', '1467457712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13016', 'btc_cny', '', '1', '0', '1467457772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13017', 'btc_cny', '', '1', '0', '1467457832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13018', 'btc_cny', '', '1', '0', '1467457892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13019', 'ltc_cny', '', '1', '0', '1467386142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13020', 'ltc_cny', '', '1', '0', '1467386202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13021', 'ltc_cny', '', '1', '0', '1467386262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13022', 'ltc_cny', '', '1', '0', '1467386322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13023', 'ltc_cny', '', '1', '0', '1467386382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13024', 'ltc_cny', '', '1', '0', '1467386442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13025', 'ltc_cny', '', '1', '0', '1467386502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13026', 'ltc_cny', '', '1', '0', '1467386562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13027', 'ltc_cny', '', '1', '0', '1467386622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13028', 'ltc_cny', '', '1', '0', '1467386682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13029', 'ltc_cny', '', '1', '0', '1467386742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13030', 'ltc_cny', '', '1', '0', '1467386802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13031', 'ltc_cny', '', '1', '0', '1467386862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13032', 'ltc_cny', '', '1', '0', '1467386922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13033', 'ltc_cny', '', '1', '0', '1467386982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13034', 'ltc_cny', '', '1', '0', '1467387042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13035', 'ltc_cny', '', '1', '0', '1467387102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13036', 'ltc_cny', '', '1', '0', '1467387162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13037', 'ltc_cny', '', '1', '0', '1467387222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13038', 'ltc_cny', '', '1', '0', '1467387282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13039', 'ltc_cny', '', '1', '0', '1467387342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13061', 'btc_cny', '', '1', '0', '1467457892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13062', 'btc_cny', '', '1', '0', '1467457952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13063', 'btc_cny', '', '1', '0', '1467458012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13064', 'btc_cny', '', '1', '0', '1467458072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13065', 'btc_cny', '', '1', '0', '1467458132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13066', 'btc_cny', '', '1', '0', '1467458192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13067', 'btc_cny', '', '1', '0', '1467458252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13068', 'btc_cny', '', '1', '0', '1467458312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13069', 'btc_cny', '', '1', '0', '1467458372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13070', 'btc_cny', '', '1', '0', '1467458432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13071', 'btc_cny', '', '1', '0', '1467458492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13072', 'btc_cny', '', '1', '0', '1467458552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13073', 'btc_cny', '', '1', '0', '1467458612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13074', 'btc_cny', '', '1', '0', '1467458672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13075', 'btc_cny', '', '1', '0', '1467458732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13076', 'btc_cny', '', '1', '0', '1467458792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13077', 'btc_cny', '', '1', '0', '1467458852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13078', 'btc_cny', '', '1', '0', '1467458912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13079', 'btc_cny', '', '1', '0', '1467458972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13080', 'btc_cny', '', '1', '0', '1467459032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13081', 'btc_cny', '', '1', '0', '1467459092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13082', 'ltc_cny', '', '1', '0', '1467387342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13083', 'ltc_cny', '', '1', '0', '1467387402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13084', 'ltc_cny', '', '1', '0', '1467387462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13085', 'ltc_cny', '', '1', '0', '1467387522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13086', 'ltc_cny', '', '1', '0', '1467387582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13087', 'ltc_cny', '', '1', '0', '1467387642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13088', 'ltc_cny', '', '1', '0', '1467387702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13089', 'ltc_cny', '', '1', '0', '1467387762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13090', 'ltc_cny', '', '1', '0', '1467387822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13091', 'ltc_cny', '', '1', '0', '1467387882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13092', 'ltc_cny', '', '1', '0', '1467387942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13093', 'ltc_cny', '', '1', '0', '1467388002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13094', 'ltc_cny', '', '1', '0', '1467388062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13095', 'ltc_cny', '', '1', '0', '1467388122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13096', 'ltc_cny', '', '1', '0', '1467388182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13097', 'ltc_cny', '', '1', '0', '1467388242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13098', 'ltc_cny', '', '1', '0', '1467388302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13099', 'ltc_cny', '', '1', '0', '1467388362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13100', 'ltc_cny', '', '1', '0', '1467388422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13101', 'ltc_cny', '', '1', '0', '1467388482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13102', 'ltc_cny', '', '1', '0', '1467388542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13124', 'btc_cny', '', '1', '0', '1467459092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13125', 'btc_cny', '', '1', '0', '1467459152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13126', 'btc_cny', '', '1', '0', '1467459212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13127', 'btc_cny', '', '1', '0', '1467459272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13128', 'btc_cny', '', '1', '0', '1467459332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13129', 'btc_cny', '', '1', '0', '1467459392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13130', 'btc_cny', '', '1', '0', '1467459452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13131', 'btc_cny', '', '1', '0', '1467459512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13132', 'btc_cny', '', '1', '0', '1467459572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13133', 'btc_cny', '', '1', '0', '1467459632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13134', 'btc_cny', '', '1', '0', '1467459692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13135', 'btc_cny', '', '1', '0', '1467459752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13136', 'btc_cny', '', '1', '0', '1467459812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13137', 'btc_cny', '', '1', '0', '1467459872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13138', 'btc_cny', '', '1', '0', '1467459932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13139', 'btc_cny', '', '1', '0', '1467459992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13140', 'btc_cny', '', '1', '0', '1467460052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13141', 'btc_cny', '', '1', '0', '1467460112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13142', 'btc_cny', '', '1', '0', '1467460172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13143', 'btc_cny', '', '1', '0', '1467460232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13144', 'btc_cny', '', '1', '0', '1467460292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13145', 'ltc_cny', '', '1', '0', '1467388542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13146', 'ltc_cny', '', '1', '0', '1467388602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13147', 'ltc_cny', '', '1', '0', '1467388662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13148', 'ltc_cny', '', '1', '0', '1467388722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13149', 'ltc_cny', '', '1', '0', '1467388782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13150', 'ltc_cny', '', '1', '0', '1467388842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13151', 'ltc_cny', '', '1', '0', '1467388902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13152', 'ltc_cny', '', '1', '0', '1467388962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13153', 'ltc_cny', '', '1', '0', '1467389022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13154', 'ltc_cny', '', '1', '0', '1467389082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13155', 'ltc_cny', '', '1', '0', '1467389142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13156', 'ltc_cny', '', '1', '0', '1467389202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13157', 'ltc_cny', '', '1', '0', '1467389262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13158', 'ltc_cny', '', '1', '0', '1467389322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13159', 'ltc_cny', '', '1', '0', '1467389382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13160', 'ltc_cny', '', '1', '0', '1467389442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13161', 'ltc_cny', '', '1', '0', '1467389502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13162', 'ltc_cny', '', '1', '0', '1467389562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13163', 'ltc_cny', '', '1', '0', '1467389622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13164', 'ltc_cny', '', '1', '0', '1467389682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13165', 'ltc_cny', '', '1', '0', '1467389742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13187', 'btc_cny', '', '1', '0', '1467460292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13188', 'btc_cny', '', '1', '0', '1467460352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13189', 'btc_cny', '', '1', '0', '1467460412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13190', 'btc_cny', '', '1', '0', '1467460472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13191', 'btc_cny', '', '1', '0', '1467460532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13192', 'btc_cny', '', '1', '0', '1467460592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13193', 'btc_cny', '', '1', '0', '1467460652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13194', 'btc_cny', '', '1', '0', '1467460712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13195', 'btc_cny', '', '1', '0', '1467460772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13196', 'btc_cny', '', '1', '0', '1467460832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13197', 'btc_cny', '', '1', '0', '1467460892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13198', 'btc_cny', '', '1', '0', '1467460952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13199', 'btc_cny', '', '1', '0', '1467461012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13200', 'btc_cny', '', '1', '0', '1467461072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13201', 'btc_cny', '', '1', '0', '1467461132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13202', 'btc_cny', '', '1', '0', '1467461192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13203', 'btc_cny', '', '1', '0', '1467461252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13204', 'btc_cny', '', '1', '0', '1467461312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13205', 'btc_cny', '', '1', '0', '1467461372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13206', 'btc_cny', '', '1', '0', '1467461432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13207', 'btc_cny', '', '1', '0', '1467461492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13208', 'ltc_cny', '', '1', '0', '1467389742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13209', 'ltc_cny', '', '1', '0', '1467389802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13210', 'ltc_cny', '', '1', '0', '1467389862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13211', 'ltc_cny', '', '1', '0', '1467389922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13212', 'ltc_cny', '', '1', '0', '1467389982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13213', 'ltc_cny', '', '1', '0', '1467390042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13214', 'ltc_cny', '', '1', '0', '1467390102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13215', 'ltc_cny', '', '1', '0', '1467390162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13216', 'ltc_cny', '', '1', '0', '1467390222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13217', 'ltc_cny', '', '1', '0', '1467390282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13218', 'ltc_cny', '', '1', '0', '1467390342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13219', 'ltc_cny', '', '1', '0', '1467390402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13220', 'ltc_cny', '', '1', '0', '1467390462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13221', 'ltc_cny', '', '1', '0', '1467390522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13222', 'ltc_cny', '', '1', '0', '1467390582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13223', 'ltc_cny', '', '1', '0', '1467390642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13224', 'ltc_cny', '', '1', '0', '1467390702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13225', 'ltc_cny', '', '1', '0', '1467390762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13226', 'ltc_cny', '', '1', '0', '1467390822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13227', 'ltc_cny', '', '1', '0', '1467390882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13228', 'ltc_cny', '', '1', '0', '1467390942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13250', 'btc_cny', '', '1', '0', '1467461492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13251', 'btc_cny', '', '1', '0', '1467461552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13252', 'btc_cny', '', '1', '0', '1467461612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13253', 'btc_cny', '', '1', '0', '1467461672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13254', 'btc_cny', '', '1', '0', '1467461732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13255', 'btc_cny', '', '1', '0', '1467461792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13256', 'btc_cny', '', '1', '0', '1467461852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13257', 'btc_cny', '', '1', '0', '1467461912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13258', 'btc_cny', '', '1', '0', '1467461972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13259', 'btc_cny', '', '1', '0', '1467462032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13260', 'btc_cny', '', '1', '0', '1467462092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13261', 'btc_cny', '', '1', '0', '1467462152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13262', 'btc_cny', '', '1', '0', '1467462212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13263', 'btc_cny', '', '1', '0', '1467462272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13264', 'btc_cny', '', '1', '0', '1467462332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13265', 'btc_cny', '', '1', '0', '1467462392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13266', 'btc_cny', '', '1', '0', '1467462452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13267', 'btc_cny', '', '1', '0', '1467462512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13268', 'btc_cny', '', '1', '0', '1467462572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13269', 'btc_cny', '', '1', '0', '1467462632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13270', 'btc_cny', '', '1', '0', '1467462692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13271', 'ltc_cny', '', '1', '0', '1467390942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13272', 'ltc_cny', '', '1', '0', '1467391002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13273', 'ltc_cny', '', '1', '0', '1467391062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13274', 'ltc_cny', '', '1', '0', '1467391122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13275', 'ltc_cny', '', '1', '0', '1467391182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13276', 'ltc_cny', '', '1', '0', '1467391242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13277', 'ltc_cny', '', '1', '0', '1467391302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13278', 'ltc_cny', '', '1', '0', '1467391362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13279', 'ltc_cny', '', '1', '0', '1467391422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13280', 'ltc_cny', '', '1', '0', '1467391482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13281', 'ltc_cny', '', '1', '0', '1467391542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13282', 'ltc_cny', '', '1', '0', '1467391602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13283', 'ltc_cny', '', '1', '0', '1467391662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13284', 'ltc_cny', '', '1', '0', '1467391722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13285', 'ltc_cny', '', '1', '0', '1467391782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13286', 'ltc_cny', '', '1', '0', '1467391842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13287', 'ltc_cny', '', '1', '0', '1467391902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13288', 'ltc_cny', '', '1', '0', '1467391962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13289', 'ltc_cny', '', '1', '0', '1467392022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13290', 'ltc_cny', '', '1', '0', '1467392082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13291', 'ltc_cny', '', '1', '0', '1467392142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13313', 'btc_cny', '', '1', '0', '1467462692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13314', 'btc_cny', '', '1', '0', '1467462752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13315', 'btc_cny', '', '1', '0', '1467462812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13316', 'btc_cny', '', '1', '0', '1467462872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13317', 'btc_cny', '', '1', '0', '1467462932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13318', 'btc_cny', '', '1', '0', '1467462992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13319', 'btc_cny', '', '1', '0', '1467463052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13320', 'btc_cny', '', '1', '0', '1467463112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13321', 'btc_cny', '', '1', '0', '1467463172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13322', 'btc_cny', '', '1', '0', '1467463232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13323', 'btc_cny', '', '1', '0', '1467463292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13324', 'btc_cny', '', '1', '0', '1467463352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13325', 'btc_cny', '', '1', '0', '1467463412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13326', 'btc_cny', '', '1', '0', '1467463472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13327', 'btc_cny', '', '1', '0', '1467463532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13328', 'btc_cny', '', '1', '0', '1467463592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13329', 'btc_cny', '', '1', '0', '1467463652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13330', 'btc_cny', '', '1', '0', '1467463712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13331', 'btc_cny', '', '1', '0', '1467463772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13332', 'btc_cny', '', '1', '0', '1467463832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13333', 'btc_cny', '', '1', '0', '1467463892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13334', 'ltc_cny', '', '1', '0', '1467392142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13335', 'ltc_cny', '', '1', '0', '1467392202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13336', 'ltc_cny', '', '1', '0', '1467392262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13337', 'ltc_cny', '', '1', '0', '1467392322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13338', 'ltc_cny', '', '1', '0', '1467392382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13339', 'ltc_cny', '', '1', '0', '1467392442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13340', 'ltc_cny', '', '1', '0', '1467392502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13341', 'ltc_cny', '', '1', '0', '1467392562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13342', 'ltc_cny', '', '1', '0', '1467392622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13343', 'ltc_cny', '', '1', '0', '1467392682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13344', 'ltc_cny', '', '1', '0', '1467392742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13345', 'ltc_cny', '', '1', '0', '1467392802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13346', 'ltc_cny', '', '1', '0', '1467392862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13347', 'ltc_cny', '', '1', '0', '1467392922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13348', 'ltc_cny', '', '1', '0', '1467392982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13349', 'ltc_cny', '', '1', '0', '1467393042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13350', 'ltc_cny', '', '1', '0', '1467393102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13351', 'ltc_cny', '', '1', '0', '1467393162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13352', 'ltc_cny', '', '1', '0', '1467393222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13353', 'ltc_cny', '', '1', '0', '1467393282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13354', 'ltc_cny', '', '1', '0', '1467393342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13376', 'btc_cny', '', '1', '0', '1467463892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13377', 'btc_cny', '', '1', '0', '1467463952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13378', 'btc_cny', '', '1', '0', '1467464012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13379', 'btc_cny', '', '1', '0', '1467464072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13380', 'btc_cny', '', '1', '0', '1467464132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13381', 'btc_cny', '', '1', '0', '1467464192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13382', 'btc_cny', '', '1', '0', '1467464252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13383', 'btc_cny', '', '1', '0', '1467464312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13384', 'btc_cny', '', '1', '0', '1467464372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13385', 'btc_cny', '', '1', '0', '1467464432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13386', 'btc_cny', '', '1', '0', '1467464492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13387', 'btc_cny', '', '1', '0', '1467464552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13388', 'btc_cny', '', '1', '0', '1467464612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13389', 'btc_cny', '', '1', '0', '1467464672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13390', 'btc_cny', '', '1', '0', '1467464732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13391', 'btc_cny', '', '1', '0', '1467464792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13392', 'btc_cny', '', '1', '0', '1467464852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13393', 'btc_cny', '', '1', '0', '1467464912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13394', 'btc_cny', '', '1', '0', '1467464972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13395', 'btc_cny', '', '1', '0', '1467465032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13396', 'btc_cny', '', '1', '0', '1467465092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13397', 'ltc_cny', '', '1', '0', '1467393342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13398', 'ltc_cny', '', '1', '0', '1467393402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13399', 'ltc_cny', '', '1', '0', '1467393462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13400', 'ltc_cny', '', '1', '0', '1467393522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13401', 'ltc_cny', '', '1', '0', '1467393582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13402', 'ltc_cny', '', '1', '0', '1467393642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13403', 'ltc_cny', '', '1', '0', '1467393702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13404', 'ltc_cny', '', '1', '0', '1467393762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13405', 'ltc_cny', '', '1', '0', '1467393822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13406', 'ltc_cny', '', '1', '0', '1467393882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13407', 'ltc_cny', '', '1', '0', '1467393942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13408', 'ltc_cny', '', '1', '0', '1467394002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13409', 'ltc_cny', '', '1', '0', '1467394062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13410', 'ltc_cny', '', '1', '0', '1467394122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13411', 'ltc_cny', '', '1', '0', '1467394182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13412', 'ltc_cny', '', '1', '0', '1467394242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13413', 'ltc_cny', '', '1', '0', '1467394302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13414', 'ltc_cny', '', '1', '0', '1467394362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13415', 'ltc_cny', '', '1', '0', '1467394422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13416', 'ltc_cny', '', '1', '0', '1467394482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13417', 'ltc_cny', '', '1', '0', '1467394542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13439', 'btc_cny', '', '1', '0', '1467465092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13440', 'btc_cny', '', '1', '0', '1467465152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13441', 'btc_cny', '', '1', '0', '1467465212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13442', 'btc_cny', '', '1', '0', '1467465272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13443', 'btc_cny', '', '1', '0', '1467465332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13444', 'btc_cny', '', '1', '0', '1467465392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13445', 'btc_cny', '', '1', '0', '1467465452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13446', 'btc_cny', '', '1', '0', '1467465512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13447', 'btc_cny', '', '1', '0', '1467465572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13448', 'btc_cny', '', '1', '0', '1467465632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13449', 'btc_cny', '', '1', '0', '1467465692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13450', 'btc_cny', '', '1', '0', '1467465752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13451', 'btc_cny', '', '1', '0', '1467465812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13452', 'btc_cny', '', '1', '0', '1467465872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13453', 'btc_cny', '', '1', '0', '1467465932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13454', 'btc_cny', '', '1', '0', '1467465992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13455', 'btc_cny', '', '1', '0', '1467466052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13456', 'btc_cny', '', '1', '0', '1467466112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13457', 'btc_cny', '', '1', '0', '1467466172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13458', 'btc_cny', '', '1', '0', '1467466232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13459', 'btc_cny', '', '1', '0', '1467466292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13460', 'ltc_cny', '', '1', '0', '1467394542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13461', 'ltc_cny', '', '1', '0', '1467394602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13462', 'ltc_cny', '', '1', '0', '1467394662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13463', 'ltc_cny', '', '1', '0', '1467394722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13464', 'ltc_cny', '', '1', '0', '1467394782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13465', 'ltc_cny', '', '1', '0', '1467394842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13466', 'ltc_cny', '', '1', '0', '1467394902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13467', 'ltc_cny', '', '1', '0', '1467394962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13468', 'ltc_cny', '', '1', '0', '1467395022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13469', 'ltc_cny', '', '1', '0', '1467395082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13470', 'ltc_cny', '', '1', '0', '1467395142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13471', 'ltc_cny', '', '1', '0', '1467395202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13472', 'ltc_cny', '', '1', '0', '1467395262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13473', 'ltc_cny', '', '1', '0', '1467395322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13474', 'ltc_cny', '', '1', '0', '1467395382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13475', 'ltc_cny', '', '1', '0', '1467395442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13476', 'ltc_cny', '', '1', '0', '1467395502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13477', 'ltc_cny', '', '1', '0', '1467395562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13478', 'ltc_cny', '', '1', '0', '1467395622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13479', 'ltc_cny', '', '1', '0', '1467395682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13480', 'ltc_cny', '', '1', '0', '1467395742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13502', 'btc_cny', '', '1', '0', '1467466292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13503', 'btc_cny', '', '1', '0', '1467466352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13504', 'btc_cny', '', '1', '0', '1467466412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13505', 'btc_cny', '', '1', '0', '1467466472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13506', 'btc_cny', '', '1', '0', '1467466532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13507', 'btc_cny', '', '1', '0', '1467466592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13508', 'btc_cny', '', '1', '0', '1467466652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13509', 'btc_cny', '', '1', '0', '1467466712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13510', 'btc_cny', '', '1', '0', '1467466772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13511', 'btc_cny', '', '1', '0', '1467466832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13512', 'btc_cny', '', '1', '0', '1467466892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13513', 'btc_cny', '', '1', '0', '1467466952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13514', 'btc_cny', '', '1', '0', '1467467012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13515', 'btc_cny', '', '1', '0', '1467467072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13516', 'btc_cny', '', '1', '0', '1467467132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13517', 'btc_cny', '', '1', '0', '1467467192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13518', 'btc_cny', '', '1', '0', '1467467252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13519', 'btc_cny', '', '1', '0', '1467467312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13520', 'btc_cny', '', '1', '0', '1467467372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13521', 'btc_cny', '', '1', '0', '1467467432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13522', 'btc_cny', '', '1', '0', '1467467492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13523', 'ltc_cny', '', '1', '0', '1467395742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13524', 'ltc_cny', '', '1', '0', '1467395802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13525', 'ltc_cny', '', '1', '0', '1467395862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13526', 'ltc_cny', '', '1', '0', '1467395922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13527', 'ltc_cny', '', '1', '0', '1467395982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13528', 'ltc_cny', '', '1', '0', '1467396042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13529', 'ltc_cny', '', '1', '0', '1467396102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13530', 'ltc_cny', '', '1', '0', '1467396162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13531', 'ltc_cny', '', '1', '0', '1467396222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13532', 'ltc_cny', '', '1', '0', '1467396282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13533', 'ltc_cny', '', '1', '0', '1467396342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13534', 'ltc_cny', '', '1', '0', '1467396402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13535', 'ltc_cny', '', '1', '0', '1467396462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13536', 'ltc_cny', '', '1', '0', '1467396522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13537', 'ltc_cny', '', '1', '0', '1467396582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13538', 'ltc_cny', '', '1', '0', '1467396642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13539', 'ltc_cny', '', '1', '0', '1467396702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13540', 'ltc_cny', '', '1', '0', '1467396762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13541', 'ltc_cny', '', '1', '0', '1467396822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13542', 'ltc_cny', '', '1', '0', '1467396882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13543', 'ltc_cny', '', '1', '0', '1467396942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13565', 'btc_cny', '', '1', '0', '1467467492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13566', 'btc_cny', '', '1', '0', '1467467552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13567', 'btc_cny', '', '1', '0', '1467467612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13568', 'btc_cny', '', '1', '0', '1467467672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13569', 'btc_cny', '', '1', '0', '1467467732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13570', 'btc_cny', '', '1', '0', '1467467792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13571', 'btc_cny', '', '1', '0', '1467467852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13572', 'btc_cny', '', '1', '0', '1467467912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13573', 'btc_cny', '', '1', '0', '1467467972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13574', 'btc_cny', '', '1', '0', '1467468032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13575', 'btc_cny', '', '1', '0', '1467468092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13576', 'btc_cny', '', '1', '0', '1467468152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13577', 'btc_cny', '', '1', '0', '1467468212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13578', 'btc_cny', '', '1', '0', '1467468272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13579', 'btc_cny', '', '1', '0', '1467468332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13580', 'btc_cny', '', '1', '0', '1467468392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13581', 'btc_cny', '', '1', '0', '1467468452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13582', 'btc_cny', '', '1', '0', '1467468512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13583', 'btc_cny', '', '1', '0', '1467468572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13584', 'btc_cny', '', '1', '0', '1467468632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13585', 'btc_cny', '', '1', '0', '1467468692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13586', 'ltc_cny', '', '1', '0', '1467396942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13587', 'ltc_cny', '', '1', '0', '1467397002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13588', 'ltc_cny', '', '1', '0', '1467397062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13589', 'ltc_cny', '', '1', '0', '1467397122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13590', 'ltc_cny', '', '1', '0', '1467397182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13591', 'ltc_cny', '', '1', '0', '1467397242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13592', 'ltc_cny', '', '1', '0', '1467397302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13593', 'ltc_cny', '', '1', '0', '1467397362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13594', 'ltc_cny', '', '1', '0', '1467397422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13595', 'ltc_cny', '', '1', '0', '1467397482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13596', 'ltc_cny', '', '1', '0', '1467397542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13597', 'ltc_cny', '', '1', '0', '1467397602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13598', 'ltc_cny', '', '1', '0', '1467397662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13599', 'ltc_cny', '', '1', '0', '1467397722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13600', 'ltc_cny', '', '1', '0', '1467397782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13601', 'ltc_cny', '', '1', '0', '1467397842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13602', 'ltc_cny', '', '1', '0', '1467397902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13603', 'ltc_cny', '', '1', '0', '1467397962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13604', 'ltc_cny', '', '1', '0', '1467398022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13605', 'ltc_cny', '', '1', '0', '1467398082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13606', 'ltc_cny', '', '1', '0', '1467398142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13610', 'ltc_cny', '[1467608760,\"1.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\"]', '3', '0', '1467608760', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13611', 'ltc_cny', '[1467608940,\"44.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\",\"30.00000000\"]', '3', '0', '1467608940', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13612', 'ltc_cny', '', '3', '0', '1467609120', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13613', 'ltc_cny', '', '3', '0', '1467609300', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13614', 'ltc_cny', '', '3', '0', '1467609480', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13615', 'ltc_cny', '', '3', '0', '1467609660', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13616', 'ltc_cny', '', '3', '0', '1467609840', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13617', 'ltc_cny', '', '3', '0', '1467610020', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13618', 'ltc_cny', '', '3', '0', '1467610200', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13619', 'ltc_cny', '', '3', '0', '1467610380', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13620', 'ltc_cny', '', '3', '0', '1467610560', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13621', 'ltc_cny', '', '3', '0', '1467610740', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13622', 'ltc_cny', '', '3', '0', '1467610920', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13623', 'ltc_cny', '', '3', '0', '1467611100', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13624', 'ltc_cny', '', '3', '0', '1467611280', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13625', 'ltc_cny', '', '3', '0', '1467611460', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13626', 'ltc_cny', '', '3', '0', '1467611640', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13627', 'ltc_cny', '', '3', '0', '1467611820', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13628', 'btc_cny', '', '1', '0', '1467468692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13629', 'btc_cny', '', '1', '0', '1467468752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13630', 'btc_cny', '', '1', '0', '1467468812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13631', 'btc_cny', '', '1', '0', '1467468872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13632', 'btc_cny', '', '1', '0', '1467468932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13633', 'btc_cny', '', '1', '0', '1467468992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13634', 'btc_cny', '', '1', '0', '1467469052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13635', 'btc_cny', '', '1', '0', '1467469112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13636', 'btc_cny', '', '1', '0', '1467469172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13637', 'btc_cny', '', '1', '0', '1467469232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13638', 'btc_cny', '', '1', '0', '1467469292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13639', 'btc_cny', '', '1', '0', '1467469352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13640', 'btc_cny', '', '1', '0', '1467469412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13641', 'btc_cny', '', '1', '0', '1467469472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13642', 'btc_cny', '', '1', '0', '1467469532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13643', 'btc_cny', '', '1', '0', '1467469592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13644', 'btc_cny', '', '1', '0', '1467469652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13645', 'btc_cny', '', '1', '0', '1467469712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13646', 'btc_cny', '', '1', '0', '1467469772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13647', 'btc_cny', '', '1', '0', '1467469832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13648', 'btc_cny', '', '1', '0', '1467469892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13649', 'ltc_cny', '', '1', '0', '1467398142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13650', 'ltc_cny', '', '1', '0', '1467398202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13651', 'ltc_cny', '', '1', '0', '1467398262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13652', 'ltc_cny', '', '1', '0', '1467398322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13653', 'ltc_cny', '', '1', '0', '1467398382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13654', 'ltc_cny', '', '1', '0', '1467398442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13655', 'ltc_cny', '', '1', '0', '1467398502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13656', 'ltc_cny', '', '1', '0', '1467398562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13657', 'ltc_cny', '', '1', '0', '1467398622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13658', 'ltc_cny', '', '1', '0', '1467398682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13659', 'ltc_cny', '', '1', '0', '1467398742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13660', 'ltc_cny', '', '1', '0', '1467398802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13661', 'ltc_cny', '', '1', '0', '1467398862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13662', 'ltc_cny', '', '1', '0', '1467398922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13663', 'ltc_cny', '', '1', '0', '1467398982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13664', 'ltc_cny', '', '1', '0', '1467399042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13665', 'ltc_cny', '', '1', '0', '1467399102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13666', 'ltc_cny', '', '1', '0', '1467399162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13667', 'ltc_cny', '', '1', '0', '1467399222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13668', 'ltc_cny', '', '1', '0', '1467399282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13669', 'ltc_cny', '', '1', '0', '1467399342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13670', 'btc_cny', '', '1', '0', '1467469892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13671', 'btc_cny', '', '1', '0', '1467469952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13672', 'btc_cny', '', '1', '0', '1467470012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13673', 'btc_cny', '', '1', '0', '1467470072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13674', 'btc_cny', '', '1', '0', '1467470132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13675', 'btc_cny', '', '1', '0', '1467470192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13676', 'btc_cny', '', '1', '0', '1467470252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13677', 'btc_cny', '', '1', '0', '1467470312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13678', 'btc_cny', '', '1', '0', '1467470372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13679', 'btc_cny', '', '1', '0', '1467470432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13680', 'btc_cny', '', '1', '0', '1467470492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13681', 'btc_cny', '', '1', '0', '1467470552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13682', 'btc_cny', '', '1', '0', '1467470612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13683', 'btc_cny', '', '1', '0', '1467470672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13684', 'btc_cny', '', '1', '0', '1467470732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13685', 'btc_cny', '', '1', '0', '1467470792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13686', 'btc_cny', '', '1', '0', '1467470852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13687', 'btc_cny', '', '1', '0', '1467470912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13688', 'btc_cny', '', '1', '0', '1467470972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13689', 'btc_cny', '', '1', '0', '1467471032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13690', 'btc_cny', '', '1', '0', '1467471092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13691', 'ltc_cny', '', '1', '0', '1467399342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13692', 'ltc_cny', '', '1', '0', '1467399402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13693', 'ltc_cny', '', '1', '0', '1467399462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13694', 'ltc_cny', '', '1', '0', '1467399522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13695', 'ltc_cny', '', '1', '0', '1467399582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13696', 'ltc_cny', '', '1', '0', '1467399642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13697', 'ltc_cny', '', '1', '0', '1467399702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13698', 'ltc_cny', '', '1', '0', '1467399762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13699', 'ltc_cny', '', '1', '0', '1467399822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13700', 'ltc_cny', '', '1', '0', '1467399882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13701', 'ltc_cny', '', '1', '0', '1467399942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13702', 'ltc_cny', '', '1', '0', '1467400002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13703', 'ltc_cny', '', '1', '0', '1467400062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13704', 'ltc_cny', '', '1', '0', '1467400122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13705', 'ltc_cny', '', '1', '0', '1467400182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13706', 'ltc_cny', '', '1', '0', '1467400242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13707', 'ltc_cny', '', '1', '0', '1467400302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13708', 'ltc_cny', '', '1', '0', '1467400362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13709', 'ltc_cny', '', '1', '0', '1467400422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13710', 'ltc_cny', '', '1', '0', '1467400482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13711', 'ltc_cny', '', '1', '0', '1467400542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13712', 'btc_cny', '', '1', '0', '1467471092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13713', 'btc_cny', '', '1', '0', '1467471152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13714', 'btc_cny', '', '1', '0', '1467471212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13715', 'btc_cny', '', '1', '0', '1467471272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13716', 'btc_cny', '', '1', '0', '1467471332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13717', 'btc_cny', '', '1', '0', '1467471392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13718', 'btc_cny', '', '1', '0', '1467471452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13719', 'btc_cny', '', '1', '0', '1467471512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13720', 'btc_cny', '', '1', '0', '1467471572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13721', 'btc_cny', '', '1', '0', '1467471632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13722', 'btc_cny', '', '1', '0', '1467471692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13723', 'btc_cny', '', '1', '0', '1467471752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13724', 'btc_cny', '', '1', '0', '1467471812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13725', 'btc_cny', '', '1', '0', '1467471872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13726', 'btc_cny', '', '1', '0', '1467471932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13727', 'btc_cny', '', '1', '0', '1467471992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13728', 'btc_cny', '', '1', '0', '1467472052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13729', 'btc_cny', '', '1', '0', '1467472112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13730', 'btc_cny', '', '1', '0', '1467472172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13731', 'btc_cny', '', '1', '0', '1467472232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13732', 'btc_cny', '', '1', '0', '1467472292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13733', 'ltc_cny', '', '1', '0', '1467400542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13734', 'ltc_cny', '', '1', '0', '1467400602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13735', 'ltc_cny', '', '1', '0', '1467400662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13736', 'ltc_cny', '', '1', '0', '1467400722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13737', 'ltc_cny', '', '1', '0', '1467400782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13738', 'ltc_cny', '', '1', '0', '1467400842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13739', 'ltc_cny', '', '1', '0', '1467400902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13740', 'ltc_cny', '', '1', '0', '1467400962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13741', 'ltc_cny', '', '1', '0', '1467401022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13742', 'ltc_cny', '', '1', '0', '1467401082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13743', 'ltc_cny', '', '1', '0', '1467401142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13744', 'ltc_cny', '', '1', '0', '1467401202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13745', 'ltc_cny', '', '1', '0', '1467401262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13746', 'ltc_cny', '', '1', '0', '1467401322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13747', 'ltc_cny', '', '1', '0', '1467401382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13748', 'ltc_cny', '', '1', '0', '1467401442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13749', 'ltc_cny', '', '1', '0', '1467401502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13750', 'ltc_cny', '', '1', '0', '1467401562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13751', 'ltc_cny', '', '1', '0', '1467401622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13752', 'ltc_cny', '', '1', '0', '1467401682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13753', 'ltc_cny', '', '1', '0', '1467401742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13754', 'btc_cny', '', '1', '0', '1467472292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13755', 'btc_cny', '', '1', '0', '1467472352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13756', 'btc_cny', '', '1', '0', '1467472412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13757', 'btc_cny', '', '1', '0', '1467472472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13758', 'btc_cny', '', '1', '0', '1467472532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13759', 'btc_cny', '', '1', '0', '1467472592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13760', 'btc_cny', '', '1', '0', '1467472652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13761', 'btc_cny', '', '1', '0', '1467472712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13762', 'btc_cny', '', '1', '0', '1467472772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13763', 'btc_cny', '', '1', '0', '1467472832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13764', 'btc_cny', '', '1', '0', '1467472892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13765', 'btc_cny', '', '1', '0', '1467472952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13766', 'btc_cny', '', '1', '0', '1467473012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13767', 'btc_cny', '', '1', '0', '1467473072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13768', 'btc_cny', '', '1', '0', '1467473132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13769', 'btc_cny', '', '1', '0', '1467473192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13770', 'btc_cny', '', '1', '0', '1467473252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13771', 'btc_cny', '', '1', '0', '1467473312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13772', 'btc_cny', '', '1', '0', '1467473372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13773', 'btc_cny', '', '1', '0', '1467473432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13774', 'btc_cny', '', '1', '0', '1467473492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13775', 'ltc_cny', '', '1', '0', '1467401742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13776', 'ltc_cny', '', '1', '0', '1467401802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13777', 'ltc_cny', '', '1', '0', '1467401862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13778', 'ltc_cny', '', '1', '0', '1467401922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13779', 'ltc_cny', '', '1', '0', '1467401982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13780', 'ltc_cny', '', '1', '0', '1467402042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13781', 'ltc_cny', '', '1', '0', '1467402102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13782', 'ltc_cny', '', '1', '0', '1467402162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13783', 'ltc_cny', '', '1', '0', '1467402222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13784', 'ltc_cny', '', '1', '0', '1467402282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13785', 'ltc_cny', '', '1', '0', '1467402342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13786', 'ltc_cny', '', '1', '0', '1467402402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13787', 'ltc_cny', '', '1', '0', '1467402462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13788', 'ltc_cny', '', '1', '0', '1467402522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13789', 'ltc_cny', '', '1', '0', '1467402582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13790', 'ltc_cny', '', '1', '0', '1467402642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13791', 'ltc_cny', '', '1', '0', '1467402702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13792', 'ltc_cny', '', '1', '0', '1467402762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13793', 'ltc_cny', '', '1', '0', '1467402822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13794', 'ltc_cny', '', '1', '0', '1467402882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13795', 'ltc_cny', '', '1', '0', '1467402942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13796', 'btc_cny', '', '1', '0', '1467473492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13797', 'btc_cny', '', '1', '0', '1467473552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13798', 'btc_cny', '', '1', '0', '1467473612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13799', 'btc_cny', '', '1', '0', '1467473672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13800', 'btc_cny', '', '1', '0', '1467473732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13801', 'btc_cny', '', '1', '0', '1467473792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13802', 'btc_cny', '', '1', '0', '1467473852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13803', 'btc_cny', '', '1', '0', '1467473912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13804', 'btc_cny', '', '1', '0', '1467473972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13805', 'btc_cny', '', '1', '0', '1467474032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13806', 'btc_cny', '', '1', '0', '1467474092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13807', 'btc_cny', '', '1', '0', '1467474152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13808', 'btc_cny', '', '1', '0', '1467474212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13809', 'btc_cny', '', '1', '0', '1467474272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13810', 'btc_cny', '', '1', '0', '1467474332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13811', 'btc_cny', '', '1', '0', '1467474392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13812', 'btc_cny', '', '1', '0', '1467474452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13813', 'btc_cny', '', '1', '0', '1467474512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13814', 'btc_cny', '', '1', '0', '1467474572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13815', 'btc_cny', '', '1', '0', '1467474632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13816', 'btc_cny', '', '1', '0', '1467474692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13817', 'ltc_cny', '', '1', '0', '1467402942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13818', 'ltc_cny', '', '1', '0', '1467403002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13819', 'ltc_cny', '', '1', '0', '1467403062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13820', 'ltc_cny', '', '1', '0', '1467403122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13821', 'ltc_cny', '', '1', '0', '1467403182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13822', 'ltc_cny', '', '1', '0', '1467403242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13823', 'ltc_cny', '', '1', '0', '1467403302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13824', 'ltc_cny', '', '1', '0', '1467403362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13825', 'ltc_cny', '', '1', '0', '1467403422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13826', 'ltc_cny', '', '1', '0', '1467403482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13827', 'ltc_cny', '', '1', '0', '1467403542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13828', 'ltc_cny', '', '1', '0', '1467403602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13829', 'ltc_cny', '', '1', '0', '1467403662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13830', 'ltc_cny', '', '1', '0', '1467403722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13831', 'ltc_cny', '', '1', '0', '1467403782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13832', 'ltc_cny', '', '1', '0', '1467403842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13833', 'ltc_cny', '', '1', '0', '1467403902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13834', 'ltc_cny', '', '1', '0', '1467403962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13835', 'ltc_cny', '', '1', '0', '1467404022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13836', 'ltc_cny', '', '1', '0', '1467404082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13837', 'ltc_cny', '', '1', '0', '1467404142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13838', 'btc_cny', '', '1', '0', '1467474692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13839', 'btc_cny', '', '1', '0', '1467474752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13840', 'btc_cny', '', '1', '0', '1467474812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13841', 'btc_cny', '', '1', '0', '1467474872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13842', 'btc_cny', '', '1', '0', '1467474932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13843', 'btc_cny', '', '1', '0', '1467474992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13844', 'btc_cny', '', '1', '0', '1467475052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13845', 'btc_cny', '', '1', '0', '1467475112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13846', 'btc_cny', '', '1', '0', '1467475172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13847', 'btc_cny', '', '1', '0', '1467475232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13848', 'btc_cny', '', '1', '0', '1467475292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13849', 'btc_cny', '', '1', '0', '1467475352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13850', 'btc_cny', '', '1', '0', '1467475412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13851', 'btc_cny', '', '1', '0', '1467475472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13852', 'btc_cny', '', '1', '0', '1467475532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13853', 'btc_cny', '', '1', '0', '1467475592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13854', 'btc_cny', '', '1', '0', '1467475652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13855', 'btc_cny', '', '1', '0', '1467475712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13856', 'btc_cny', '', '1', '0', '1467475772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13857', 'btc_cny', '', '1', '0', '1467475832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13858', 'btc_cny', '', '1', '0', '1467475892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13859', 'ltc_cny', '', '1', '0', '1467404142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13860', 'ltc_cny', '', '1', '0', '1467404202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13861', 'ltc_cny', '', '1', '0', '1467404262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13862', 'ltc_cny', '', '1', '0', '1467404322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13863', 'ltc_cny', '', '1', '0', '1467404382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13864', 'ltc_cny', '', '1', '0', '1467404442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13865', 'ltc_cny', '', '1', '0', '1467404502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13866', 'ltc_cny', '', '1', '0', '1467404562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13867', 'ltc_cny', '', '1', '0', '1467404622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13868', 'ltc_cny', '', '1', '0', '1467404682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13869', 'ltc_cny', '', '1', '0', '1467404742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13870', 'ltc_cny', '', '1', '0', '1467404802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13871', 'ltc_cny', '', '1', '0', '1467404862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13872', 'ltc_cny', '', '1', '0', '1467404922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13873', 'ltc_cny', '', '1', '0', '1467404982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13874', 'ltc_cny', '', '1', '0', '1467405042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13875', 'ltc_cny', '', '1', '0', '1467405102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13876', 'ltc_cny', '', '1', '0', '1467405162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13877', 'ltc_cny', '', '1', '0', '1467405222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13878', 'ltc_cny', '', '1', '0', '1467405282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13879', 'ltc_cny', '', '1', '0', '1467405342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13880', 'btc_cny', '', '1', '0', '1467475892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13881', 'btc_cny', '', '1', '0', '1467475952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13882', 'btc_cny', '', '1', '0', '1467476012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13883', 'btc_cny', '', '1', '0', '1467476072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13884', 'btc_cny', '', '1', '0', '1467476132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13885', 'btc_cny', '', '1', '0', '1467476192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13886', 'btc_cny', '', '1', '0', '1467476252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13887', 'btc_cny', '', '1', '0', '1467476312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13888', 'btc_cny', '', '1', '0', '1467476372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13889', 'btc_cny', '', '1', '0', '1467476432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13890', 'btc_cny', '', '1', '0', '1467476492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13891', 'btc_cny', '', '1', '0', '1467476552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13892', 'btc_cny', '', '1', '0', '1467476612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13893', 'btc_cny', '', '1', '0', '1467476672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13894', 'btc_cny', '', '1', '0', '1467476732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13895', 'btc_cny', '', '1', '0', '1467476792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13896', 'btc_cny', '', '1', '0', '1467476852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13897', 'btc_cny', '', '1', '0', '1467476912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13898', 'btc_cny', '', '1', '0', '1467476972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13899', 'btc_cny', '', '1', '0', '1467477032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13900', 'btc_cny', '', '1', '0', '1467477092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13901', 'ltc_cny', '', '1', '0', '1467405342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13902', 'ltc_cny', '', '1', '0', '1467405402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13903', 'ltc_cny', '', '1', '0', '1467405462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13904', 'ltc_cny', '', '1', '0', '1467405522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13905', 'ltc_cny', '', '1', '0', '1467405582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13906', 'ltc_cny', '', '1', '0', '1467405642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13907', 'ltc_cny', '', '1', '0', '1467405702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13908', 'ltc_cny', '', '1', '0', '1467405762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13909', 'ltc_cny', '', '1', '0', '1467405822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13910', 'ltc_cny', '', '1', '0', '1467405882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13911', 'ltc_cny', '', '1', '0', '1467405942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13912', 'ltc_cny', '', '1', '0', '1467406002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13913', 'ltc_cny', '', '1', '0', '1467406062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13914', 'ltc_cny', '', '1', '0', '1467406122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13915', 'ltc_cny', '', '1', '0', '1467406182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13916', 'ltc_cny', '', '1', '0', '1467406242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13917', 'ltc_cny', '', '1', '0', '1467406302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13918', 'ltc_cny', '', '1', '0', '1467406362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13919', 'ltc_cny', '', '1', '0', '1467406422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13920', 'ltc_cny', '', '1', '0', '1467406482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13921', 'ltc_cny', '', '1', '0', '1467406542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13922', 'btc_cny', '', '1', '0', '1467477092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13923', 'btc_cny', '', '1', '0', '1467477152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13924', 'btc_cny', '', '1', '0', '1467477212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13925', 'btc_cny', '', '1', '0', '1467477272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13926', 'btc_cny', '', '1', '0', '1467477332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13927', 'btc_cny', '', '1', '0', '1467477392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13928', 'btc_cny', '', '1', '0', '1467477452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13929', 'btc_cny', '', '1', '0', '1467477512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13930', 'btc_cny', '', '1', '0', '1467477572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13931', 'btc_cny', '', '1', '0', '1467477632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13932', 'btc_cny', '', '1', '0', '1467477692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13933', 'btc_cny', '', '1', '0', '1467477752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13934', 'btc_cny', '', '1', '0', '1467477812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13935', 'btc_cny', '', '1', '0', '1467477872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13936', 'btc_cny', '', '1', '0', '1467477932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13937', 'btc_cny', '', '1', '0', '1467477992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13938', 'btc_cny', '', '1', '0', '1467478052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13939', 'btc_cny', '', '1', '0', '1467478112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13940', 'btc_cny', '', '1', '0', '1467478172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13941', 'btc_cny', '', '1', '0', '1467478232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13942', 'btc_cny', '', '1', '0', '1467478292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13943', 'ltc_cny', '', '1', '0', '1467406542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13944', 'ltc_cny', '', '1', '0', '1467406602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13945', 'ltc_cny', '', '1', '0', '1467406662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13946', 'ltc_cny', '', '1', '0', '1467406722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13947', 'ltc_cny', '', '1', '0', '1467406782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13948', 'ltc_cny', '', '1', '0', '1467406842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13949', 'ltc_cny', '', '1', '0', '1467406902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13950', 'ltc_cny', '', '1', '0', '1467406962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13951', 'ltc_cny', '', '1', '0', '1467407022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13952', 'ltc_cny', '', '1', '0', '1467407082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13953', 'ltc_cny', '', '1', '0', '1467407142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13954', 'ltc_cny', '', '1', '0', '1467407202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13955', 'ltc_cny', '', '1', '0', '1467407262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13956', 'ltc_cny', '', '1', '0', '1467407322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13957', 'ltc_cny', '', '1', '0', '1467407382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13958', 'ltc_cny', '', '1', '0', '1467407442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13959', 'ltc_cny', '', '1', '0', '1467407502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13960', 'ltc_cny', '', '1', '0', '1467407562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13961', 'ltc_cny', '', '1', '0', '1467407622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13962', 'ltc_cny', '', '1', '0', '1467407682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13963', 'ltc_cny', '', '1', '0', '1467407742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13964', 'btc_cny', '', '1', '0', '1467478292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13965', 'btc_cny', '', '1', '0', '1467478352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13966', 'btc_cny', '', '1', '0', '1467478412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13967', 'btc_cny', '', '1', '0', '1467478472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13968', 'btc_cny', '', '1', '0', '1467478532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13969', 'btc_cny', '', '1', '0', '1467478592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13970', 'btc_cny', '', '1', '0', '1467478652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13971', 'btc_cny', '', '1', '0', '1467478712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13972', 'btc_cny', '', '1', '0', '1467478772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13973', 'btc_cny', '', '1', '0', '1467478832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13974', 'btc_cny', '', '1', '0', '1467478892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13975', 'btc_cny', '', '1', '0', '1467478952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13976', 'btc_cny', '', '1', '0', '1467479012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13977', 'btc_cny', '', '1', '0', '1467479072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13978', 'btc_cny', '', '1', '0', '1467479132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13979', 'btc_cny', '', '1', '0', '1467479192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13980', 'btc_cny', '', '1', '0', '1467479252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13981', 'btc_cny', '', '1', '0', '1467479312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13982', 'btc_cny', '', '1', '0', '1467479372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13983', 'btc_cny', '', '1', '0', '1467479432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13984', 'btc_cny', '', '1', '0', '1467479492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13985', 'ltc_cny', '', '1', '0', '1467407742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13986', 'ltc_cny', '', '1', '0', '1467407802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13987', 'ltc_cny', '', '1', '0', '1467407862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13988', 'ltc_cny', '', '1', '0', '1467407922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13989', 'ltc_cny', '', '1', '0', '1467407982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13990', 'ltc_cny', '', '1', '0', '1467408042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13991', 'ltc_cny', '', '1', '0', '1467408102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13992', 'ltc_cny', '', '1', '0', '1467408162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13993', 'ltc_cny', '', '1', '0', '1467408222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13994', 'ltc_cny', '', '1', '0', '1467408282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13995', 'ltc_cny', '', '1', '0', '1467408342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13996', 'ltc_cny', '', '1', '0', '1467408402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13997', 'ltc_cny', '', '1', '0', '1467408462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13998', 'ltc_cny', '', '1', '0', '1467408522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('13999', 'ltc_cny', '', '1', '0', '1467408582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14000', 'ltc_cny', '', '1', '0', '1467408642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14001', 'ltc_cny', '', '1', '0', '1467408702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14002', 'ltc_cny', '', '1', '0', '1467408762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14003', 'ltc_cny', '', '1', '0', '1467408822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14004', 'ltc_cny', '', '1', '0', '1467408882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14005', 'ltc_cny', '', '1', '0', '1467408942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14006', 'btc_cny', '', '1', '0', '1467479492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14007', 'btc_cny', '', '1', '0', '1467479552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14008', 'btc_cny', '', '1', '0', '1467479612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14009', 'btc_cny', '', '1', '0', '1467479672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14010', 'btc_cny', '', '1', '0', '1467479732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14011', 'btc_cny', '', '1', '0', '1467479792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14012', 'btc_cny', '', '1', '0', '1467479852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14013', 'btc_cny', '', '1', '0', '1467479912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14014', 'btc_cny', '', '1', '0', '1467479972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14015', 'btc_cny', '', '1', '0', '1467480032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14016', 'btc_cny', '', '1', '0', '1467480092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14017', 'btc_cny', '', '1', '0', '1467480152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14018', 'btc_cny', '', '1', '0', '1467480212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14019', 'btc_cny', '', '1', '0', '1467480272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14020', 'btc_cny', '', '1', '0', '1467480332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14021', 'btc_cny', '', '1', '0', '1467480392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14022', 'btc_cny', '', '1', '0', '1467480452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14023', 'btc_cny', '', '1', '0', '1467480512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14024', 'btc_cny', '', '1', '0', '1467480572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14025', 'btc_cny', '', '1', '0', '1467480632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14026', 'btc_cny', '', '1', '0', '1467480692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14027', 'ltc_cny', '', '1', '0', '1467408942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14028', 'ltc_cny', '', '1', '0', '1467409002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14029', 'ltc_cny', '', '1', '0', '1467409062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14030', 'ltc_cny', '', '1', '0', '1467409122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14031', 'ltc_cny', '', '1', '0', '1467409182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14032', 'ltc_cny', '', '1', '0', '1467409242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14033', 'ltc_cny', '', '1', '0', '1467409302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14034', 'ltc_cny', '', '1', '0', '1467409362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14035', 'ltc_cny', '', '1', '0', '1467409422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14036', 'ltc_cny', '', '1', '0', '1467409482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14037', 'ltc_cny', '', '1', '0', '1467409542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14038', 'ltc_cny', '', '1', '0', '1467409602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14039', 'ltc_cny', '', '1', '0', '1467409662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14040', 'ltc_cny', '', '1', '0', '1467409722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14041', 'ltc_cny', '', '1', '0', '1467409782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14042', 'ltc_cny', '', '1', '0', '1467409842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14043', 'ltc_cny', '', '1', '0', '1467409902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14044', 'ltc_cny', '', '1', '0', '1467409962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14045', 'ltc_cny', '', '1', '0', '1467410022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14046', 'ltc_cny', '', '1', '0', '1467410082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14047', 'ltc_cny', '', '1', '0', '1467410142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14048', 'btc_cny', '', '1', '0', '1467480692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14049', 'btc_cny', '', '1', '0', '1467480752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14050', 'btc_cny', '', '1', '0', '1467480812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14051', 'btc_cny', '', '1', '0', '1467480872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14052', 'btc_cny', '', '1', '0', '1467480932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14053', 'btc_cny', '', '1', '0', '1467480992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14054', 'btc_cny', '', '1', '0', '1467481052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14055', 'btc_cny', '', '1', '0', '1467481112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14056', 'btc_cny', '', '1', '0', '1467481172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14057', 'btc_cny', '', '1', '0', '1467481232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14058', 'btc_cny', '', '1', '0', '1467481292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14059', 'btc_cny', '', '1', '0', '1467481352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14060', 'btc_cny', '', '1', '0', '1467481412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14061', 'btc_cny', '', '1', '0', '1467481472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14062', 'btc_cny', '', '1', '0', '1467481532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14063', 'btc_cny', '', '1', '0', '1467481592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14064', 'btc_cny', '', '1', '0', '1467481652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14065', 'btc_cny', '', '1', '0', '1467481712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14066', 'btc_cny', '', '1', '0', '1467481772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14067', 'btc_cny', '', '1', '0', '1467481832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14068', 'btc_cny', '', '1', '0', '1467481892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14069', 'ltc_cny', '', '1', '0', '1467410142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14070', 'ltc_cny', '', '1', '0', '1467410202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14071', 'ltc_cny', '', '1', '0', '1467410262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14072', 'ltc_cny', '', '1', '0', '1467410322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14073', 'ltc_cny', '', '1', '0', '1467410382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14074', 'ltc_cny', '', '1', '0', '1467410442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14075', 'ltc_cny', '', '1', '0', '1467410502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14076', 'ltc_cny', '', '1', '0', '1467410562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14077', 'ltc_cny', '', '1', '0', '1467410622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14078', 'ltc_cny', '', '1', '0', '1467410682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14079', 'ltc_cny', '', '1', '0', '1467410742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14080', 'ltc_cny', '', '1', '0', '1467410802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14081', 'ltc_cny', '', '1', '0', '1467410862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14082', 'ltc_cny', '', '1', '0', '1467410922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14083', 'ltc_cny', '', '1', '0', '1467410982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14084', 'ltc_cny', '', '1', '0', '1467411042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14085', 'ltc_cny', '', '1', '0', '1467411102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14086', 'ltc_cny', '', '1', '0', '1467411162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14087', 'ltc_cny', '', '1', '0', '1467411222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14088', 'ltc_cny', '', '1', '0', '1467411282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14089', 'ltc_cny', '', '1', '0', '1467411342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14090', 'btc_cny', '', '1', '0', '1467481892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14091', 'btc_cny', '', '1', '0', '1467481952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14092', 'btc_cny', '', '1', '0', '1467482012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14093', 'btc_cny', '', '1', '0', '1467482072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14094', 'btc_cny', '', '1', '0', '1467482132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14095', 'btc_cny', '', '1', '0', '1467482192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14096', 'btc_cny', '', '1', '0', '1467482252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14097', 'btc_cny', '', '1', '0', '1467482312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14098', 'btc_cny', '', '1', '0', '1467482372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14099', 'btc_cny', '', '1', '0', '1467482432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14100', 'btc_cny', '', '1', '0', '1467482492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14101', 'btc_cny', '', '1', '0', '1467482552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14102', 'btc_cny', '', '1', '0', '1467482612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14103', 'btc_cny', '', '1', '0', '1467482672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14104', 'btc_cny', '', '1', '0', '1467482732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14105', 'btc_cny', '', '1', '0', '1467482792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14106', 'btc_cny', '', '1', '0', '1467482852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14107', 'btc_cny', '', '1', '0', '1467482912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14108', 'btc_cny', '', '1', '0', '1467482972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14109', 'btc_cny', '', '1', '0', '1467483032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14110', 'btc_cny', '', '1', '0', '1467483092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14111', 'ltc_cny', '', '1', '0', '1467411342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14112', 'ltc_cny', '', '1', '0', '1467411402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14113', 'ltc_cny', '', '1', '0', '1467411462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14114', 'ltc_cny', '', '1', '0', '1467411522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14115', 'ltc_cny', '', '1', '0', '1467411582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14116', 'ltc_cny', '', '1', '0', '1467411642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14117', 'ltc_cny', '', '1', '0', '1467411702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14118', 'ltc_cny', '', '1', '0', '1467411762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14119', 'ltc_cny', '', '1', '0', '1467411822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14120', 'ltc_cny', '', '1', '0', '1467411882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14121', 'ltc_cny', '', '1', '0', '1467411942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14122', 'ltc_cny', '', '1', '0', '1467412002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14123', 'ltc_cny', '', '1', '0', '1467412062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14124', 'ltc_cny', '', '1', '0', '1467412122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14125', 'ltc_cny', '', '1', '0', '1467412182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14126', 'ltc_cny', '', '1', '0', '1467412242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14127', 'ltc_cny', '', '1', '0', '1467412302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14128', 'ltc_cny', '', '1', '0', '1467412362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14129', 'ltc_cny', '', '1', '0', '1467412422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14130', 'ltc_cny', '', '1', '0', '1467412482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14131', 'ltc_cny', '', '1', '0', '1467412542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14132', 'btc_cny', '', '1', '0', '1467483092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14133', 'btc_cny', '', '1', '0', '1467483152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14134', 'btc_cny', '', '1', '0', '1467483212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14135', 'btc_cny', '', '1', '0', '1467483272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14136', 'btc_cny', '', '1', '0', '1467483332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14137', 'btc_cny', '', '1', '0', '1467483392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14138', 'btc_cny', '', '1', '0', '1467483452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14139', 'btc_cny', '', '1', '0', '1467483512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14140', 'btc_cny', '', '1', '0', '1467483572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14141', 'btc_cny', '', '1', '0', '1467483632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14142', 'btc_cny', '', '1', '0', '1467483692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14143', 'btc_cny', '', '1', '0', '1467483752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14144', 'btc_cny', '', '1', '0', '1467483812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14145', 'btc_cny', '', '1', '0', '1467483872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14146', 'btc_cny', '', '1', '0', '1467483932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14147', 'btc_cny', '', '1', '0', '1467483992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14148', 'btc_cny', '', '1', '0', '1467484052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14149', 'btc_cny', '', '1', '0', '1467484112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14150', 'btc_cny', '', '1', '0', '1467484172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14151', 'btc_cny', '', '1', '0', '1467484232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14152', 'btc_cny', '', '1', '0', '1467484292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14153', 'ltc_cny', '', '1', '0', '1467412542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14154', 'ltc_cny', '', '1', '0', '1467412602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14155', 'ltc_cny', '', '1', '0', '1467412662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14156', 'ltc_cny', '', '1', '0', '1467412722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14157', 'ltc_cny', '', '1', '0', '1467412782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14158', 'ltc_cny', '', '1', '0', '1467412842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14159', 'ltc_cny', '', '1', '0', '1467412902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14160', 'ltc_cny', '', '1', '0', '1467412962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14161', 'ltc_cny', '', '1', '0', '1467413022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14162', 'ltc_cny', '', '1', '0', '1467413082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14163', 'ltc_cny', '', '1', '0', '1467413142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14164', 'ltc_cny', '', '1', '0', '1467413202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14165', 'ltc_cny', '', '1', '0', '1467413262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14166', 'ltc_cny', '', '1', '0', '1467413322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14167', 'ltc_cny', '', '1', '0', '1467413382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14168', 'ltc_cny', '', '1', '0', '1467413442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14169', 'ltc_cny', '', '1', '0', '1467413502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14170', 'ltc_cny', '', '1', '0', '1467413562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14171', 'ltc_cny', '', '1', '0', '1467413622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14172', 'ltc_cny', '', '1', '0', '1467413682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14173', 'ltc_cny', '', '1', '0', '1467413742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14174', 'btc_cny', '', '1', '0', '1467484292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14175', 'btc_cny', '', '1', '0', '1467484352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14176', 'btc_cny', '', '1', '0', '1467484412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14177', 'btc_cny', '', '1', '0', '1467484472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14178', 'btc_cny', '', '1', '0', '1467484532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14179', 'btc_cny', '', '1', '0', '1467484592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14180', 'btc_cny', '', '1', '0', '1467484652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14181', 'btc_cny', '', '1', '0', '1467484712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14182', 'btc_cny', '', '1', '0', '1467484772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14183', 'btc_cny', '', '1', '0', '1467484832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14184', 'btc_cny', '', '1', '0', '1467484892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14185', 'btc_cny', '', '1', '0', '1467484952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14186', 'btc_cny', '', '1', '0', '1467485012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14187', 'btc_cny', '', '1', '0', '1467485072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14188', 'btc_cny', '', '1', '0', '1467485132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14189', 'btc_cny', '', '1', '0', '1467485192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14190', 'btc_cny', '', '1', '0', '1467485252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14191', 'btc_cny', '', '1', '0', '1467485312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14192', 'btc_cny', '', '1', '0', '1467485372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14193', 'btc_cny', '', '1', '0', '1467485432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14194', 'btc_cny', '', '1', '0', '1467485492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14195', 'ltc_cny', '', '1', '0', '1467413742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14196', 'ltc_cny', '', '1', '0', '1467413802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14197', 'ltc_cny', '', '1', '0', '1467413862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14198', 'ltc_cny', '', '1', '0', '1467413922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14199', 'ltc_cny', '', '1', '0', '1467413982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14200', 'ltc_cny', '', '1', '0', '1467414042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14201', 'ltc_cny', '', '1', '0', '1467414102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14202', 'ltc_cny', '', '1', '0', '1467414162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14203', 'ltc_cny', '', '1', '0', '1467414222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14204', 'ltc_cny', '', '1', '0', '1467414282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14205', 'ltc_cny', '', '1', '0', '1467414342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14206', 'ltc_cny', '', '1', '0', '1467414402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14207', 'ltc_cny', '', '1', '0', '1467414462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14208', 'ltc_cny', '', '1', '0', '1467414522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14209', 'ltc_cny', '', '1', '0', '1467414582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14210', 'ltc_cny', '', '1', '0', '1467414642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14211', 'ltc_cny', '', '1', '0', '1467414702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14212', 'ltc_cny', '', '1', '0', '1467414762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14213', 'ltc_cny', '', '1', '0', '1467414822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14214', 'ltc_cny', '', '1', '0', '1467414882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14215', 'ltc_cny', '', '1', '0', '1467414942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14216', 'btc_cny', '', '1', '0', '1467485492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14217', 'btc_cny', '', '1', '0', '1467485552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14218', 'btc_cny', '', '1', '0', '1467485612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14219', 'btc_cny', '', '1', '0', '1467485672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14220', 'btc_cny', '', '1', '0', '1467485732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14221', 'btc_cny', '', '1', '0', '1467485792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14222', 'btc_cny', '', '1', '0', '1467485852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14223', 'btc_cny', '', '1', '0', '1467485912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14224', 'btc_cny', '', '1', '0', '1467485972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14225', 'btc_cny', '', '1', '0', '1467486032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14226', 'btc_cny', '', '1', '0', '1467486092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14227', 'btc_cny', '', '1', '0', '1467486152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14228', 'btc_cny', '', '1', '0', '1467486212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14229', 'btc_cny', '', '1', '0', '1467486272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14230', 'btc_cny', '', '1', '0', '1467486332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14231', 'btc_cny', '', '1', '0', '1467486392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14232', 'btc_cny', '', '1', '0', '1467486452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14233', 'btc_cny', '', '1', '0', '1467486512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14234', 'btc_cny', '', '1', '0', '1467486572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14235', 'btc_cny', '', '1', '0', '1467486632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14236', 'btc_cny', '', '1', '0', '1467486692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14237', 'ltc_cny', '', '1', '0', '1467414942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14238', 'ltc_cny', '', '1', '0', '1467415002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14239', 'ltc_cny', '', '1', '0', '1467415062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14240', 'ltc_cny', '', '1', '0', '1467415122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14241', 'ltc_cny', '', '1', '0', '1467415182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14242', 'ltc_cny', '', '1', '0', '1467415242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14243', 'ltc_cny', '', '1', '0', '1467415302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14244', 'ltc_cny', '', '1', '0', '1467415362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14245', 'ltc_cny', '', '1', '0', '1467415422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14246', 'ltc_cny', '', '1', '0', '1467415482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14247', 'ltc_cny', '', '1', '0', '1467415542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14248', 'ltc_cny', '', '1', '0', '1467415602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14249', 'ltc_cny', '', '1', '0', '1467415662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14250', 'ltc_cny', '', '1', '0', '1467415722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14251', 'ltc_cny', '', '1', '0', '1467415782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14252', 'ltc_cny', '', '1', '0', '1467415842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14253', 'ltc_cny', '', '1', '0', '1467415902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14254', 'ltc_cny', '', '1', '0', '1467415962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14255', 'ltc_cny', '', '1', '0', '1467416022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14256', 'ltc_cny', '', '1', '0', '1467416082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14257', 'ltc_cny', '', '1', '0', '1467416142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14258', 'btc_cny', '', '1', '0', '1467486692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14259', 'btc_cny', '', '1', '0', '1467486752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14260', 'btc_cny', '', '1', '0', '1467486812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14261', 'btc_cny', '', '1', '0', '1467486872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14262', 'btc_cny', '', '1', '0', '1467486932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14263', 'btc_cny', '', '1', '0', '1467486992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14264', 'btc_cny', '', '1', '0', '1467487052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14265', 'btc_cny', '', '1', '0', '1467487112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14266', 'btc_cny', '', '1', '0', '1467487172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14267', 'btc_cny', '', '1', '0', '1467487232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14268', 'btc_cny', '', '1', '0', '1467487292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14269', 'btc_cny', '', '1', '0', '1467487352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14270', 'btc_cny', '', '1', '0', '1467487412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14271', 'btc_cny', '', '1', '0', '1467487472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14272', 'btc_cny', '', '1', '0', '1467487532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14273', 'btc_cny', '', '1', '0', '1467487592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14274', 'btc_cny', '', '1', '0', '1467487652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14275', 'btc_cny', '', '1', '0', '1467487712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14276', 'btc_cny', '', '1', '0', '1467487772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14277', 'btc_cny', '', '1', '0', '1467487832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14278', 'btc_cny', '', '1', '0', '1467487892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14279', 'ltc_cny', '', '1', '0', '1467416142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14280', 'ltc_cny', '', '1', '0', '1467416202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14281', 'ltc_cny', '', '1', '0', '1467416262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14282', 'ltc_cny', '', '1', '0', '1467416322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14283', 'ltc_cny', '', '1', '0', '1467416382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14284', 'ltc_cny', '', '1', '0', '1467416442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14285', 'ltc_cny', '', '1', '0', '1467416502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14286', 'ltc_cny', '', '1', '0', '1467416562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14287', 'ltc_cny', '', '1', '0', '1467416622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14288', 'ltc_cny', '', '1', '0', '1467416682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14289', 'ltc_cny', '', '1', '0', '1467416742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14290', 'ltc_cny', '', '1', '0', '1467416802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14291', 'ltc_cny', '', '1', '0', '1467416862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14292', 'ltc_cny', '', '1', '0', '1467416922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14293', 'ltc_cny', '', '1', '0', '1467416982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14294', 'ltc_cny', '', '1', '0', '1467417042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14295', 'ltc_cny', '', '1', '0', '1467417102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14296', 'ltc_cny', '', '1', '0', '1467417162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14297', 'ltc_cny', '', '1', '0', '1467417222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14298', 'ltc_cny', '', '1', '0', '1467417282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14299', 'ltc_cny', '', '1', '0', '1467417342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14300', 'btc_cny', '', '1', '0', '1467487892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14301', 'btc_cny', '', '1', '0', '1467487952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14302', 'btc_cny', '', '1', '0', '1467488012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14303', 'btc_cny', '', '1', '0', '1467488072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14304', 'btc_cny', '', '1', '0', '1467488132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14305', 'btc_cny', '', '1', '0', '1467488192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14306', 'btc_cny', '', '1', '0', '1467488252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14307', 'btc_cny', '', '1', '0', '1467488312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14308', 'btc_cny', '', '1', '0', '1467488372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14309', 'btc_cny', '', '1', '0', '1467488432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14310', 'btc_cny', '', '1', '0', '1467488492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14311', 'btc_cny', '', '1', '0', '1467488552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14312', 'btc_cny', '', '1', '0', '1467488612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14313', 'btc_cny', '', '1', '0', '1467488672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14314', 'btc_cny', '', '1', '0', '1467488732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14315', 'btc_cny', '', '1', '0', '1467488792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14316', 'btc_cny', '', '1', '0', '1467488852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14317', 'btc_cny', '', '1', '0', '1467488912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14318', 'btc_cny', '', '1', '0', '1467488972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14319', 'btc_cny', '', '1', '0', '1467489032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14320', 'btc_cny', '', '1', '0', '1467489092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14321', 'ltc_cny', '', '1', '0', '1467417342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14322', 'ltc_cny', '', '1', '0', '1467417402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14323', 'ltc_cny', '', '1', '0', '1467417462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14324', 'ltc_cny', '', '1', '0', '1467417522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14325', 'ltc_cny', '', '1', '0', '1467417582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14326', 'ltc_cny', '', '1', '0', '1467417642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14327', 'ltc_cny', '', '1', '0', '1467417702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14328', 'ltc_cny', '', '1', '0', '1467417762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14329', 'ltc_cny', '', '1', '0', '1467417822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14330', 'ltc_cny', '', '1', '0', '1467417882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14331', 'ltc_cny', '', '1', '0', '1467417942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14332', 'ltc_cny', '', '1', '0', '1467418002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14333', 'ltc_cny', '', '1', '0', '1467418062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14334', 'ltc_cny', '', '1', '0', '1467418122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14335', 'ltc_cny', '', '1', '0', '1467418182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14336', 'ltc_cny', '', '1', '0', '1467418242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14337', 'ltc_cny', '', '1', '0', '1467418302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14338', 'ltc_cny', '', '1', '0', '1467418362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14339', 'ltc_cny', '', '1', '0', '1467418422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14340', 'ltc_cny', '', '1', '0', '1467418482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14341', 'ltc_cny', '', '1', '0', '1467418542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14342', 'btc_cny', '', '1', '0', '1467489092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14343', 'btc_cny', '', '1', '0', '1467489152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14344', 'btc_cny', '', '1', '0', '1467489212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14345', 'btc_cny', '', '1', '0', '1467489272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14346', 'btc_cny', '', '1', '0', '1467489332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14347', 'btc_cny', '', '1', '0', '1467489392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14348', 'btc_cny', '', '1', '0', '1467489452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14349', 'btc_cny', '', '1', '0', '1467489512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14350', 'btc_cny', '', '1', '0', '1467489572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14351', 'btc_cny', '', '1', '0', '1467489632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14352', 'btc_cny', '', '1', '0', '1467489692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14353', 'btc_cny', '', '1', '0', '1467489752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14354', 'btc_cny', '', '1', '0', '1467489812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14355', 'btc_cny', '', '1', '0', '1467489872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14356', 'btc_cny', '', '1', '0', '1467489932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14357', 'btc_cny', '', '1', '0', '1467489992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14358', 'btc_cny', '', '1', '0', '1467490052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14359', 'btc_cny', '', '1', '0', '1467490112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14360', 'btc_cny', '', '1', '0', '1467490172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14361', 'btc_cny', '', '1', '0', '1467490232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14362', 'btc_cny', '', '1', '0', '1467490292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14363', 'ltc_cny', '', '1', '0', '1467418542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14364', 'ltc_cny', '', '1', '0', '1467418602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14365', 'ltc_cny', '', '1', '0', '1467418662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14366', 'ltc_cny', '', '1', '0', '1467418722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14367', 'ltc_cny', '', '1', '0', '1467418782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14368', 'ltc_cny', '', '1', '0', '1467418842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14369', 'ltc_cny', '', '1', '0', '1467418902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14370', 'ltc_cny', '', '1', '0', '1467418962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14371', 'ltc_cny', '', '1', '0', '1467419022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14372', 'ltc_cny', '', '1', '0', '1467419082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14373', 'ltc_cny', '', '1', '0', '1467419142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14374', 'ltc_cny', '', '1', '0', '1467419202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14375', 'ltc_cny', '', '1', '0', '1467419262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14376', 'ltc_cny', '', '1', '0', '1467419322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14377', 'ltc_cny', '', '1', '0', '1467419382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14378', 'ltc_cny', '', '1', '0', '1467419442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14379', 'ltc_cny', '', '1', '0', '1467419502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14380', 'ltc_cny', '', '1', '0', '1467419562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14381', 'ltc_cny', '', '1', '0', '1467419622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14382', 'ltc_cny', '', '1', '0', '1467419682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14383', 'ltc_cny', '', '1', '0', '1467419742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14384', 'btc_cny', '', '1', '0', '1467490292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14385', 'btc_cny', '', '1', '0', '1467490352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14386', 'btc_cny', '', '1', '0', '1467490412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14387', 'btc_cny', '', '1', '0', '1467490472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14388', 'btc_cny', '', '1', '0', '1467490532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14389', 'btc_cny', '', '1', '0', '1467490592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14390', 'btc_cny', '', '1', '0', '1467490652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14391', 'btc_cny', '', '1', '0', '1467490712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14392', 'btc_cny', '', '1', '0', '1467490772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14393', 'btc_cny', '', '1', '0', '1467490832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14394', 'btc_cny', '', '1', '0', '1467490892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14395', 'btc_cny', '', '1', '0', '1467490952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14396', 'btc_cny', '', '1', '0', '1467491012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14397', 'btc_cny', '', '1', '0', '1467491072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14398', 'btc_cny', '', '1', '0', '1467491132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14399', 'btc_cny', '', '1', '0', '1467491192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14400', 'btc_cny', '', '1', '0', '1467491252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14401', 'btc_cny', '', '1', '0', '1467491312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14402', 'btc_cny', '', '1', '0', '1467491372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14403', 'btc_cny', '', '1', '0', '1467491432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14404', 'btc_cny', '', '1', '0', '1467491492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14405', 'ltc_cny', '', '1', '0', '1467419742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14406', 'ltc_cny', '', '1', '0', '1467419802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14407', 'ltc_cny', '', '1', '0', '1467419862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14408', 'ltc_cny', '', '1', '0', '1467419922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14409', 'ltc_cny', '', '1', '0', '1467419982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14410', 'ltc_cny', '', '1', '0', '1467420042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14411', 'ltc_cny', '', '1', '0', '1467420102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14412', 'ltc_cny', '', '1', '0', '1467420162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14413', 'ltc_cny', '', '1', '0', '1467420222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14414', 'ltc_cny', '', '1', '0', '1467420282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14415', 'ltc_cny', '', '1', '0', '1467420342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14416', 'ltc_cny', '', '1', '0', '1467420402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14417', 'ltc_cny', '', '1', '0', '1467420462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14418', 'ltc_cny', '', '1', '0', '1467420522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14419', 'ltc_cny', '', '1', '0', '1467420582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14420', 'ltc_cny', '', '1', '0', '1467420642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14421', 'ltc_cny', '', '1', '0', '1467420702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14422', 'ltc_cny', '', '1', '0', '1467420762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14423', 'ltc_cny', '', '1', '0', '1467420822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14424', 'ltc_cny', '', '1', '0', '1467420882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14425', 'ltc_cny', '', '1', '0', '1467420942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14426', 'btc_cny', '', '1', '0', '1467491492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14427', 'btc_cny', '', '1', '0', '1467491552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14428', 'btc_cny', '', '1', '0', '1467491612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14429', 'btc_cny', '', '1', '0', '1467491672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14430', 'btc_cny', '', '1', '0', '1467491732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14431', 'btc_cny', '', '1', '0', '1467491792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14432', 'btc_cny', '', '1', '0', '1467491852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14433', 'btc_cny', '', '1', '0', '1467491912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14434', 'btc_cny', '', '1', '0', '1467491972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14435', 'btc_cny', '', '1', '0', '1467492032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14436', 'btc_cny', '', '1', '0', '1467492092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14437', 'btc_cny', '', '1', '0', '1467492152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14438', 'btc_cny', '', '1', '0', '1467492212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14439', 'btc_cny', '', '1', '0', '1467492272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14440', 'btc_cny', '', '1', '0', '1467492332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14441', 'btc_cny', '', '1', '0', '1467492392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14442', 'btc_cny', '', '1', '0', '1467492452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14443', 'btc_cny', '', '1', '0', '1467492512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14444', 'btc_cny', '', '1', '0', '1467492572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14445', 'btc_cny', '', '1', '0', '1467492632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14446', 'btc_cny', '', '1', '0', '1467492692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14447', 'ltc_cny', '', '1', '0', '1467420942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14448', 'ltc_cny', '', '1', '0', '1467421002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14449', 'ltc_cny', '', '1', '0', '1467421062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14450', 'ltc_cny', '', '1', '0', '1467421122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14451', 'ltc_cny', '', '1', '0', '1467421182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14452', 'ltc_cny', '', '1', '0', '1467421242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14453', 'ltc_cny', '', '1', '0', '1467421302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14454', 'ltc_cny', '', '1', '0', '1467421362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14455', 'ltc_cny', '', '1', '0', '1467421422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14456', 'ltc_cny', '', '1', '0', '1467421482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14457', 'ltc_cny', '', '1', '0', '1467421542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14458', 'ltc_cny', '', '1', '0', '1467421602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14459', 'ltc_cny', '', '1', '0', '1467421662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14460', 'ltc_cny', '', '1', '0', '1467421722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14461', 'ltc_cny', '', '1', '0', '1467421782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14462', 'ltc_cny', '', '1', '0', '1467421842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14463', 'ltc_cny', '', '1', '0', '1467421902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14464', 'ltc_cny', '', '1', '0', '1467421962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14465', 'ltc_cny', '', '1', '0', '1467422022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14466', 'ltc_cny', '', '1', '0', '1467422082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14467', 'ltc_cny', '', '1', '0', '1467422142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14468', 'btc_cny', '', '1', '0', '1467492692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14469', 'btc_cny', '', '1', '0', '1467492752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14470', 'btc_cny', '', '1', '0', '1467492812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14471', 'btc_cny', '', '1', '0', '1467492872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14472', 'btc_cny', '', '1', '0', '1467492932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14473', 'btc_cny', '', '1', '0', '1467492992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14474', 'btc_cny', '', '1', '0', '1467493052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14475', 'btc_cny', '', '1', '0', '1467493112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14476', 'btc_cny', '', '1', '0', '1467493172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14477', 'btc_cny', '', '1', '0', '1467493232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14478', 'btc_cny', '', '1', '0', '1467493292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14479', 'btc_cny', '', '1', '0', '1467493352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14480', 'btc_cny', '', '1', '0', '1467493412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14481', 'btc_cny', '', '1', '0', '1467493472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14482', 'btc_cny', '', '1', '0', '1467493532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14483', 'btc_cny', '', '1', '0', '1467493592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14484', 'btc_cny', '', '1', '0', '1467493652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14485', 'btc_cny', '', '1', '0', '1467493712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14486', 'btc_cny', '', '1', '0', '1467493772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14487', 'btc_cny', '', '1', '0', '1467493832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14488', 'btc_cny', '', '1', '0', '1467493892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14489', 'ltc_cny', '', '1', '0', '1467422142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14490', 'ltc_cny', '', '1', '0', '1467422202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14491', 'ltc_cny', '', '1', '0', '1467422262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14492', 'ltc_cny', '', '1', '0', '1467422322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14493', 'ltc_cny', '', '1', '0', '1467422382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14494', 'ltc_cny', '', '1', '0', '1467422442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14495', 'ltc_cny', '', '1', '0', '1467422502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14496', 'ltc_cny', '', '1', '0', '1467422562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14497', 'ltc_cny', '', '1', '0', '1467422622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14498', 'ltc_cny', '', '1', '0', '1467422682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14499', 'ltc_cny', '', '1', '0', '1467422742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14500', 'ltc_cny', '', '1', '0', '1467422802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14501', 'ltc_cny', '', '1', '0', '1467422862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14502', 'ltc_cny', '', '1', '0', '1467422922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14503', 'ltc_cny', '', '1', '0', '1467422982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14504', 'ltc_cny', '', '1', '0', '1467423042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14505', 'ltc_cny', '', '1', '0', '1467423102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14506', 'ltc_cny', '', '1', '0', '1467423162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14507', 'ltc_cny', '', '1', '0', '1467423222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14508', 'ltc_cny', '', '1', '0', '1467423282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14509', 'ltc_cny', '', '1', '0', '1467423342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14510', 'btc_cny', '', '1', '0', '1467493892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14511', 'btc_cny', '', '1', '0', '1467493952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14512', 'btc_cny', '', '1', '0', '1467494012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14513', 'btc_cny', '', '1', '0', '1467494072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14514', 'btc_cny', '', '1', '0', '1467494132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14515', 'btc_cny', '', '1', '0', '1467494192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14516', 'btc_cny', '', '1', '0', '1467494252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14517', 'btc_cny', '', '1', '0', '1467494312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14518', 'btc_cny', '', '1', '0', '1467494372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14519', 'btc_cny', '', '1', '0', '1467494432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14520', 'btc_cny', '', '1', '0', '1467494492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14521', 'btc_cny', '', '1', '0', '1467494552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14522', 'btc_cny', '', '1', '0', '1467494612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14523', 'btc_cny', '', '1', '0', '1467494672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14524', 'btc_cny', '', '1', '0', '1467494732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14525', 'btc_cny', '', '1', '0', '1467494792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14526', 'btc_cny', '', '1', '0', '1467494852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14527', 'btc_cny', '', '1', '0', '1467494912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14528', 'btc_cny', '', '1', '0', '1467494972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14529', 'btc_cny', '', '1', '0', '1467495032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14530', 'btc_cny', '', '1', '0', '1467495092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14531', 'ltc_cny', '', '1', '0', '1467423342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14532', 'ltc_cny', '', '1', '0', '1467423402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14533', 'ltc_cny', '', '1', '0', '1467423462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14534', 'ltc_cny', '', '1', '0', '1467423522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14535', 'ltc_cny', '', '1', '0', '1467423582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14536', 'ltc_cny', '', '1', '0', '1467423642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14537', 'ltc_cny', '', '1', '0', '1467423702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14538', 'ltc_cny', '', '1', '0', '1467423762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14539', 'ltc_cny', '', '1', '0', '1467423822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14540', 'ltc_cny', '', '1', '0', '1467423882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14541', 'ltc_cny', '', '1', '0', '1467423942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14542', 'ltc_cny', '', '1', '0', '1467424002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14543', 'ltc_cny', '', '1', '0', '1467424062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14544', 'ltc_cny', '', '1', '0', '1467424122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14545', 'ltc_cny', '', '1', '0', '1467424182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14546', 'ltc_cny', '', '1', '0', '1467424242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14547', 'ltc_cny', '', '1', '0', '1467424302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14548', 'ltc_cny', '', '1', '0', '1467424362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14549', 'ltc_cny', '', '1', '0', '1467424422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14550', 'ltc_cny', '', '1', '0', '1467424482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14551', 'ltc_cny', '', '1', '0', '1467424542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14552', 'btc_cny', '', '1', '0', '1467495092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14553', 'btc_cny', '', '1', '0', '1467495152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14554', 'btc_cny', '', '1', '0', '1467495212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14555', 'btc_cny', '', '1', '0', '1467495272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14556', 'btc_cny', '', '1', '0', '1467495332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14557', 'btc_cny', '', '1', '0', '1467495392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14558', 'btc_cny', '', '1', '0', '1467495452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14559', 'btc_cny', '', '1', '0', '1467495512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14560', 'btc_cny', '', '1', '0', '1467495572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14561', 'btc_cny', '', '1', '0', '1467495632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14562', 'btc_cny', '', '1', '0', '1467495692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14563', 'btc_cny', '', '1', '0', '1467495752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14564', 'btc_cny', '', '1', '0', '1467495812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14565', 'btc_cny', '', '1', '0', '1467495872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14566', 'btc_cny', '', '1', '0', '1467495932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14567', 'btc_cny', '', '1', '0', '1467495992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14568', 'btc_cny', '', '1', '0', '1467496052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14569', 'btc_cny', '', '1', '0', '1467496112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14570', 'btc_cny', '', '1', '0', '1467496172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14571', 'btc_cny', '', '1', '0', '1467496232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14572', 'btc_cny', '', '1', '0', '1467496292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14573', 'ltc_cny', '', '1', '0', '1467424542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14574', 'ltc_cny', '', '1', '0', '1467424602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14575', 'ltc_cny', '', '1', '0', '1467424662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14576', 'ltc_cny', '', '1', '0', '1467424722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14577', 'ltc_cny', '', '1', '0', '1467424782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14578', 'ltc_cny', '', '1', '0', '1467424842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14579', 'ltc_cny', '', '1', '0', '1467424902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14580', 'ltc_cny', '', '1', '0', '1467424962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14581', 'ltc_cny', '', '1', '0', '1467425022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14582', 'ltc_cny', '', '1', '0', '1467425082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14583', 'ltc_cny', '', '1', '0', '1467425142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14584', 'ltc_cny', '', '1', '0', '1467425202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14585', 'ltc_cny', '', '1', '0', '1467425262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14586', 'ltc_cny', '', '1', '0', '1467425322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14587', 'ltc_cny', '', '1', '0', '1467425382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14588', 'ltc_cny', '', '1', '0', '1467425442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14589', 'ltc_cny', '', '1', '0', '1467425502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14590', 'ltc_cny', '', '1', '0', '1467425562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14591', 'ltc_cny', '', '1', '0', '1467425622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14592', 'ltc_cny', '', '1', '0', '1467425682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14593', 'ltc_cny', '', '1', '0', '1467425742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14594', 'btc_cny', '', '1', '0', '1467496292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14595', 'btc_cny', '', '1', '0', '1467496352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14596', 'btc_cny', '', '1', '0', '1467496412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14597', 'btc_cny', '', '1', '0', '1467496472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14598', 'btc_cny', '', '1', '0', '1467496532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14599', 'btc_cny', '', '1', '0', '1467496592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14600', 'btc_cny', '', '1', '0', '1467496652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14601', 'btc_cny', '', '1', '0', '1467496712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14602', 'btc_cny', '', '1', '0', '1467496772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14603', 'btc_cny', '', '1', '0', '1467496832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14604', 'btc_cny', '', '1', '0', '1467496892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14605', 'btc_cny', '', '1', '0', '1467496952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14606', 'btc_cny', '', '1', '0', '1467497012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14607', 'btc_cny', '', '1', '0', '1467497072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14608', 'btc_cny', '', '1', '0', '1467497132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14609', 'btc_cny', '', '1', '0', '1467497192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14610', 'btc_cny', '', '1', '0', '1467497252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14611', 'btc_cny', '', '1', '0', '1467497312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14612', 'btc_cny', '', '1', '0', '1467497372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14613', 'btc_cny', '', '1', '0', '1467497432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14614', 'btc_cny', '', '1', '0', '1467497492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14615', 'ltc_cny', '', '1', '0', '1467425742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14616', 'ltc_cny', '', '1', '0', '1467425802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14617', 'ltc_cny', '', '1', '0', '1467425862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14618', 'ltc_cny', '', '1', '0', '1467425922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14619', 'ltc_cny', '', '1', '0', '1467425982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14620', 'ltc_cny', '', '1', '0', '1467426042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14621', 'ltc_cny', '', '1', '0', '1467426102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14622', 'ltc_cny', '', '1', '0', '1467426162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14623', 'ltc_cny', '', '1', '0', '1467426222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14624', 'ltc_cny', '', '1', '0', '1467426282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14625', 'ltc_cny', '', '1', '0', '1467426342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14626', 'ltc_cny', '', '1', '0', '1467426402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14627', 'ltc_cny', '', '1', '0', '1467426462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14628', 'ltc_cny', '', '1', '0', '1467426522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14629', 'ltc_cny', '', '1', '0', '1467426582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14630', 'ltc_cny', '', '1', '0', '1467426642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14631', 'ltc_cny', '', '1', '0', '1467426702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14632', 'ltc_cny', '', '1', '0', '1467426762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14633', 'ltc_cny', '', '1', '0', '1467426822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14634', 'ltc_cny', '', '1', '0', '1467426882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14635', 'ltc_cny', '', '1', '0', '1467426942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14636', 'btc_cny', '', '1', '0', '1467497492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14637', 'btc_cny', '', '1', '0', '1467497552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14638', 'btc_cny', '', '1', '0', '1467497612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14639', 'btc_cny', '', '1', '0', '1467497672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14640', 'btc_cny', '', '1', '0', '1467497732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14641', 'btc_cny', '', '1', '0', '1467497792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14642', 'btc_cny', '', '1', '0', '1467497852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14643', 'btc_cny', '', '1', '0', '1467497912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14644', 'btc_cny', '', '1', '0', '1467497972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14645', 'btc_cny', '', '1', '0', '1467498032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14646', 'btc_cny', '', '1', '0', '1467498092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14647', 'btc_cny', '', '1', '0', '1467498152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14648', 'btc_cny', '', '1', '0', '1467498212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14649', 'btc_cny', '', '1', '0', '1467498272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14650', 'btc_cny', '', '1', '0', '1467498332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14651', 'btc_cny', '', '1', '0', '1467498392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14652', 'btc_cny', '', '1', '0', '1467498452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14653', 'btc_cny', '', '1', '0', '1467498512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14654', 'btc_cny', '', '1', '0', '1467498572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14655', 'btc_cny', '', '1', '0', '1467498632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14656', 'btc_cny', '', '1', '0', '1467498692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14657', 'ltc_cny', '', '1', '0', '1467426942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14658', 'ltc_cny', '', '1', '0', '1467427002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14659', 'ltc_cny', '', '1', '0', '1467427062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14660', 'ltc_cny', '', '1', '0', '1467427122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14661', 'ltc_cny', '', '1', '0', '1467427182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14662', 'ltc_cny', '', '1', '0', '1467427242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14663', 'ltc_cny', '', '1', '0', '1467427302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14664', 'ltc_cny', '', '1', '0', '1467427362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14665', 'ltc_cny', '', '1', '0', '1467427422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14666', 'ltc_cny', '', '1', '0', '1467427482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14667', 'ltc_cny', '', '1', '0', '1467427542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14668', 'ltc_cny', '', '1', '0', '1467427602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14669', 'ltc_cny', '', '1', '0', '1467427662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14670', 'ltc_cny', '', '1', '0', '1467427722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14671', 'ltc_cny', '', '1', '0', '1467427782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14672', 'ltc_cny', '', '1', '0', '1467427842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14673', 'ltc_cny', '', '1', '0', '1467427902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14674', 'ltc_cny', '', '1', '0', '1467427962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14675', 'ltc_cny', '', '1', '0', '1467428022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14676', 'ltc_cny', '', '1', '0', '1467428082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14677', 'ltc_cny', '', '1', '0', '1467428142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14678', 'btc_cny', '', '1', '0', '1467498692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14679', 'btc_cny', '', '1', '0', '1467498752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14680', 'btc_cny', '', '1', '0', '1467498812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14681', 'btc_cny', '', '1', '0', '1467498872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14682', 'btc_cny', '', '1', '0', '1467498932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14683', 'btc_cny', '', '1', '0', '1467498992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14684', 'btc_cny', '', '1', '0', '1467499052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14685', 'btc_cny', '', '1', '0', '1467499112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14686', 'btc_cny', '', '1', '0', '1467499172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14687', 'btc_cny', '', '1', '0', '1467499232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14688', 'btc_cny', '', '1', '0', '1467499292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14689', 'btc_cny', '', '1', '0', '1467499352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14690', 'btc_cny', '', '1', '0', '1467499412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14691', 'btc_cny', '', '1', '0', '1467499472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14692', 'btc_cny', '', '1', '0', '1467499532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14693', 'btc_cny', '', '1', '0', '1467499592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14694', 'btc_cny', '', '1', '0', '1467499652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14695', 'btc_cny', '', '1', '0', '1467499712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14696', 'btc_cny', '', '1', '0', '1467499772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14697', 'btc_cny', '', '1', '0', '1467499832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14698', 'btc_cny', '', '1', '0', '1467499892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14699', 'ltc_cny', '', '1', '0', '1467428142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14700', 'ltc_cny', '', '1', '0', '1467428202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14701', 'ltc_cny', '', '1', '0', '1467428262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14702', 'ltc_cny', '', '1', '0', '1467428322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14703', 'ltc_cny', '', '1', '0', '1467428382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14704', 'ltc_cny', '', '1', '0', '1467428442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14705', 'ltc_cny', '', '1', '0', '1467428502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14706', 'ltc_cny', '', '1', '0', '1467428562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14707', 'ltc_cny', '', '1', '0', '1467428622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14708', 'ltc_cny', '', '1', '0', '1467428682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14709', 'ltc_cny', '', '1', '0', '1467428742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14710', 'ltc_cny', '', '1', '0', '1467428802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14711', 'ltc_cny', '', '1', '0', '1467428862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14712', 'ltc_cny', '', '1', '0', '1467428922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14713', 'ltc_cny', '', '1', '0', '1467428982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14714', 'ltc_cny', '', '1', '0', '1467429042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14715', 'ltc_cny', '', '1', '0', '1467429102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14716', 'ltc_cny', '', '1', '0', '1467429162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14717', 'ltc_cny', '', '1', '0', '1467429222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14718', 'ltc_cny', '', '1', '0', '1467429282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14719', 'ltc_cny', '', '1', '0', '1467429342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14720', 'btc_cny', '', '1', '0', '1467499892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14721', 'btc_cny', '', '1', '0', '1467499952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14722', 'btc_cny', '', '1', '0', '1467500012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14723', 'btc_cny', '', '1', '0', '1467500072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14724', 'btc_cny', '', '1', '0', '1467500132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14725', 'btc_cny', '', '1', '0', '1467500192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14726', 'btc_cny', '', '1', '0', '1467500252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14727', 'btc_cny', '', '1', '0', '1467500312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14728', 'btc_cny', '', '1', '0', '1467500372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14729', 'btc_cny', '', '1', '0', '1467500432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14730', 'btc_cny', '', '1', '0', '1467500492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14731', 'btc_cny', '', '1', '0', '1467500552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14732', 'btc_cny', '', '1', '0', '1467500612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14733', 'btc_cny', '', '1', '0', '1467500672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14734', 'btc_cny', '', '1', '0', '1467500732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14735', 'btc_cny', '', '1', '0', '1467500792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14736', 'btc_cny', '', '1', '0', '1467500852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14737', 'btc_cny', '', '1', '0', '1467500912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14738', 'btc_cny', '', '1', '0', '1467500972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14739', 'btc_cny', '', '1', '0', '1467501032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14740', 'btc_cny', '', '1', '0', '1467501092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14741', 'ltc_cny', '', '1', '0', '1467429342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14742', 'ltc_cny', '', '1', '0', '1467429402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14743', 'ltc_cny', '', '1', '0', '1467429462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14744', 'ltc_cny', '', '1', '0', '1467429522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14745', 'ltc_cny', '', '1', '0', '1467429582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14746', 'ltc_cny', '', '1', '0', '1467429642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14747', 'ltc_cny', '', '1', '0', '1467429702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14748', 'ltc_cny', '', '1', '0', '1467429762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14749', 'ltc_cny', '', '1', '0', '1467429822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14750', 'ltc_cny', '', '1', '0', '1467429882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14751', 'ltc_cny', '', '1', '0', '1467429942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14752', 'ltc_cny', '', '1', '0', '1467430002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14753', 'ltc_cny', '', '1', '0', '1467430062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14754', 'ltc_cny', '', '1', '0', '1467430122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14755', 'ltc_cny', '', '1', '0', '1467430182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14756', 'ltc_cny', '', '1', '0', '1467430242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14757', 'ltc_cny', '', '1', '0', '1467430302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14758', 'ltc_cny', '', '1', '0', '1467430362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14759', 'ltc_cny', '', '1', '0', '1467430422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14760', 'ltc_cny', '', '1', '0', '1467430482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14761', 'ltc_cny', '', '1', '0', '1467430542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14762', 'btc_cny', '', '1', '0', '1467501092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14763', 'btc_cny', '', '1', '0', '1467501152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14764', 'btc_cny', '', '1', '0', '1467501212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14765', 'btc_cny', '', '1', '0', '1467501272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14766', 'btc_cny', '', '1', '0', '1467501332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14767', 'btc_cny', '', '1', '0', '1467501392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14768', 'btc_cny', '', '1', '0', '1467501452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14769', 'btc_cny', '', '1', '0', '1467501512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14770', 'btc_cny', '', '1', '0', '1467501572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14771', 'btc_cny', '', '1', '0', '1467501632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14772', 'btc_cny', '', '1', '0', '1467501692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14773', 'btc_cny', '', '1', '0', '1467501752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14774', 'btc_cny', '', '1', '0', '1467501812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14775', 'btc_cny', '', '1', '0', '1467501872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14776', 'btc_cny', '', '1', '0', '1467501932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14777', 'btc_cny', '', '1', '0', '1467501992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14778', 'btc_cny', '', '1', '0', '1467502052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14779', 'btc_cny', '', '1', '0', '1467502112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14780', 'btc_cny', '', '1', '0', '1467502172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14781', 'btc_cny', '', '1', '0', '1467502232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14782', 'btc_cny', '', '1', '0', '1467502292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14783', 'ltc_cny', '', '1', '0', '1467430542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14784', 'ltc_cny', '', '1', '0', '1467430602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14785', 'ltc_cny', '', '1', '0', '1467430662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14786', 'ltc_cny', '', '1', '0', '1467430722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14787', 'ltc_cny', '', '1', '0', '1467430782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14788', 'ltc_cny', '', '1', '0', '1467430842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14789', 'ltc_cny', '', '1', '0', '1467430902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14790', 'ltc_cny', '', '1', '0', '1467430962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14791', 'ltc_cny', '', '1', '0', '1467431022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14792', 'ltc_cny', '', '1', '0', '1467431082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14793', 'ltc_cny', '', '1', '0', '1467431142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14794', 'ltc_cny', '', '1', '0', '1467431202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14795', 'ltc_cny', '', '1', '0', '1467431262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14796', 'ltc_cny', '', '1', '0', '1467431322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14797', 'ltc_cny', '', '1', '0', '1467431382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14798', 'ltc_cny', '', '1', '0', '1467431442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14799', 'ltc_cny', '', '1', '0', '1467431502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14800', 'ltc_cny', '', '1', '0', '1467431562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14801', 'ltc_cny', '', '1', '0', '1467431622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14802', 'ltc_cny', '', '1', '0', '1467431682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14803', 'ltc_cny', '', '1', '0', '1467431742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14804', 'btc_cny', '', '1', '0', '1467502292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14805', 'btc_cny', '', '1', '0', '1467502352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14806', 'btc_cny', '', '1', '0', '1467502412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14807', 'btc_cny', '', '1', '0', '1467502472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14808', 'btc_cny', '', '1', '0', '1467502532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14809', 'btc_cny', '', '1', '0', '1467502592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14810', 'btc_cny', '', '1', '0', '1467502652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14811', 'btc_cny', '', '1', '0', '1467502712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14812', 'btc_cny', '', '1', '0', '1467502772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14813', 'btc_cny', '', '1', '0', '1467502832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14814', 'btc_cny', '', '1', '0', '1467502892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14815', 'btc_cny', '', '1', '0', '1467502952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14816', 'btc_cny', '', '1', '0', '1467503012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14817', 'btc_cny', '', '1', '0', '1467503072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14818', 'btc_cny', '', '1', '0', '1467503132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14819', 'btc_cny', '', '1', '0', '1467503192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14820', 'btc_cny', '', '1', '0', '1467503252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14821', 'btc_cny', '', '1', '0', '1467503312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14822', 'btc_cny', '', '1', '0', '1467503372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14823', 'btc_cny', '', '1', '0', '1467503432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14824', 'btc_cny', '', '1', '0', '1467503492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14825', 'ltc_cny', '', '1', '0', '1467431742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14826', 'ltc_cny', '', '1', '0', '1467431802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14827', 'ltc_cny', '', '1', '0', '1467431862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14828', 'ltc_cny', '', '1', '0', '1467431922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14829', 'ltc_cny', '', '1', '0', '1467431982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14830', 'ltc_cny', '', '1', '0', '1467432042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14831', 'ltc_cny', '', '1', '0', '1467432102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14832', 'ltc_cny', '', '1', '0', '1467432162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14833', 'ltc_cny', '', '1', '0', '1467432222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14834', 'ltc_cny', '', '1', '0', '1467432282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14835', 'ltc_cny', '', '1', '0', '1467432342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14836', 'ltc_cny', '', '1', '0', '1467432402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14837', 'ltc_cny', '', '1', '0', '1467432462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14838', 'ltc_cny', '', '1', '0', '1467432522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14839', 'ltc_cny', '', '1', '0', '1467432582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14840', 'ltc_cny', '', '1', '0', '1467432642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14841', 'ltc_cny', '', '1', '0', '1467432702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14842', 'ltc_cny', '', '1', '0', '1467432762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14843', 'ltc_cny', '', '1', '0', '1467432822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14844', 'ltc_cny', '', '1', '0', '1467432882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14845', 'ltc_cny', '', '1', '0', '1467432942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14846', 'btc_cny', '', '1', '0', '1467503492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14847', 'btc_cny', '', '1', '0', '1467503552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14848', 'btc_cny', '', '1', '0', '1467503612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14849', 'btc_cny', '', '1', '0', '1467503672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14850', 'btc_cny', '', '1', '0', '1467503732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14851', 'btc_cny', '', '1', '0', '1467503792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14852', 'btc_cny', '', '1', '0', '1467503852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14853', 'btc_cny', '', '1', '0', '1467503912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14854', 'btc_cny', '', '1', '0', '1467503972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14855', 'btc_cny', '', '1', '0', '1467504032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14856', 'btc_cny', '', '1', '0', '1467504092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14857', 'btc_cny', '', '1', '0', '1467504152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14858', 'btc_cny', '', '1', '0', '1467504212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14859', 'btc_cny', '', '1', '0', '1467504272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14860', 'btc_cny', '', '1', '0', '1467504332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14861', 'btc_cny', '', '1', '0', '1467504392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14862', 'btc_cny', '', '1', '0', '1467504452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14863', 'btc_cny', '', '1', '0', '1467504512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14864', 'btc_cny', '', '1', '0', '1467504572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14865', 'btc_cny', '', '1', '0', '1467504632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14866', 'btc_cny', '', '1', '0', '1467504692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14867', 'ltc_cny', '', '1', '0', '1467432942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14868', 'ltc_cny', '', '1', '0', '1467433002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14869', 'ltc_cny', '', '1', '0', '1467433062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14870', 'ltc_cny', '', '1', '0', '1467433122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14871', 'ltc_cny', '', '1', '0', '1467433182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14872', 'ltc_cny', '', '1', '0', '1467433242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14873', 'ltc_cny', '', '1', '0', '1467433302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14874', 'ltc_cny', '', '1', '0', '1467433362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14875', 'ltc_cny', '', '1', '0', '1467433422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14876', 'ltc_cny', '', '1', '0', '1467433482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14877', 'ltc_cny', '', '1', '0', '1467433542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14878', 'ltc_cny', '', '1', '0', '1467433602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14879', 'ltc_cny', '', '1', '0', '1467433662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14880', 'ltc_cny', '', '1', '0', '1467433722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14881', 'ltc_cny', '', '1', '0', '1467433782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14882', 'ltc_cny', '', '1', '0', '1467433842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14883', 'ltc_cny', '', '1', '0', '1467433902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14884', 'ltc_cny', '', '1', '0', '1467433962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14885', 'ltc_cny', '', '1', '0', '1467434022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14886', 'ltc_cny', '', '1', '0', '1467434082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14887', 'ltc_cny', '', '1', '0', '1467434142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14888', 'btc_cny', '', '1', '0', '1467504692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14889', 'btc_cny', '', '1', '0', '1467504752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14890', 'btc_cny', '', '1', '0', '1467504812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14891', 'btc_cny', '', '1', '0', '1467504872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14892', 'btc_cny', '', '1', '0', '1467504932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14893', 'btc_cny', '', '1', '0', '1467504992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14894', 'btc_cny', '', '1', '0', '1467505052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14895', 'btc_cny', '', '1', '0', '1467505112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14896', 'btc_cny', '', '1', '0', '1467505172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14897', 'btc_cny', '', '1', '0', '1467505232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14898', 'btc_cny', '', '1', '0', '1467505292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14899', 'btc_cny', '', '1', '0', '1467505352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14900', 'btc_cny', '', '1', '0', '1467505412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14901', 'btc_cny', '', '1', '0', '1467505472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14902', 'btc_cny', '', '1', '0', '1467505532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14903', 'btc_cny', '', '1', '0', '1467505592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14904', 'btc_cny', '', '1', '0', '1467505652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14905', 'btc_cny', '', '1', '0', '1467505712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14906', 'btc_cny', '', '1', '0', '1467505772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14907', 'btc_cny', '', '1', '0', '1467505832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14908', 'btc_cny', '', '1', '0', '1467505892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14909', 'ltc_cny', '', '1', '0', '1467434142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14910', 'ltc_cny', '', '1', '0', '1467434202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14911', 'ltc_cny', '', '1', '0', '1467434262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14912', 'ltc_cny', '', '1', '0', '1467434322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14913', 'ltc_cny', '', '1', '0', '1467434382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14914', 'ltc_cny', '', '1', '0', '1467434442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14915', 'ltc_cny', '', '1', '0', '1467434502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14916', 'ltc_cny', '', '1', '0', '1467434562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14917', 'ltc_cny', '', '1', '0', '1467434622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14918', 'ltc_cny', '', '1', '0', '1467434682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14919', 'ltc_cny', '', '1', '0', '1467434742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14920', 'ltc_cny', '', '1', '0', '1467434802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14921', 'ltc_cny', '', '1', '0', '1467434862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14922', 'ltc_cny', '', '1', '0', '1467434922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14923', 'ltc_cny', '', '1', '0', '1467434982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14924', 'ltc_cny', '', '1', '0', '1467435042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14925', 'ltc_cny', '', '1', '0', '1467435102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14926', 'ltc_cny', '', '1', '0', '1467435162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14927', 'ltc_cny', '', '1', '0', '1467435222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14928', 'ltc_cny', '', '1', '0', '1467435282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14929', 'ltc_cny', '', '1', '0', '1467435342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14930', 'btc_cny', '', '1', '0', '1467505892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14931', 'btc_cny', '', '1', '0', '1467505952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14932', 'btc_cny', '', '1', '0', '1467506012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14933', 'btc_cny', '', '1', '0', '1467506072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14934', 'btc_cny', '', '1', '0', '1467506132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14935', 'btc_cny', '', '1', '0', '1467506192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14936', 'btc_cny', '', '1', '0', '1467506252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14937', 'btc_cny', '', '1', '0', '1467506312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14938', 'btc_cny', '', '1', '0', '1467506372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14939', 'btc_cny', '', '1', '0', '1467506432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14940', 'btc_cny', '', '1', '0', '1467506492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14941', 'btc_cny', '', '1', '0', '1467506552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14942', 'btc_cny', '', '1', '0', '1467506612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14943', 'btc_cny', '', '1', '0', '1467506672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14944', 'btc_cny', '', '1', '0', '1467506732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14945', 'btc_cny', '', '1', '0', '1467506792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14946', 'btc_cny', '', '1', '0', '1467506852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14947', 'btc_cny', '', '1', '0', '1467506912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14948', 'btc_cny', '', '1', '0', '1467506972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14949', 'btc_cny', '', '1', '0', '1467507032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14950', 'btc_cny', '', '1', '0', '1467507092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14951', 'ltc_cny', '', '1', '0', '1467435342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14952', 'ltc_cny', '', '1', '0', '1467435402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14953', 'ltc_cny', '', '1', '0', '1467435462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14954', 'ltc_cny', '', '1', '0', '1467435522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14955', 'ltc_cny', '', '1', '0', '1467435582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14956', 'ltc_cny', '', '1', '0', '1467435642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14957', 'ltc_cny', '', '1', '0', '1467435702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14958', 'ltc_cny', '', '1', '0', '1467435762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14959', 'ltc_cny', '', '1', '0', '1467435822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14960', 'ltc_cny', '', '1', '0', '1467435882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14961', 'ltc_cny', '', '1', '0', '1467435942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14962', 'ltc_cny', '', '1', '0', '1467436002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14963', 'ltc_cny', '', '1', '0', '1467436062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14964', 'ltc_cny', '', '1', '0', '1467436122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14965', 'ltc_cny', '', '1', '0', '1467436182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14966', 'ltc_cny', '', '1', '0', '1467436242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14967', 'ltc_cny', '', '1', '0', '1467436302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14968', 'ltc_cny', '', '1', '0', '1467436362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14969', 'ltc_cny', '', '1', '0', '1467436422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14970', 'ltc_cny', '', '1', '0', '1467436482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14971', 'ltc_cny', '', '1', '0', '1467436542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14972', 'btc_cny', '', '1', '0', '1467507092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14973', 'btc_cny', '', '1', '0', '1467507152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14974', 'btc_cny', '', '1', '0', '1467507212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14975', 'btc_cny', '', '1', '0', '1467507272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14976', 'btc_cny', '', '1', '0', '1467507332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14977', 'btc_cny', '', '1', '0', '1467507392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14978', 'btc_cny', '', '1', '0', '1467507452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14979', 'btc_cny', '', '1', '0', '1467507512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14980', 'btc_cny', '', '1', '0', '1467507572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14981', 'btc_cny', '', '1', '0', '1467507632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14982', 'btc_cny', '', '1', '0', '1467507692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14983', 'btc_cny', '', '1', '0', '1467507752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14984', 'btc_cny', '', '1', '0', '1467507812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14985', 'btc_cny', '', '1', '0', '1467507872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14986', 'btc_cny', '', '1', '0', '1467507932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14987', 'btc_cny', '', '1', '0', '1467507992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14988', 'btc_cny', '', '1', '0', '1467508052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14989', 'btc_cny', '', '1', '0', '1467508112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14990', 'btc_cny', '', '1', '0', '1467508172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14991', 'btc_cny', '', '1', '0', '1467508232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14992', 'btc_cny', '', '1', '0', '1467508292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14993', 'ltc_cny', '', '1', '0', '1467436542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14994', 'ltc_cny', '', '1', '0', '1467436602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14995', 'ltc_cny', '', '1', '0', '1467436662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14996', 'ltc_cny', '', '1', '0', '1467436722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14997', 'ltc_cny', '', '1', '0', '1467436782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14998', 'ltc_cny', '', '1', '0', '1467436842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('14999', 'ltc_cny', '', '1', '0', '1467436902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15000', 'ltc_cny', '', '1', '0', '1467436962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15001', 'ltc_cny', '', '1', '0', '1467437022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15002', 'ltc_cny', '', '1', '0', '1467437082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15003', 'ltc_cny', '', '1', '0', '1467437142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15004', 'ltc_cny', '', '1', '0', '1467437202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15005', 'ltc_cny', '', '1', '0', '1467437262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15006', 'ltc_cny', '', '1', '0', '1467437322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15007', 'ltc_cny', '', '1', '0', '1467437382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15008', 'ltc_cny', '', '1', '0', '1467437442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15009', 'ltc_cny', '', '1', '0', '1467437502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15010', 'ltc_cny', '', '1', '0', '1467437562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15011', 'ltc_cny', '', '1', '0', '1467437622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15012', 'ltc_cny', '', '1', '0', '1467437682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15013', 'ltc_cny', '', '1', '0', '1467437742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15014', 'btc_cny', '', '1', '0', '1467508292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15015', 'btc_cny', '', '1', '0', '1467508352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15016', 'btc_cny', '', '1', '0', '1467508412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15017', 'btc_cny', '', '1', '0', '1467508472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15018', 'btc_cny', '', '1', '0', '1467508532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15019', 'btc_cny', '', '1', '0', '1467508592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15020', 'btc_cny', '', '1', '0', '1467508652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15021', 'btc_cny', '', '1', '0', '1467508712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15022', 'btc_cny', '', '1', '0', '1467508772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15023', 'btc_cny', '', '1', '0', '1467508832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15024', 'btc_cny', '', '1', '0', '1467508892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15025', 'btc_cny', '', '1', '0', '1467508952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15026', 'btc_cny', '', '1', '0', '1467509012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15027', 'btc_cny', '', '1', '0', '1467509072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15028', 'btc_cny', '', '1', '0', '1467509132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15029', 'btc_cny', '', '1', '0', '1467509192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15030', 'btc_cny', '', '1', '0', '1467509252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15031', 'btc_cny', '', '1', '0', '1467509312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15032', 'btc_cny', '', '1', '0', '1467509372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15033', 'btc_cny', '', '1', '0', '1467509432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15034', 'btc_cny', '', '1', '0', '1467509492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15035', 'ltc_cny', '', '1', '0', '1467437742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15036', 'ltc_cny', '', '1', '0', '1467437802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15037', 'ltc_cny', '', '1', '0', '1467437862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15038', 'ltc_cny', '', '1', '0', '1467437922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15039', 'ltc_cny', '', '1', '0', '1467437982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15040', 'ltc_cny', '', '1', '0', '1467438042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15041', 'ltc_cny', '', '1', '0', '1467438102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15042', 'ltc_cny', '', '1', '0', '1467438162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15043', 'ltc_cny', '', '1', '0', '1467438222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15044', 'ltc_cny', '', '1', '0', '1467438282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15045', 'ltc_cny', '', '1', '0', '1467438342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15046', 'ltc_cny', '', '1', '0', '1467438402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15047', 'ltc_cny', '', '1', '0', '1467438462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15048', 'ltc_cny', '', '1', '0', '1467438522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15049', 'ltc_cny', '', '1', '0', '1467438582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15050', 'ltc_cny', '', '1', '0', '1467438642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15051', 'ltc_cny', '', '1', '0', '1467438702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15052', 'ltc_cny', '', '1', '0', '1467438762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15053', 'ltc_cny', '', '1', '0', '1467438822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15054', 'ltc_cny', '', '1', '0', '1467438882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15055', 'ltc_cny', '', '1', '0', '1467438942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15056', 'btc_cny', '', '1', '0', '1467509492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15057', 'btc_cny', '', '1', '0', '1467509552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15058', 'btc_cny', '', '1', '0', '1467509612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15059', 'btc_cny', '', '1', '0', '1467509672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15060', 'btc_cny', '', '1', '0', '1467509732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15061', 'btc_cny', '', '1', '0', '1467509792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15062', 'btc_cny', '', '1', '0', '1467509852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15063', 'btc_cny', '', '1', '0', '1467509912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15064', 'btc_cny', '', '1', '0', '1467509972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15065', 'btc_cny', '', '1', '0', '1467510032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15066', 'btc_cny', '', '1', '0', '1467510092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15067', 'btc_cny', '', '1', '0', '1467510152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15068', 'btc_cny', '', '1', '0', '1467510212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15069', 'btc_cny', '', '1', '0', '1467510272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15070', 'btc_cny', '', '1', '0', '1467510332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15071', 'btc_cny', '', '1', '0', '1467510392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15072', 'btc_cny', '', '1', '0', '1467510452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15073', 'btc_cny', '', '1', '0', '1467510512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15074', 'btc_cny', '', '1', '0', '1467510572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15075', 'btc_cny', '', '1', '0', '1467510632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15076', 'btc_cny', '', '1', '0', '1467510692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15077', 'ltc_cny', '', '1', '0', '1467438942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15078', 'ltc_cny', '', '1', '0', '1467439002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15079', 'ltc_cny', '', '1', '0', '1467439062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15080', 'ltc_cny', '', '1', '0', '1467439122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15081', 'ltc_cny', '', '1', '0', '1467439182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15082', 'ltc_cny', '', '1', '0', '1467439242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15083', 'ltc_cny', '', '1', '0', '1467439302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15084', 'ltc_cny', '', '1', '0', '1467439362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15085', 'ltc_cny', '', '1', '0', '1467439422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15086', 'ltc_cny', '', '1', '0', '1467439482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15087', 'ltc_cny', '', '1', '0', '1467439542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15088', 'ltc_cny', '', '1', '0', '1467439602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15089', 'ltc_cny', '', '1', '0', '1467439662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15090', 'ltc_cny', '', '1', '0', '1467439722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15091', 'ltc_cny', '', '1', '0', '1467439782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15092', 'ltc_cny', '', '1', '0', '1467439842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15093', 'ltc_cny', '', '1', '0', '1467439902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15094', 'ltc_cny', '', '1', '0', '1467439962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15095', 'ltc_cny', '', '1', '0', '1467440022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15096', 'ltc_cny', '', '1', '0', '1467440082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15097', 'ltc_cny', '', '1', '0', '1467440142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15098', 'btc_cny', '', '1', '0', '1467510692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15099', 'btc_cny', '', '1', '0', '1467510752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15100', 'btc_cny', '', '1', '0', '1467510812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15101', 'btc_cny', '', '1', '0', '1467510872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15102', 'btc_cny', '', '1', '0', '1467510932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15103', 'btc_cny', '', '1', '0', '1467510992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15104', 'btc_cny', '', '1', '0', '1467511052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15105', 'btc_cny', '', '1', '0', '1467511112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15106', 'btc_cny', '', '1', '0', '1467511172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15107', 'btc_cny', '', '1', '0', '1467511232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15108', 'btc_cny', '', '1', '0', '1467511292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15109', 'btc_cny', '', '1', '0', '1467511352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15110', 'btc_cny', '', '1', '0', '1467511412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15111', 'btc_cny', '', '1', '0', '1467511472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15112', 'btc_cny', '', '1', '0', '1467511532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15113', 'btc_cny', '', '1', '0', '1467511592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15114', 'btc_cny', '', '1', '0', '1467511652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15115', 'btc_cny', '', '1', '0', '1467511712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15116', 'btc_cny', '', '1', '0', '1467511772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15117', 'btc_cny', '', '1', '0', '1467511832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15118', 'btc_cny', '', '1', '0', '1467511892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15119', 'ltc_cny', '', '1', '0', '1467440142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15120', 'ltc_cny', '', '1', '0', '1467440202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15121', 'ltc_cny', '', '1', '0', '1467440262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15122', 'ltc_cny', '', '1', '0', '1467440322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15123', 'ltc_cny', '', '1', '0', '1467440382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15124', 'ltc_cny', '', '1', '0', '1467440442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15125', 'ltc_cny', '', '1', '0', '1467440502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15126', 'ltc_cny', '', '1', '0', '1467440562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15127', 'ltc_cny', '', '1', '0', '1467440622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15128', 'ltc_cny', '', '1', '0', '1467440682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15129', 'ltc_cny', '', '1', '0', '1467440742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15130', 'ltc_cny', '', '1', '0', '1467440802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15131', 'ltc_cny', '', '1', '0', '1467440862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15132', 'ltc_cny', '', '1', '0', '1467440922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15133', 'ltc_cny', '', '1', '0', '1467440982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15134', 'ltc_cny', '', '1', '0', '1467441042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15135', 'ltc_cny', '', '1', '0', '1467441102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15136', 'ltc_cny', '', '1', '0', '1467441162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15137', 'ltc_cny', '', '1', '0', '1467441222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15138', 'ltc_cny', '', '1', '0', '1467441282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15139', 'ltc_cny', '', '1', '0', '1467441342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15140', 'btc_cny', '', '1', '0', '1467511892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15141', 'btc_cny', '', '1', '0', '1467511952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15142', 'btc_cny', '', '1', '0', '1467512012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15143', 'btc_cny', '', '1', '0', '1467512072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15144', 'btc_cny', '', '1', '0', '1467512132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15145', 'btc_cny', '', '1', '0', '1467512192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15146', 'btc_cny', '', '1', '0', '1467512252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15147', 'btc_cny', '', '1', '0', '1467512312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15148', 'btc_cny', '', '1', '0', '1467512372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15149', 'btc_cny', '', '1', '0', '1467512432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15150', 'btc_cny', '', '1', '0', '1467512492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15151', 'btc_cny', '', '1', '0', '1467512552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15152', 'btc_cny', '', '1', '0', '1467512612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15153', 'btc_cny', '', '1', '0', '1467512672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15154', 'btc_cny', '', '1', '0', '1467512732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15155', 'btc_cny', '', '1', '0', '1467512792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15156', 'btc_cny', '', '1', '0', '1467512852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15157', 'btc_cny', '', '1', '0', '1467512912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15158', 'btc_cny', '', '1', '0', '1467512972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15159', 'btc_cny', '', '1', '0', '1467513032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15160', 'btc_cny', '', '1', '0', '1467513092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15161', 'ltc_cny', '', '1', '0', '1467441342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15162', 'ltc_cny', '', '1', '0', '1467441402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15163', 'ltc_cny', '', '1', '0', '1467441462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15164', 'ltc_cny', '', '1', '0', '1467441522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15165', 'ltc_cny', '', '1', '0', '1467441582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15166', 'ltc_cny', '', '1', '0', '1467441642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15167', 'ltc_cny', '', '1', '0', '1467441702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15168', 'ltc_cny', '', '1', '0', '1467441762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15169', 'ltc_cny', '', '1', '0', '1467441822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15170', 'ltc_cny', '', '1', '0', '1467441882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15171', 'ltc_cny', '', '1', '0', '1467441942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15172', 'ltc_cny', '', '1', '0', '1467442002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15173', 'ltc_cny', '', '1', '0', '1467442062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15174', 'ltc_cny', '', '1', '0', '1467442122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15175', 'ltc_cny', '', '1', '0', '1467442182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15176', 'ltc_cny', '', '1', '0', '1467442242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15177', 'ltc_cny', '', '1', '0', '1467442302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15178', 'ltc_cny', '', '1', '0', '1467442362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15179', 'ltc_cny', '', '1', '0', '1467442422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15180', 'ltc_cny', '', '1', '0', '1467442482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15181', 'ltc_cny', '', '1', '0', '1467442542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15182', 'btc_cny', '', '1', '0', '1467513092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15183', 'btc_cny', '', '1', '0', '1467513152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15184', 'btc_cny', '', '1', '0', '1467513212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15185', 'btc_cny', '', '1', '0', '1467513272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15186', 'btc_cny', '', '1', '0', '1467513332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15187', 'btc_cny', '', '1', '0', '1467513392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15188', 'btc_cny', '', '1', '0', '1467513452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15189', 'btc_cny', '', '1', '0', '1467513512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15190', 'btc_cny', '', '1', '0', '1467513572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15191', 'btc_cny', '', '1', '0', '1467513632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15192', 'btc_cny', '', '1', '0', '1467513692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15193', 'btc_cny', '', '1', '0', '1467513752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15194', 'btc_cny', '', '1', '0', '1467513812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15195', 'btc_cny', '', '1', '0', '1467513872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15196', 'btc_cny', '', '1', '0', '1467513932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15197', 'btc_cny', '', '1', '0', '1467513992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15198', 'btc_cny', '', '1', '0', '1467514052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15199', 'btc_cny', '', '1', '0', '1467514112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15200', 'btc_cny', '', '1', '0', '1467514172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15201', 'btc_cny', '', '1', '0', '1467514232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15202', 'btc_cny', '', '1', '0', '1467514292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15203', 'ltc_cny', '', '1', '0', '1467442542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15204', 'ltc_cny', '', '1', '0', '1467442602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15205', 'ltc_cny', '', '1', '0', '1467442662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15206', 'ltc_cny', '', '1', '0', '1467442722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15207', 'ltc_cny', '', '1', '0', '1467442782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15208', 'ltc_cny', '', '1', '0', '1467442842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15209', 'ltc_cny', '', '1', '0', '1467442902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15210', 'ltc_cny', '', '1', '0', '1467442962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15211', 'ltc_cny', '', '1', '0', '1467443022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15212', 'ltc_cny', '', '1', '0', '1467443082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15213', 'ltc_cny', '', '1', '0', '1467443142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15214', 'ltc_cny', '', '1', '0', '1467443202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15215', 'ltc_cny', '', '1', '0', '1467443262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15216', 'ltc_cny', '', '1', '0', '1467443322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15217', 'ltc_cny', '', '1', '0', '1467443382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15218', 'ltc_cny', '', '1', '0', '1467443442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15219', 'ltc_cny', '', '1', '0', '1467443502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15220', 'ltc_cny', '', '1', '0', '1467443562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15221', 'ltc_cny', '', '1', '0', '1467443622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15222', 'ltc_cny', '', '1', '0', '1467443682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15223', 'ltc_cny', '', '1', '0', '1467443742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15224', 'btc_cny', '', '1', '0', '1467514292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15225', 'btc_cny', '', '1', '0', '1467514352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15226', 'btc_cny', '', '1', '0', '1467514412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15227', 'btc_cny', '', '1', '0', '1467514472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15228', 'btc_cny', '', '1', '0', '1467514532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15229', 'btc_cny', '', '1', '0', '1467514592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15230', 'btc_cny', '', '1', '0', '1467514652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15231', 'btc_cny', '', '1', '0', '1467514712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15232', 'btc_cny', '', '1', '0', '1467514772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15233', 'btc_cny', '', '1', '0', '1467514832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15234', 'btc_cny', '', '1', '0', '1467514892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15235', 'btc_cny', '', '1', '0', '1467514952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15236', 'btc_cny', '', '1', '0', '1467515012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15237', 'btc_cny', '', '1', '0', '1467515072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15238', 'btc_cny', '', '1', '0', '1467515132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15239', 'btc_cny', '', '1', '0', '1467515192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15240', 'btc_cny', '', '1', '0', '1467515252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15241', 'btc_cny', '', '1', '0', '1467515312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15242', 'btc_cny', '', '1', '0', '1467515372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15243', 'btc_cny', '', '1', '0', '1467515432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15244', 'btc_cny', '', '1', '0', '1467515492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15245', 'ltc_cny', '', '1', '0', '1467443742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15246', 'ltc_cny', '', '1', '0', '1467443802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15247', 'ltc_cny', '', '1', '0', '1467443862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15248', 'ltc_cny', '', '1', '0', '1467443922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15249', 'ltc_cny', '', '1', '0', '1467443982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15250', 'ltc_cny', '', '1', '0', '1467444042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15251', 'ltc_cny', '', '1', '0', '1467444102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15252', 'ltc_cny', '', '1', '0', '1467444162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15253', 'ltc_cny', '', '1', '0', '1467444222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15254', 'ltc_cny', '', '1', '0', '1467444282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15255', 'ltc_cny', '', '1', '0', '1467444342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15256', 'ltc_cny', '', '1', '0', '1467444402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15257', 'ltc_cny', '', '1', '0', '1467444462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15258', 'ltc_cny', '', '1', '0', '1467444522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15259', 'ltc_cny', '', '1', '0', '1467444582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15260', 'ltc_cny', '', '1', '0', '1467444642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15261', 'ltc_cny', '', '1', '0', '1467444702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15262', 'ltc_cny', '', '1', '0', '1467444762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15263', 'ltc_cny', '', '1', '0', '1467444822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15264', 'ltc_cny', '', '1', '0', '1467444882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15265', 'ltc_cny', '', '1', '0', '1467444942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15266', 'btc_cny', '', '1', '0', '1467515492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15267', 'btc_cny', '', '1', '0', '1467515552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15268', 'btc_cny', '', '1', '0', '1467515612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15269', 'btc_cny', '', '1', '0', '1467515672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15270', 'btc_cny', '', '1', '0', '1467515732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15271', 'btc_cny', '', '1', '0', '1467515792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15272', 'btc_cny', '', '1', '0', '1467515852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15273', 'btc_cny', '', '1', '0', '1467515912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15274', 'btc_cny', '', '1', '0', '1467515972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15275', 'btc_cny', '', '1', '0', '1467516032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15276', 'btc_cny', '', '1', '0', '1467516092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15277', 'btc_cny', '', '1', '0', '1467516152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15278', 'btc_cny', '', '1', '0', '1467516212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15279', 'btc_cny', '', '1', '0', '1467516272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15280', 'btc_cny', '', '1', '0', '1467516332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15281', 'btc_cny', '', '1', '0', '1467516392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15282', 'btc_cny', '', '1', '0', '1467516452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15283', 'btc_cny', '', '1', '0', '1467516512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15284', 'btc_cny', '', '1', '0', '1467516572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15285', 'btc_cny', '', '1', '0', '1467516632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15286', 'btc_cny', '', '1', '0', '1467516692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15287', 'ltc_cny', '', '1', '0', '1467444942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15288', 'ltc_cny', '', '1', '0', '1467445002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15289', 'ltc_cny', '', '1', '0', '1467445062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15290', 'ltc_cny', '', '1', '0', '1467445122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15291', 'ltc_cny', '', '1', '0', '1467445182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15292', 'ltc_cny', '', '1', '0', '1467445242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15293', 'ltc_cny', '', '1', '0', '1467445302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15294', 'ltc_cny', '', '1', '0', '1467445362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15295', 'ltc_cny', '', '1', '0', '1467445422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15296', 'ltc_cny', '', '1', '0', '1467445482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15297', 'ltc_cny', '', '1', '0', '1467445542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15298', 'ltc_cny', '', '1', '0', '1467445602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15299', 'ltc_cny', '', '1', '0', '1467445662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15300', 'ltc_cny', '', '1', '0', '1467445722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15301', 'ltc_cny', '', '1', '0', '1467445782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15302', 'ltc_cny', '', '1', '0', '1467445842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15303', 'ltc_cny', '', '1', '0', '1467445902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15304', 'ltc_cny', '', '1', '0', '1467445962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15305', 'ltc_cny', '', '1', '0', '1467446022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15306', 'ltc_cny', '', '1', '0', '1467446082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15307', 'ltc_cny', '', '1', '0', '1467446142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15308', 'btc_cny', '', '1', '0', '1467516692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15309', 'btc_cny', '', '1', '0', '1467516752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15310', 'btc_cny', '', '1', '0', '1467516812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15311', 'btc_cny', '', '1', '0', '1467516872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15312', 'btc_cny', '', '1', '0', '1467516932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15313', 'btc_cny', '', '1', '0', '1467516992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15314', 'btc_cny', '', '1', '0', '1467517052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15315', 'btc_cny', '', '1', '0', '1467517112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15316', 'btc_cny', '', '1', '0', '1467517172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15317', 'btc_cny', '', '1', '0', '1467517232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15318', 'btc_cny', '', '1', '0', '1467517292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15319', 'btc_cny', '', '1', '0', '1467517352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15320', 'btc_cny', '', '1', '0', '1467517412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15321', 'btc_cny', '', '1', '0', '1467517472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15322', 'btc_cny', '', '1', '0', '1467517532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15323', 'btc_cny', '', '1', '0', '1467517592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15324', 'btc_cny', '', '1', '0', '1467517652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15325', 'btc_cny', '', '1', '0', '1467517712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15326', 'btc_cny', '', '1', '0', '1467517772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15327', 'btc_cny', '', '1', '0', '1467517832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15328', 'btc_cny', '', '1', '0', '1467517892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15329', 'ltc_cny', '', '1', '0', '1467446142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15330', 'ltc_cny', '', '1', '0', '1467446202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15331', 'ltc_cny', '', '1', '0', '1467446262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15332', 'ltc_cny', '', '1', '0', '1467446322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15333', 'ltc_cny', '', '1', '0', '1467446382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15334', 'ltc_cny', '', '1', '0', '1467446442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15335', 'ltc_cny', '', '1', '0', '1467446502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15336', 'ltc_cny', '', '1', '0', '1467446562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15337', 'ltc_cny', '', '1', '0', '1467446622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15338', 'ltc_cny', '', '1', '0', '1467446682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15339', 'ltc_cny', '', '1', '0', '1467446742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15340', 'ltc_cny', '', '1', '0', '1467446802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15341', 'ltc_cny', '', '1', '0', '1467446862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15342', 'ltc_cny', '', '1', '0', '1467446922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15343', 'ltc_cny', '', '1', '0', '1467446982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15344', 'ltc_cny', '', '1', '0', '1467447042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15345', 'ltc_cny', '', '1', '0', '1467447102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15346', 'ltc_cny', '', '1', '0', '1467447162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15347', 'ltc_cny', '', '1', '0', '1467447222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15348', 'ltc_cny', '', '1', '0', '1467447282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15349', 'ltc_cny', '', '1', '0', '1467447342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15350', 'btc_cny', '', '1', '0', '1467517892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15351', 'btc_cny', '', '1', '0', '1467517952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15352', 'btc_cny', '', '1', '0', '1467518012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15353', 'btc_cny', '', '1', '0', '1467518072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15354', 'btc_cny', '', '1', '0', '1467518132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15355', 'btc_cny', '', '1', '0', '1467518192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15356', 'btc_cny', '', '1', '0', '1467518252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15357', 'btc_cny', '', '1', '0', '1467518312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15358', 'btc_cny', '', '1', '0', '1467518372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15359', 'btc_cny', '', '1', '0', '1467518432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15360', 'btc_cny', '', '1', '0', '1467518492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15361', 'btc_cny', '', '1', '0', '1467518552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15362', 'btc_cny', '', '1', '0', '1467518612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15363', 'btc_cny', '', '1', '0', '1467518672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15364', 'btc_cny', '', '1', '0', '1467518732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15365', 'btc_cny', '', '1', '0', '1467518792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15366', 'btc_cny', '', '1', '0', '1467518852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15367', 'btc_cny', '', '1', '0', '1467518912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15368', 'btc_cny', '', '1', '0', '1467518972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15369', 'btc_cny', '', '1', '0', '1467519032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15370', 'btc_cny', '', '1', '0', '1467519092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15371', 'ltc_cny', '', '1', '0', '1467447342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15372', 'ltc_cny', '', '1', '0', '1467447402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15373', 'ltc_cny', '', '1', '0', '1467447462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15374', 'ltc_cny', '', '1', '0', '1467447522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15375', 'ltc_cny', '', '1', '0', '1467447582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15376', 'ltc_cny', '', '1', '0', '1467447642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15377', 'ltc_cny', '', '1', '0', '1467447702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15378', 'ltc_cny', '', '1', '0', '1467447762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15379', 'ltc_cny', '', '1', '0', '1467447822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15380', 'ltc_cny', '', '1', '0', '1467447882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15381', 'ltc_cny', '', '1', '0', '1467447942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15382', 'ltc_cny', '', '1', '0', '1467448002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15383', 'ltc_cny', '', '1', '0', '1467448062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15384', 'ltc_cny', '', '1', '0', '1467448122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15385', 'ltc_cny', '', '1', '0', '1467448182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15386', 'ltc_cny', '', '1', '0', '1467448242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15387', 'ltc_cny', '', '1', '0', '1467448302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15388', 'ltc_cny', '', '1', '0', '1467448362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15389', 'ltc_cny', '', '1', '0', '1467448422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15390', 'ltc_cny', '', '1', '0', '1467448482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15391', 'ltc_cny', '', '1', '0', '1467448542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15392', 'btc_cny', '', '1', '0', '1467519092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15393', 'btc_cny', '', '1', '0', '1467519152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15394', 'btc_cny', '', '1', '0', '1467519212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15395', 'btc_cny', '', '1', '0', '1467519272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15396', 'btc_cny', '', '1', '0', '1467519332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15397', 'btc_cny', '', '1', '0', '1467519392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15398', 'btc_cny', '', '1', '0', '1467519452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15399', 'btc_cny', '', '1', '0', '1467519512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15400', 'btc_cny', '', '1', '0', '1467519572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15401', 'btc_cny', '', '1', '0', '1467519632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15402', 'btc_cny', '', '1', '0', '1467519692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15403', 'btc_cny', '', '1', '0', '1467519752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15404', 'btc_cny', '', '1', '0', '1467519812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15405', 'btc_cny', '', '1', '0', '1467519872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15406', 'btc_cny', '', '1', '0', '1467519932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15407', 'btc_cny', '', '1', '0', '1467519992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15408', 'btc_cny', '', '1', '0', '1467520052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15409', 'btc_cny', '', '1', '0', '1467520112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15410', 'btc_cny', '', '1', '0', '1467520172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15411', 'btc_cny', '', '1', '0', '1467520232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15412', 'btc_cny', '', '1', '0', '1467520292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15413', 'ltc_cny', '', '1', '0', '1467448542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15414', 'ltc_cny', '', '1', '0', '1467448602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15415', 'ltc_cny', '', '1', '0', '1467448662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15416', 'ltc_cny', '', '1', '0', '1467448722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15417', 'ltc_cny', '', '1', '0', '1467448782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15418', 'ltc_cny', '', '1', '0', '1467448842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15419', 'ltc_cny', '', '1', '0', '1467448902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15420', 'ltc_cny', '', '1', '0', '1467448962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15421', 'ltc_cny', '', '1', '0', '1467449022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15422', 'ltc_cny', '', '1', '0', '1467449082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15423', 'ltc_cny', '', '1', '0', '1467449142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15424', 'ltc_cny', '', '1', '0', '1467449202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15425', 'ltc_cny', '', '1', '0', '1467449262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15426', 'ltc_cny', '', '1', '0', '1467449322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15427', 'ltc_cny', '', '1', '0', '1467449382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15428', 'ltc_cny', '', '1', '0', '1467449442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15429', 'ltc_cny', '', '1', '0', '1467449502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15430', 'ltc_cny', '', '1', '0', '1467449562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15431', 'ltc_cny', '', '1', '0', '1467449622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15432', 'ltc_cny', '', '1', '0', '1467449682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15433', 'ltc_cny', '', '1', '0', '1467449742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15434', 'btc_cny', '', '1', '0', '1467520292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15435', 'btc_cny', '', '1', '0', '1467520352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15436', 'btc_cny', '', '1', '0', '1467520412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15437', 'btc_cny', '', '1', '0', '1467520472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15438', 'btc_cny', '', '1', '0', '1467520532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15439', 'btc_cny', '', '1', '0', '1467520592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15440', 'btc_cny', '', '1', '0', '1467520652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15441', 'btc_cny', '', '1', '0', '1467520712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15442', 'btc_cny', '', '1', '0', '1467520772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15443', 'btc_cny', '', '1', '0', '1467520832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15444', 'btc_cny', '', '1', '0', '1467520892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15445', 'btc_cny', '', '1', '0', '1467520952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15446', 'btc_cny', '', '1', '0', '1467521012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15447', 'btc_cny', '', '1', '0', '1467521072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15448', 'btc_cny', '', '1', '0', '1467521132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15449', 'btc_cny', '', '1', '0', '1467521192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15450', 'btc_cny', '', '1', '0', '1467521252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15451', 'btc_cny', '', '1', '0', '1467521312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15452', 'btc_cny', '', '1', '0', '1467521372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15453', 'btc_cny', '', '1', '0', '1467521432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15454', 'btc_cny', '', '1', '0', '1467521492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15455', 'ltc_cny', '', '1', '0', '1467449742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15456', 'ltc_cny', '', '1', '0', '1467449802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15457', 'ltc_cny', '', '1', '0', '1467449862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15458', 'ltc_cny', '', '1', '0', '1467449922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15459', 'ltc_cny', '', '1', '0', '1467449982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15460', 'ltc_cny', '', '1', '0', '1467450042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15461', 'ltc_cny', '', '1', '0', '1467450102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15462', 'ltc_cny', '', '1', '0', '1467450162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15463', 'ltc_cny', '', '1', '0', '1467450222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15464', 'ltc_cny', '', '1', '0', '1467450282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15465', 'ltc_cny', '', '1', '0', '1467450342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15466', 'ltc_cny', '', '1', '0', '1467450402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15467', 'ltc_cny', '', '1', '0', '1467450462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15468', 'ltc_cny', '', '1', '0', '1467450522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15469', 'ltc_cny', '', '1', '0', '1467450582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15470', 'ltc_cny', '', '1', '0', '1467450642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15471', 'ltc_cny', '', '1', '0', '1467450702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15472', 'ltc_cny', '', '1', '0', '1467450762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15473', 'ltc_cny', '', '1', '0', '1467450822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15474', 'ltc_cny', '', '1', '0', '1467450882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15475', 'ltc_cny', '', '1', '0', '1467450942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15476', 'btc_cny', '', '1', '0', '1467521492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15477', 'btc_cny', '', '1', '0', '1467521552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15478', 'btc_cny', '', '1', '0', '1467521612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15479', 'btc_cny', '', '1', '0', '1467521672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15480', 'btc_cny', '', '1', '0', '1467521732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15481', 'btc_cny', '', '1', '0', '1467521792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15482', 'btc_cny', '', '1', '0', '1467521852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15483', 'btc_cny', '', '1', '0', '1467521912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15484', 'btc_cny', '', '1', '0', '1467521972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15485', 'btc_cny', '', '1', '0', '1467522032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15486', 'btc_cny', '', '1', '0', '1467522092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15487', 'btc_cny', '', '1', '0', '1467522152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15488', 'btc_cny', '', '1', '0', '1467522212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15489', 'btc_cny', '', '1', '0', '1467522272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15490', 'btc_cny', '', '1', '0', '1467522332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15491', 'btc_cny', '', '1', '0', '1467522392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15492', 'btc_cny', '', '1', '0', '1467522452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15493', 'btc_cny', '', '1', '0', '1467522512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15494', 'btc_cny', '', '1', '0', '1467522572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15495', 'btc_cny', '', '1', '0', '1467522632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15496', 'btc_cny', '', '1', '0', '1467522692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15497', 'ltc_cny', '', '1', '0', '1467450942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15498', 'ltc_cny', '', '1', '0', '1467451002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15499', 'ltc_cny', '', '1', '0', '1467451062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15500', 'ltc_cny', '', '1', '0', '1467451122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15501', 'ltc_cny', '', '1', '0', '1467451182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15502', 'ltc_cny', '', '1', '0', '1467451242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15503', 'ltc_cny', '', '1', '0', '1467451302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15504', 'ltc_cny', '', '1', '0', '1467451362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15505', 'ltc_cny', '', '1', '0', '1467451422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15506', 'ltc_cny', '', '1', '0', '1467451482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15507', 'ltc_cny', '', '1', '0', '1467451542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15508', 'ltc_cny', '', '1', '0', '1467451602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15509', 'ltc_cny', '', '1', '0', '1467451662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15510', 'ltc_cny', '', '1', '0', '1467451722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15511', 'ltc_cny', '', '1', '0', '1467451782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15512', 'ltc_cny', '', '1', '0', '1467451842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15513', 'ltc_cny', '', '1', '0', '1467451902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15514', 'ltc_cny', '', '1', '0', '1467451962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15515', 'ltc_cny', '', '1', '0', '1467452022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15516', 'ltc_cny', '', '1', '0', '1467452082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15517', 'ltc_cny', '', '1', '0', '1467452142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15518', 'btc_cny', '', '1', '0', '1467522692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15519', 'btc_cny', '', '1', '0', '1467522752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15520', 'btc_cny', '', '1', '0', '1467522812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15521', 'btc_cny', '', '1', '0', '1467522872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15522', 'btc_cny', '', '1', '0', '1467522932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15523', 'btc_cny', '', '1', '0', '1467522992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15524', 'btc_cny', '', '1', '0', '1467523052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15525', 'btc_cny', '', '1', '0', '1467523112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15526', 'btc_cny', '', '1', '0', '1467523172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15527', 'btc_cny', '', '1', '0', '1467523232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15528', 'btc_cny', '', '1', '0', '1467523292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15529', 'btc_cny', '', '1', '0', '1467523352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15530', 'btc_cny', '', '1', '0', '1467523412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15531', 'btc_cny', '', '1', '0', '1467523472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15532', 'btc_cny', '', '1', '0', '1467523532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15533', 'btc_cny', '', '1', '0', '1467523592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15534', 'btc_cny', '', '1', '0', '1467523652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15535', 'btc_cny', '', '1', '0', '1467523712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15536', 'btc_cny', '', '1', '0', '1467523772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15537', 'btc_cny', '', '1', '0', '1467523832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15538', 'btc_cny', '', '1', '0', '1467523892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15539', 'ltc_cny', '', '1', '0', '1467452142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15540', 'ltc_cny', '', '1', '0', '1467452202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15541', 'ltc_cny', '', '1', '0', '1467452262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15542', 'ltc_cny', '', '1', '0', '1467452322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15543', 'ltc_cny', '', '1', '0', '1467452382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15544', 'ltc_cny', '', '1', '0', '1467452442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15545', 'ltc_cny', '', '1', '0', '1467452502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15546', 'ltc_cny', '', '1', '0', '1467452562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15547', 'ltc_cny', '', '1', '0', '1467452622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15548', 'ltc_cny', '', '1', '0', '1467452682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15549', 'ltc_cny', '', '1', '0', '1467452742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15550', 'ltc_cny', '', '1', '0', '1467452802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15551', 'ltc_cny', '', '1', '0', '1467452862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15552', 'ltc_cny', '', '1', '0', '1467452922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15553', 'ltc_cny', '', '1', '0', '1467452982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15554', 'ltc_cny', '', '1', '0', '1467453042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15555', 'ltc_cny', '', '1', '0', '1467453102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15556', 'ltc_cny', '', '1', '0', '1467453162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15557', 'ltc_cny', '', '1', '0', '1467453222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15558', 'ltc_cny', '', '1', '0', '1467453282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15559', 'ltc_cny', '', '1', '0', '1467453342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15560', 'btc_cny', '', '1', '0', '1467523892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15561', 'btc_cny', '', '1', '0', '1467523952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15562', 'btc_cny', '', '1', '0', '1467524012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15563', 'btc_cny', '', '1', '0', '1467524072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15564', 'btc_cny', '', '1', '0', '1467524132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15565', 'btc_cny', '', '1', '0', '1467524192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15566', 'btc_cny', '', '1', '0', '1467524252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15567', 'btc_cny', '', '1', '0', '1467524312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15568', 'btc_cny', '', '1', '0', '1467524372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15569', 'btc_cny', '', '1', '0', '1467524432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15570', 'btc_cny', '', '1', '0', '1467524492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15571', 'btc_cny', '', '1', '0', '1467524552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15572', 'btc_cny', '', '1', '0', '1467524612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15573', 'btc_cny', '', '1', '0', '1467524672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15574', 'btc_cny', '', '1', '0', '1467524732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15575', 'btc_cny', '', '1', '0', '1467524792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15576', 'btc_cny', '', '1', '0', '1467524852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15577', 'btc_cny', '', '1', '0', '1467524912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15578', 'btc_cny', '', '1', '0', '1467524972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15579', 'btc_cny', '', '1', '0', '1467525032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15580', 'btc_cny', '', '1', '0', '1467525092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15581', 'ltc_cny', '', '1', '0', '1467453342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15582', 'ltc_cny', '', '1', '0', '1467453402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15583', 'ltc_cny', '', '1', '0', '1467453462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15584', 'ltc_cny', '', '1', '0', '1467453522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15585', 'ltc_cny', '', '1', '0', '1467453582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15586', 'ltc_cny', '', '1', '0', '1467453642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15587', 'ltc_cny', '', '1', '0', '1467453702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15588', 'ltc_cny', '', '1', '0', '1467453762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15589', 'ltc_cny', '', '1', '0', '1467453822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15590', 'ltc_cny', '', '1', '0', '1467453882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15591', 'ltc_cny', '', '1', '0', '1467453942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15592', 'ltc_cny', '', '1', '0', '1467454002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15593', 'ltc_cny', '', '1', '0', '1467454062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15594', 'ltc_cny', '', '1', '0', '1467454122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15595', 'ltc_cny', '', '1', '0', '1467454182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15596', 'ltc_cny', '', '1', '0', '1467454242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15597', 'ltc_cny', '', '1', '0', '1467454302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15598', 'ltc_cny', '', '1', '0', '1467454362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15599', 'ltc_cny', '', '1', '0', '1467454422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15600', 'ltc_cny', '', '1', '0', '1467454482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15601', 'ltc_cny', '', '1', '0', '1467454542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15602', 'btc_cny', '', '1', '0', '1467525092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15603', 'btc_cny', '', '1', '0', '1467525152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15604', 'btc_cny', '', '1', '0', '1467525212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15605', 'btc_cny', '', '1', '0', '1467525272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15606', 'btc_cny', '', '1', '0', '1467525332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15607', 'btc_cny', '', '1', '0', '1467525392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15608', 'btc_cny', '', '1', '0', '1467525452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15609', 'btc_cny', '', '1', '0', '1467525512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15610', 'btc_cny', '', '1', '0', '1467525572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15611', 'btc_cny', '', '1', '0', '1467525632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15612', 'btc_cny', '', '1', '0', '1467525692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15613', 'btc_cny', '', '1', '0', '1467525752', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15614', 'btc_cny', '', '1', '0', '1467525812', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15615', 'btc_cny', '', '1', '0', '1467525872', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15616', 'btc_cny', '', '1', '0', '1467525932', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15617', 'btc_cny', '', '1', '0', '1467525992', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15618', 'btc_cny', '', '1', '0', '1467526052', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15619', 'btc_cny', '', '1', '0', '1467526112', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15620', 'btc_cny', '', '1', '0', '1467526172', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15621', 'btc_cny', '', '1', '0', '1467526232', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15622', 'btc_cny', '', '1', '0', '1467526292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15623', 'ltc_cny', '', '1', '0', '1467454542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15624', 'ltc_cny', '', '1', '0', '1467454602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15625', 'ltc_cny', '', '1', '0', '1467454662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15626', 'ltc_cny', '', '1', '0', '1467454722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15627', 'ltc_cny', '', '1', '0', '1467454782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15628', 'ltc_cny', '', '1', '0', '1467454842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15629', 'ltc_cny', '', '1', '0', '1467454902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15630', 'ltc_cny', '', '1', '0', '1467454962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15631', 'ltc_cny', '', '1', '0', '1467455022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15632', 'ltc_cny', '', '1', '0', '1467455082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15633', 'ltc_cny', '', '1', '0', '1467455142', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15634', 'ltc_cny', '', '1', '0', '1467455202', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15635', 'ltc_cny', '', '1', '0', '1467455262', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15636', 'ltc_cny', '', '1', '0', '1467455322', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15637', 'ltc_cny', '', '1', '0', '1467455382', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15638', 'ltc_cny', '', '1', '0', '1467455442', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15639', 'ltc_cny', '', '1', '0', '1467455502', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15640', 'ltc_cny', '', '1', '0', '1467455562', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15641', 'ltc_cny', '', '1', '0', '1467455622', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15642', 'ltc_cny', '', '1', '0', '1467455682', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15643', 'ltc_cny', '', '1', '0', '1467455742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15644', 'btc_cny', '', '1', '0', '1467526292', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15645', 'btc_cny', '', '1', '0', '1467526352', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15646', 'btc_cny', '', '1', '0', '1467526412', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15647', 'btc_cny', '', '1', '0', '1467526472', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15648', 'btc_cny', '', '1', '0', '1467526532', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15649', 'btc_cny', '', '1', '0', '1467526592', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15650', 'btc_cny', '', '1', '0', '1467526652', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15651', 'btc_cny', '', '1', '0', '1467526712', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15652', 'btc_cny', '', '1', '0', '1467526772', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15653', 'btc_cny', '', '1', '0', '1467526832', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15654', 'btc_cny', '', '1', '0', '1467526892', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15655', 'btc_cny', '', '1', '0', '1467526952', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15656', 'btc_cny', '', '1', '0', '1467527012', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15657', 'btc_cny', '', '1', '0', '1467527072', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15658', 'btc_cny', '', '1', '0', '1467527132', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15659', 'btc_cny', '', '1', '0', '1467527192', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15660', 'btc_cny', '', '1', '0', '1467527252', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15661', 'btc_cny', '', '1', '0', '1467527312', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15662', 'btc_cny', '', '1', '0', '1467527372', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15663', 'btc_cny', '', '1', '0', '1467527432', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15664', 'btc_cny', '', '1', '0', '1467527492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15665', 'ltc_cny', '', '1', '0', '1467455742', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15666', 'ltc_cny', '', '1', '0', '1467455802', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15667', 'ltc_cny', '', '1', '0', '1467455862', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15668', 'ltc_cny', '', '1', '0', '1467455922', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15669', 'ltc_cny', '', '1', '0', '1467455982', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15670', 'ltc_cny', '', '1', '0', '1467456042', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15671', 'ltc_cny', '', '1', '0', '1467456102', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15672', 'ltc_cny', '', '1', '0', '1467456162', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15673', 'ltc_cny', '', '1', '0', '1467456222', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15674', 'ltc_cny', '', '1', '0', '1467456282', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15675', 'ltc_cny', '', '1', '0', '1467456342', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15676', 'ltc_cny', '', '1', '0', '1467456402', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15677', 'ltc_cny', '', '1', '0', '1467456462', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15678', 'ltc_cny', '', '1', '0', '1467456522', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15679', 'ltc_cny', '', '1', '0', '1467456582', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15680', 'ltc_cny', '', '1', '0', '1467456642', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15681', 'ltc_cny', '', '1', '0', '1467456702', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15682', 'ltc_cny', '', '1', '0', '1467456762', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15683', 'ltc_cny', '', '1', '0', '1467456822', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15684', 'ltc_cny', '', '1', '0', '1467456882', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15685', 'ltc_cny', '', '1', '0', '1467456942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15686', 'btc_cny', '', '1', '0', '1467527492', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15687', 'btc_cny', '', '1', '0', '1467527552', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15688', 'btc_cny', '', '1', '0', '1467527612', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15689', 'btc_cny', '', '1', '0', '1467527672', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15690', 'btc_cny', '', '1', '0', '1467527732', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15691', 'btc_cny', '', '1', '0', '1467527792', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15692', 'btc_cny', '', '1', '0', '1467527852', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15693', 'btc_cny', '', '1', '0', '1467527912', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15694', 'btc_cny', '', '1', '0', '1467527972', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15695', 'btc_cny', '', '1', '0', '1467528032', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15696', 'btc_cny', '', '1', '0', '1467528092', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15697', 'btc_cny', '', '1', '0', '1467528152', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15698', 'btc_cny', '', '1', '0', '1467528212', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15699', 'btc_cny', '', '1', '0', '1467528272', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15700', 'btc_cny', '', '1', '0', '1467528332', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15701', 'btc_cny', '', '1', '0', '1467528392', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15702', 'btc_cny', '', '1', '0', '1467528452', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15703', 'btc_cny', '', '1', '0', '1467528512', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15704', 'btc_cny', '', '1', '0', '1467528572', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15705', 'btc_cny', '', '1', '0', '1467528632', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15706', 'btc_cny', '', '1', '0', '1467528692', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15707', 'ltc_cny', '', '1', '0', '1467456942', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15708', 'ltc_cny', '', '1', '0', '1467457002', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15709', 'ltc_cny', '', '1', '0', '1467457062', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15710', 'ltc_cny', '', '1', '0', '1467457122', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15711', 'ltc_cny', '', '1', '0', '1467457182', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15712', 'ltc_cny', '', '1', '0', '1467457242', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15713', 'ltc_cny', '', '1', '0', '1467457302', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15714', 'ltc_cny', '', '1', '0', '1467457362', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15715', 'ltc_cny', '', '1', '0', '1467457422', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15716', 'ltc_cny', '', '1', '0', '1467457482', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15717', 'ltc_cny', '', '1', '0', '1467457542', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15718', 'ltc_cny', '', '1', '0', '1467457602', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15719', 'ltc_cny', '', '1', '0', '1467457662', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15720', 'ltc_cny', '', '1', '0', '1467457722', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15721', 'ltc_cny', '', '1', '0', '1467457782', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15722', 'ltc_cny', '', '1', '0', '1467457842', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15723', 'ltc_cny', '', '1', '0', '1467457902', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15724', 'ltc_cny', '', '1', '0', '1467457962', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15725', 'ltc_cny', '', '1', '0', '1467458022', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15726', 'ltc_cny', '', '1', '0', '1467458082', '0', '0');
INSERT INTO `movesay_trade_json` VALUES ('15727', 'ltc_cny', '', '1', '0', '1467458142', '0', '0');

-- -----------------------------
-- Table structure for `movesay_trade_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_trade_log`;
CREATE TABLE `movesay_trade_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `peerid` int(11) unsigned NOT NULL,
  `market` varchar(50) NOT NULL,
  `price` decimal(20,8) unsigned NOT NULL,
  `num` decimal(20,8) unsigned NOT NULL,
  `mum` decimal(20,8) unsigned NOT NULL,
  `fee_buy` decimal(20,8) unsigned NOT NULL,
  `fee_sell` decimal(20,8) unsigned NOT NULL,
  `type` tinyint(2) unsigned NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `peerid` (`peerid`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=gbk;

-- -----------------------------
-- Records of `movesay_trade_log`
-- -----------------------------
INSERT INTO `movesay_trade_log` VALUES ('1', '2', '2', 'btc_cny', '4350.00000000', '1.00000000', '4350.00000000', '0.00000000', '0.00000000', '2', '0', '1467291032', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('2', '2', '2', 'btc_cny', '4350.00000000', '1.00000000', '4350.00000000', '0.00000000', '0.00000000', '2', '0', '1467291036', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('3', '2', '2', 'btc_cny', '4400.00000000', '0.30000000', '1320.00000000', '0.00000000', '0.00000000', '1', '0', '1467291050', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('4', '2', '2', 'btc_cny', '4400.00000000', '0.10000000', '440.00000000', '0.00000000', '0.00000000', '1', '0', '1467291060', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('5', '2', '2', 'btc_cny', '4400.00000000', '0.10000000', '440.00000000', '0.00000000', '0.00000000', '1', '0', '1467291073', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('6', '2', '2', 'ltc_cny', '27.00000000', '42.00000000', '1134.00000000', '0.00000000', '0.00000000', '2', '0', '1467291282', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('7', '2', '2', 'ltc_cny', '27.00000000', '45.00000000', '1215.00000000', '0.00000000', '0.00000000', '2', '0', '1467291288', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('8', '2', '2', 'ltc_cny', '27.00000000', '786.00000000', '21222.00000000', '0.00000000', '0.00000000', '2', '0', '1467291295', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('9', '2', '2', 'ltc_cny', '27.00000000', '1.00000000', '27.00000000', '0.00000000', '0.00000000', '2', '0', '1467291307', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('10', '2', '2', 'ltc_cny', '30.00000000', '1.00000000', '30.00000000', '0.00000000', '0.00000000', '1', '0', '1467291314', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('11', '2', '2', 'ltc_cny', '30.00000000', '1.00000000', '30.00000000', '0.00000000', '0.00000000', '1', '0', '1467291319', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('12', '2', '2', 'ytc_cny', '11.00000000', '1.00000000', '11.00000000', '0.00000000', '0.00000000', '1', '0', '1467291605', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('13', '2', '2', 'ytc_cny', '10.00000000', '453.00000000', '4530.00000000', '0.00000000', '0.00000000', '2', '0', '1467291610', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('14', '2', '2', 'ytc_cny', '10.00000000', '45.00000000', '450.00000000', '0.00000000', '0.00000000', '2', '0', '1467291620', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('15', '2', '2', 'ytc_cny', '10.00000000', '55.00000000', '550.00000000', '0.00000000', '0.00000000', '2', '0', '1467291624', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('16', '2', '2', 'ytc_cny', '11.00000000', '444.00000000', '4884.00000000', '0.00000000', '0.00000000', '1', '0', '1467291632', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('17', '2', '2', 'ytc_cny', '11.00000000', '45.00000000', '495.00000000', '0.00000000', '0.00000000', '1', '0', '1467291640', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('18', '2', '2', 'btc_cny', '4400.00000000', '1.00000000', '4400.00000000', '0.00000000', '0.00000000', '1', '0', '1467360689', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('19', '2', '2', 'btc_cny', '4400.00000000', '1.00000000', '4400.00000000', '0.00000000', '0.00000000', '1', '0', '1467360694', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('20', '2', '2', 'btc_cny', '4399.00000000', '1.00000000', '4399.00000000', '0.00000000', '0.00000000', '2', '0', '1467360697', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('21', '2', '2', 'btc_cny', '4399.00000000', '1.00000000', '4399.00000000', '0.00000000', '0.00000000', '2', '0', '1467360700', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('22', '2', '2', 'btc_cny', '4400.00000000', '1.00000000', '4400.00000000', '0.00000000', '0.00000000', '1', '0', '1467608890', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('23', '2', '2', 'btc_cny', '4400.00000000', '5.40000000', '23760.00000000', '0.00000000', '0.00000000', '1', '0', '1467608895', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('24', '2', '2', 'btc_cny', '4400.00000000', '1.70000000', '7480.00000000', '0.00000000', '0.00000000', '1', '0', '1467608900', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('25', '2', '2', 'btc_cny', '4568.00000000', '12.00000000', '54816.00000000', '0.00000000', '0.00000000', '1', '0', '1467608900', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('26', '2', '2', 'btc_cny', '4599.00000000', '1.00000000', '4599.00000000', '0.00000000', '0.00000000', '1', '0', '1467608914', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('27', '2', '2', 'btc_cny', '4599.00000000', '1.00000000', '4599.00000000', '0.00000000', '0.00000000', '1', '0', '1467608921', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('28', '2', '2', 'ltc_cny', '30.00000000', '1.00000000', '30.00000000', '0.00000000', '0.00000000', '1', '0', '1467608938', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('29', '2', '2', 'ltc_cny', '30.00000000', '21.00000000', '630.00000000', '0.00000000', '0.00000000', '1', '0', '1467608941', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('30', '2', '2', 'ltc_cny', '30.00000000', '12.00000000', '360.00000000', '0.00000000', '0.00000000', '1', '0', '1467608945', '0', '1');
INSERT INTO `movesay_trade_log` VALUES ('31', '2', '2', 'ltc_cny', '30.00000000', '11.00000000', '330.00000000', '0.00000000', '0.00000000', '1', '0', '1467608949', '0', '1');

-- -----------------------------
-- Table structure for `movesay_user`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user`;
CREATE TABLE `movesay_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `moble` varchar(50) NOT NULL,
  `mobletime` int(11) unsigned NOT NULL,
  `password` varchar(32) NOT NULL,
  `tpwdsetting` varchar(32) NOT NULL,
  `paypassword` varchar(32) NOT NULL,
  `invit` varchar(32) NOT NULL,
  `invit_1` varchar(50) NOT NULL,
  `invit_2` varchar(50) NOT NULL,
  `invit_3` varchar(50) NOT NULL,
  `truename` varchar(32) NOT NULL,
  `idcard` varchar(32) NOT NULL,
  `logins` int(11) unsigned NOT NULL,
  `ga` varchar(50) NOT NULL,
  `addip` varchar(50) NOT NULL,
  `addr` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `email` varchar(200) DEFAULT NULL COMMENT '邮箱',
  `alipay` varchar(200) DEFAULT NULL COMMENT '支付宝',
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='用户信息表';

-- -----------------------------
-- Records of `movesay_user`
-- -----------------------------
INSERT INTO `movesay_user` VALUES ('1', 'movesay', '', '0', 'b887cbf3cbbc67a332b47eab6fadbc89', '1', '0a7de7a81d7e87b6f2cde05d0e692d07', 'RLSHFK', '0', '0', '0', '牛一', '420117198804074311', '0', '', '127.0.0.1', '未分配或者内网IP', '0', '1459584765', '0', '1', '', '');
INSERT INTO `movesay_user` VALUES ('2', 'BTC10000', '18573148630', '1467359791', 'e10adc3949ba59abbe56e057f20f883e', '1', 'fcea920f7412b5da7be0cf42b8c93759', 'EXHGTU', '0', '0', '0', '牛牛', '430822198712120000', '6', '', '121.34.129.214', '未分配或者内网IP', '0', '1467279524', '0', '1', '', '');
INSERT INTO `movesay_user` VALUES ('3', 'yjj123', '', '0', 'e10adc3949ba59abbe56e057f20f883e', '1', 'c33367701511b4f6020ec61ded352059', 'QMHJWR', '0', '0', '0', '的广泛的', '111111111111111111', '3', '', '112.95.136.101', '未分配或者内网IP', '0', '1467285932', '0', '1', '', '');
INSERT INTO `movesay_user` VALUES ('4', 'btc20000', '13888888888', '1469894400', 'e10adc3949ba59abbe56e057f20f883e', '1', 'fcea920f7412b5da7be0cf42b8c93759', 'HLAMGQ', '2', '0', '0', '牛位', '430901195012120000', '0', '', '121.34.129.214', '未分配或者内网IP', '0', '1467353358', '0', '1', '', '');

-- -----------------------------
-- Table structure for `movesay_user_bank`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_bank`;
CREATE TABLE `movesay_user_bank` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `name` varchar(200) NOT NULL,
  `bank` varchar(200) NOT NULL,
  `bankprov` varchar(200) NOT NULL,
  `bankcity` varchar(200) NOT NULL,
  `bankaddr` varchar(200) NOT NULL,
  `bankcard` varchar(200) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_user_bank`
-- -----------------------------
INSERT INTO `movesay_user_bank` VALUES ('1', '2', '广东', '平安银行', '广东', '深圳', '科技园支行', '8888888888888888', '0', '1467292115', '0', '1');
INSERT INTO `movesay_user_bank` VALUES ('2', '4', '123', '平安银行', '北京', '西城区', '哈哈哈', '88888888', '0', '1467354708', '0', '1');

-- -----------------------------
-- Table structure for `movesay_user_bank_type`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_bank_type`;
CREATE TABLE `movesay_user_bank_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL,
  `mytx` varchar(200) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='常用银行地址';

-- -----------------------------
-- Records of `movesay_user_bank_type`
-- -----------------------------
INSERT INTO `movesay_user_bank_type` VALUES ('4', 'boc', '中国银行', 'http://www.boc.cn/', 'img_56937003683ce.jpg', '', '', '0', '1452503043', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('5', 'abc', '农业银行', 'http://www.abchina.com/cn/', 'img_569370458b18d.jpg', '', '', '0', '1452503109', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('6', 'bccb', '北京银行', 'http://www.bankofbeijing.com.cn/', 'img_569370588dcdc.jpg', '', '', '0', '1452503128', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('8', 'ccb', '建设银行', 'http://www.ccb.com/', 'img_5693709bbd20f.jpg', '', '', '0', '1452503195', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('9', 'ceb', '光大银行', 'http://www.bankofbeijing.com.cn/', 'img_569370b207cc8.jpg', '', '', '0', '1452503218', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('10', 'cib', '兴业银行', 'http://www.cib.com.cn/cn/index.html', 'img_569370d29bf59.jpg', '', '', '0', '1452503250', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('11', 'citic', '中信银行', 'http://www.ecitic.com/', 'img_569370fb7a1b3.jpg', '', '', '0', '1452503291', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('12', 'cmb', '招商银行', 'http://www.cmbchina.com/', 'img_5693710a9ac9c.jpg', '', '', '0', '1452503306', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('13', 'cmbc', '民生银行', 'http://www.cmbchina.com/', 'img_5693711f97a9d.jpg', '', '', '0', '1452503327', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('14', 'comm', '交通银行', 'http://www.bankcomm.com/BankCommSite/default.shtml', 'img_5693713076351.jpg', '', '', '0', '1452503344', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('16', 'gdb', '广发银行', 'http://www.cgbchina.com.cn/', 'img_56937154bebc5.jpg', '', '', '0', '1452503380', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('17', 'icbc', '工商银行', 'http://www.icbc.com.cn/icbc/', 'img_56937162db7f5.jpg', '', '', '0', '1452503394', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('19', 'psbc', '邮政银行', 'http://www.psbc.com/portal/zh_CN/index.html', 'img_5693717eefaa3.jpg', '', '', '0', '1452503422', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('20', 'spdb', '浦发银行', 'http://www.spdb.com.cn/chpage/c1/', 'img_5693718f1d70e.jpg', '', '', '0', '1452503439', '0', '1');
INSERT INTO `movesay_user_bank_type` VALUES ('21', 'szpab', '平安银行', 'http://bank.pingan.com/', '56c2e4c9aff85.jpg', '', '', '0', '1455613129', '0', '1');

-- -----------------------------
-- Table structure for `movesay_user_coin`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_coin`;
CREATE TABLE `movesay_user_coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL,
  `cny` decimal(20,8) unsigned NOT NULL,
  `cnyd` decimal(20,8) unsigned NOT NULL,
  `btc` decimal(20,8) unsigned NOT NULL,
  `btcd` decimal(20,8) unsigned NOT NULL,
  `btcb` varchar(200) NOT NULL,
  `ltc` decimal(20,8) unsigned NOT NULL,
  `ltcd` decimal(20,8) unsigned NOT NULL,
  `ltcb` varchar(200) NOT NULL,
  `avc` decimal(20,8) unsigned NOT NULL,
  `avcd` decimal(20,8) unsigned NOT NULL,
  `avcb` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='用户币种表';

-- -----------------------------
-- Records of `movesay_user_coin`
-- -----------------------------
INSERT INTO `movesay_user_coin` VALUES ('1', '1', '0.00000000', '0.00000000', '0.00000000', '0.00000000', '', '0.00000000', '0.00000000', '', '0.00000000', '0.00000000', '');
INSERT INTO `movesay_user_coin` VALUES ('2', '2', '7525141.40000000', '2567875.60000000', '9141.00000000', '859.00000000', '', '97399.00000000', '2601.00000000', '', '10000.00000000', '0.00000000', '');
INSERT INTO `movesay_user_coin` VALUES ('3', '3', '10000100.00000000', '0.00000000', '1000000.00000000', '0.00000000', '', '1000000.00000000', '0.00000000', '', '0.00000000', '0.00000000', '');
INSERT INTO `movesay_user_coin` VALUES ('4', '4', '99999999.00000000', '0.00000000', '999999.00000000', '0.00000000', '', '9999.00000000', '0.00000000', '', '0.00000000', '0.00000000', '');

-- -----------------------------
-- Table structure for `movesay_user_goods`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_goods`;
CREATE TABLE `movesay_user_goods` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `name` varchar(200) NOT NULL,
  `truename` varchar(200) NOT NULL,
  `idcard` varchar(200) NOT NULL,
  `moble` varchar(200) NOT NULL,
  `addr` varchar(200) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `movesay_user_goods`
-- -----------------------------
INSERT INTO `movesay_user_goods` VALUES ('1', '2', '123', '请问', '430821198802023333', '13888888888', '啊发而非阿瑟发全国', '0', '1467292285', '0', '1');

-- -----------------------------
-- Table structure for `movesay_user_log`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_log`;
CREATE TABLE `movesay_user_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL,
  `type` varchar(200) NOT NULL,
  `remark` varchar(200) NOT NULL,
  `addip` varchar(200) NOT NULL,
  `addr` varchar(200) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='用户记录表';

-- -----------------------------
-- Records of `movesay_user_log`
-- -----------------------------
INSERT INTO `movesay_user_log` VALUES ('1', '3', '登录', '通过用户名登录', '112.95.136.101', '未分配或者内网IP', '0', '1467286436', '0', '1');
INSERT INTO `movesay_user_log` VALUES ('2', '2', '登录', '通过用户名登录', '121.34.129.214', '未分配或者内网IP', '0', '1467349383', '0', '1');
INSERT INTO `movesay_user_log` VALUES ('3', '2', '登录', '通过用户名登录', '121.34.129.214', '未分配或者内网IP', '0', '1467349889', '0', '1');
INSERT INTO `movesay_user_log` VALUES ('4', '2', '登录', '通过用户名登录', '121.34.129.214', '未分配或者内网IP', '0', '1467370264', '0', '1');
INSERT INTO `movesay_user_log` VALUES ('5', '3', '登录', '通过用户名登录', '112.95.136.101', '未分配或者内网IP', '0', '1467594987', '0', '1');
INSERT INTO `movesay_user_log` VALUES ('6', '2', '登录', '通过用户名登录', '220.202.152.42', '未分配或者内网IP', '0', '1467595193', '0', '1');
INSERT INTO `movesay_user_log` VALUES ('7', '3', '登录', '通过用户名登录', '112.95.136.101', '未分配或者内网IP', '0', '1467595305', '0', '1');
INSERT INTO `movesay_user_log` VALUES ('8', '2', '登录', '通过用户名登录', '113.102.161.228', '未分配或者内网IP', '0', '1467603419', '0', '1');
INSERT INTO `movesay_user_log` VALUES ('9', '2', '登录', '通过用户名登录', '183.54.81.121', '未分配或者内网IP', '0', '1467615422', '0', '1');

-- -----------------------------
-- Table structure for `movesay_user_qianbao`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_qianbao`;
CREATE TABLE `movesay_user_qianbao` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL,
  `coinname` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `addr` varchar(200) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `coinname` (`coinname`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户钱包表';

-- -----------------------------
-- Records of `movesay_user_qianbao`
-- -----------------------------
INSERT INTO `movesay_user_qianbao` VALUES ('1', '2', 'btc', '比特1', '7fc388730328525271a39bae0becd54f75bc0d5f ', '0', '1467292195', '0', '1');
INSERT INTO `movesay_user_qianbao` VALUES ('2', '2', 'ltc', '莱特1', '7fc388730328525271a39bae0becd54f75bc0d5f ', '0', '1467292222', '0', '1');

-- -----------------------------
-- Table structure for `movesay_user_shopaddr`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_user_shopaddr`;
CREATE TABLE `movesay_user_shopaddr` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) unsigned NOT NULL DEFAULT '0',
  `truename` varchar(200) NOT NULL DEFAULT '0',
  `moble` varchar(500) NOT NULL,
  `name` varchar(500) NOT NULL,
  `sort` int(11) unsigned NOT NULL,
  `addtime` int(11) unsigned NOT NULL,
  `endtime` int(11) unsigned NOT NULL,
  `status` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `movesay_version`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_version`;
CREATE TABLE `movesay_version` (
  `name` varchar(50) NOT NULL COMMENT '版本号',
  `number` int(11) NOT NULL COMMENT '序列号，一般用日期数字标示',
  `title` varchar(50) NOT NULL COMMENT '版本名',
  `create_time` int(11) NOT NULL COMMENT '发布时间',
  `update_time` int(11) NOT NULL COMMENT '更新的时间',
  `log` text NOT NULL COMMENT '更新日志',
  `url` varchar(150) NOT NULL COMMENT '链接到的远程文章',
  `is_current` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`name`),
  KEY `id` (`number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='自动更新表';

-- -----------------------------
-- Records of `movesay_version`
-- -----------------------------
INSERT INTO `movesay_version` VALUES ('2.4.8', '10026', '优化自动更新功能', '1467361623', '0', '优化自动更新功能', 'http://101.201.199.224/Update/download/2.4.8.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.7', '10025', '更新人民币充值功能', '1467352025', '1467352740', '更新人民币充值功能\r\n优化软件不能自动到账\r\n优化前台充值弹窗的状态', 'http://101.201.199.224/Update/download/2.4.7.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.6', '10024', '优化财务部分', '1467346688', '1467350864', '优化充值提现转入转出', 'http://101.201.199.224/Update/download/2.4.6.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.9', '10027', '优化后台首页', '1467362093', '0', '优化后台首页\r\n增加扩展 -客服代码  可以更换钱袋客服代码 \r\n更新之后，需要清理缓存', 'http://os.movesay.com/Auth/upFile/version/2.4.9', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.1', '10009', '更新每日卖出限制', '1463659822', '0', '每日限制卖出计算说明\r\n\r\n比如系统设置10%   \r\n假如用户现在有100个币\r\n那么今天他可以卖10个\r\n如果这10个卖了\r\n按照计算他还剩余90个 \r\n按照上面的比例他应该还可以卖9个\r\n但是今天他已经卖过10个所以不能再卖了\r\n\r\n最新版在币种配置里面设置这个百分比参数\r\n\r\n优化核心部分代码', 'http://101.201.199.224/Update/download/2.3.1.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.0', '10008', '系统授权更新', '1463372848', '0', '因官网网站备案掉了更新授权功能', 'http://101.201.199.224/Update/download/2.3.0.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.2', '10020', '优化后台用户编辑', '1467185261', '1467277842', '优化后台用户编辑', 'http://101.201.199.224/Update/download/2.4.2.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.1', '10019', '优化扩展功能', '1467119925', '1467277816', '优化扩展功能', 'http://101.201.199.224/Update/download/2.4.1.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.0', '10018', '更新后台用户管理部分', '1467111754', '1467277791', '更新后台用户管理部分', 'http://101.201.199.224/Update/download/2.4.0.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.9', '10017', '更新后台内容管理', '1467105573', '0', '更新后台内容管理', 'http://101.201.199.224/Update/download/2.3.9.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.8', '10016', '更新权限', '1467096687', '0', '更新权限部分（还未完善）', 'http://101.201.199.224/Update/download/2.3.8.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.7', '10015', '修复更新', '1466394377', '0', '修复首页下拉导航条显示bug\r\n修复交易界面导航条下拉bug', 'http://101.201.199.224/Update/download/2.3.7.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.6', '10014', '增加交易评价后台管理', '1465530871', '0', '更新完成 记得清理缓存\r\n后台所有操作都要清理缓存才能生效\r\n\r\n增加交易评价后台管理  交易---币种评价\r\n增加委托管理缺少市场筛选功能\r\n增加交易记录缺少市场筛选功能\r\n优化登陆验证码后台控制在设置--其他设置里面可以设置是否开启需要验证码\r\n增加  设置其他设置里面 控制前台首页是否显示全站累计成交额\r\n增加元宝网首页模板，可在后台其他配置里面设置\r\n\r\n这次更新需要改动首页模板文件\r\n需要改动前台底部公共文件\r\n如果自己改过模板请先自行备份好\r\n\r\n后期版本更新预告\r\n1.充值部分\r\n2.发布应用理财，话费，集市\r\n3.用户财务明细\r\n\r\n针对破解或者盗版\r\n我们会有相应政策，坚决打击\r\n\r\n\r\n', 'http://101.201.199.224/Update/download/2.3.6.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.5', '10013', '更新用户登录去掉验证码部分', '1465212260', '0', '更新用户登录去掉验证码\r\n更新登录注册可能存在的漏洞\r\n更新版本泄露检查\r\n\r\n如果发现版本从你们这边泄露我们有权终止你的平台更新\r\n\r\n需要改动网站底部文件和网站首页文件\r\n请修改过模板的自行做好备份\r\n', 'http://101.201.199.224/Update/download/2.3.5.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.4', '10012', '后台交易管理添加撤销委托功能', '1464765371', '0', '后台交易管理添加撤销委托功能\r\n更新完成请后台清理一下缓存\r\n请更新之后仔细测试确认没有问题\r\n不要更新之后就不管了', 'http://101.201.199.224/Update/download/2.3.4.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.3', '10011', '增加新币投票功能', '1464695124', '0', '增加新币投票功能\r\n优化系统应用部分\r\n更新了前台头部文件', 'http://101.201.199.224/Update/download/2.3.3.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.3.2', '10010', '页面提示功能', '1464681746', '0', '增加每个页面带提示功能\r\n这次更新之后前台模板再不会大面积改动了\r\n\r\n更新完成后台清理一下缓存\r\n在设置--提示文字里面可以配置\r\n如果没有叨叨请多刷新一下基本设置页面\r\n', 'http://101.201.199.224/Update/download/2.3.2.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.5', '10023', '优化财务部分', '1467270688', '1467277927', '优化人民币充值 提现\r\n优化虚拟币转入 转出\r\n\r\n需要重新配置充值方式', 'http://101.201.199.224/Update/download/2.4.5.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.4', '10022', '更新后台交易管理部分', '1467266348', '1467277897', '更新后台交易管理部分', 'http://101.201.199.224/Update/download/2.4.4.zip', '0', '0');
INSERT INTO `movesay_version` VALUES ('2.4.3', '10021', '优化后台菜单部分', '1467265786', '1467277868', '优化后台菜单部分', 'http://101.201.199.224/Update/download/2.4.3.zip', '0', '0');

-- -----------------------------
-- Table structure for `movesay_version_game`
-- -----------------------------
DROP TABLE IF EXISTS `movesay_version_game`;
CREATE TABLE `movesay_version_game` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `number` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='应用管理表';

-- -----------------------------
-- Records of `movesay_version_game`
-- -----------------------------
INSERT INTO `movesay_version_game` VALUES ('1', 'shop', '云购商城', '0');
INSERT INTO `movesay_version_game` VALUES ('2', 'fenhong', '分红中心', '0');
INSERT INTO `movesay_version_game` VALUES ('3', 'huafei', '话费充值', '0');
INSERT INTO `movesay_version_game` VALUES ('4', 'issue', '认购中心', '0');
INSERT INTO `movesay_version_game` VALUES ('5', 'vote', '新币投票', '0');
INSERT INTO `movesay_version_game` VALUES ('6', 'money', '理财中心', '0');
INSERT INTO `movesay_version_game` VALUES ('7', 'bazaar', '集市交易', '0');
